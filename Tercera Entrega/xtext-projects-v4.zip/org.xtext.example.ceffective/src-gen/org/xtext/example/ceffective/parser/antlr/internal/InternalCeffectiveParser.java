package org.xtext.example.ceffective.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.example.ceffective.services.CeffectiveGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalCeffectiveParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_OBJECT_START", "RULE_EQUALS", "RULE_SEMICOLON", "RULE_OBJECT_END", "RULE_COMA", "RULE_LIST_START", "RULE_LIST_END", "RULE_ID", "RULE_INT", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'InfraestructuraCeffective'", "'proveedorNube'", "'tipoProveedor'", "'autenticacionUsuario'", "'ambientes'", "'AutenticacionUsuario'", "'usuario'", "'correo'", "'password'", "'accessId'", "'secret'", "'ambiente'", "'nombre'", "'vpcs'", "'securityresource'", "'recursos'", "'conexiones'", "'recurso1'", "'recurso2'", "'id'", "'cidrBlock'", "'.'", "'zonaNombre'", "'zonaDisponibilidad'", "'vpc'", "'descripcion'", "'reglas'", "'tipo'", "'protocolo'", "'puerto'", "'origen'", "'direccion'", "'Servidor'", "'tamano'", "'('", "')'", "'dimension'", "'sistemaOperativo'", "'gigas'", "'sistemaManejador'", "'-'", "'E'", "'e'", "'IST'", "'QA'", "'NFT'", "'PRD'", "'ENTRADA'", "'SALIDA'", "'Micro'", "'Small'", "'Medium'", "'Large'", "'Relacional'", "'NoSql'"
    };
    public static final int T__50=50;
    public static final int RULE_OBJECT_START=4;
    public static final int RULE_LIST_END=10;
    public static final int T__19=19;
    public static final int RULE_EQUALS=5;
    public static final int T__59=59;
    public static final int T__18=18;
    public static final int T__55=55;
    public static final int T__56=56;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=11;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=12;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=14;
    public static final int T__23=23;
    public static final int T__67=67;
    public static final int T__24=24;
    public static final int T__68=68;
    public static final int T__25=25;
    public static final int T__69=69;
    public static final int RULE_SEMICOLON=6;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__20=20;
    public static final int T__64=64;
    public static final int T__21=21;
    public static final int T__65=65;
    public static final int T__70=70;
    public static final int RULE_LIST_START=9;
    public static final int T__71=71;
    public static final int RULE_COMA=8;
    public static final int T__72=72;
    public static final int RULE_STRING=13;
    public static final int RULE_SL_COMMENT=15;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=16;
    public static final int RULE_ANY_OTHER=17;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int RULE_OBJECT_END=7;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalCeffectiveParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalCeffectiveParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalCeffectiveParser.tokenNames; }
    public String getGrammarFileName() { return "InternalCeffective.g"; }



     	private CeffectiveGrammarAccess grammarAccess;

        public InternalCeffectiveParser(TokenStream input, CeffectiveGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Ceffective";
       	}

       	@Override
       	protected CeffectiveGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleCeffective"
    // InternalCeffective.g:65:1: entryRuleCeffective returns [EObject current=null] : iv_ruleCeffective= ruleCeffective EOF ;
    public final EObject entryRuleCeffective() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCeffective = null;


        try {
            // InternalCeffective.g:65:51: (iv_ruleCeffective= ruleCeffective EOF )
            // InternalCeffective.g:66:2: iv_ruleCeffective= ruleCeffective EOF
            {
             newCompositeNode(grammarAccess.getCeffectiveRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCeffective=ruleCeffective();

            state._fsp--;

             current =iv_ruleCeffective; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCeffective"


    // $ANTLR start "ruleCeffective"
    // InternalCeffective.g:72:1: ruleCeffective returns [EObject current=null] : ( () otherlv_1= 'InfraestructuraCeffective' ( (lv_nombre_2_0= ruleEString ) )? this_OBJECT_START_3= RULE_OBJECT_START (otherlv_4= 'proveedorNube' this_EQUALS_5= RULE_EQUALS ( (lv_proveedorNube_6_0= ruleProveedorNube ) ) this_SEMICOLON_7= RULE_SEMICOLON )? this_OBJECT_END_8= RULE_OBJECT_END ) ;
    public final EObject ruleCeffective() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token this_OBJECT_START_3=null;
        Token otherlv_4=null;
        Token this_EQUALS_5=null;
        Token this_SEMICOLON_7=null;
        Token this_OBJECT_END_8=null;
        AntlrDatatypeRuleToken lv_nombre_2_0 = null;

        EObject lv_proveedorNube_6_0 = null;



        	enterRule();

        try {
            // InternalCeffective.g:78:2: ( ( () otherlv_1= 'InfraestructuraCeffective' ( (lv_nombre_2_0= ruleEString ) )? this_OBJECT_START_3= RULE_OBJECT_START (otherlv_4= 'proveedorNube' this_EQUALS_5= RULE_EQUALS ( (lv_proveedorNube_6_0= ruleProveedorNube ) ) this_SEMICOLON_7= RULE_SEMICOLON )? this_OBJECT_END_8= RULE_OBJECT_END ) )
            // InternalCeffective.g:79:2: ( () otherlv_1= 'InfraestructuraCeffective' ( (lv_nombre_2_0= ruleEString ) )? this_OBJECT_START_3= RULE_OBJECT_START (otherlv_4= 'proveedorNube' this_EQUALS_5= RULE_EQUALS ( (lv_proveedorNube_6_0= ruleProveedorNube ) ) this_SEMICOLON_7= RULE_SEMICOLON )? this_OBJECT_END_8= RULE_OBJECT_END )
            {
            // InternalCeffective.g:79:2: ( () otherlv_1= 'InfraestructuraCeffective' ( (lv_nombre_2_0= ruleEString ) )? this_OBJECT_START_3= RULE_OBJECT_START (otherlv_4= 'proveedorNube' this_EQUALS_5= RULE_EQUALS ( (lv_proveedorNube_6_0= ruleProveedorNube ) ) this_SEMICOLON_7= RULE_SEMICOLON )? this_OBJECT_END_8= RULE_OBJECT_END )
            // InternalCeffective.g:80:3: () otherlv_1= 'InfraestructuraCeffective' ( (lv_nombre_2_0= ruleEString ) )? this_OBJECT_START_3= RULE_OBJECT_START (otherlv_4= 'proveedorNube' this_EQUALS_5= RULE_EQUALS ( (lv_proveedorNube_6_0= ruleProveedorNube ) ) this_SEMICOLON_7= RULE_SEMICOLON )? this_OBJECT_END_8= RULE_OBJECT_END
            {
            // InternalCeffective.g:80:3: ()
            // InternalCeffective.g:81:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getCeffectiveAccess().getCeffectiveAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,18,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getCeffectiveAccess().getInfraestructuraCeffectiveKeyword_1());
            		
            // InternalCeffective.g:91:3: ( (lv_nombre_2_0= ruleEString ) )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==RULE_ID||LA1_0==RULE_STRING) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // InternalCeffective.g:92:4: (lv_nombre_2_0= ruleEString )
                    {
                    // InternalCeffective.g:92:4: (lv_nombre_2_0= ruleEString )
                    // InternalCeffective.g:93:5: lv_nombre_2_0= ruleEString
                    {

                    					newCompositeNode(grammarAccess.getCeffectiveAccess().getNombreEStringParserRuleCall_2_0());
                    				
                    pushFollow(FOLLOW_4);
                    lv_nombre_2_0=ruleEString();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getCeffectiveRule());
                    					}
                    					set(
                    						current,
                    						"nombre",
                    						lv_nombre_2_0,
                    						"org.xtext.example.ceffective.Ceffective.EString");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            this_OBJECT_START_3=(Token)match(input,RULE_OBJECT_START,FOLLOW_5); 

            			newLeafNode(this_OBJECT_START_3, grammarAccess.getCeffectiveAccess().getOBJECT_STARTTerminalRuleCall_3());
            		
            // InternalCeffective.g:114:3: (otherlv_4= 'proveedorNube' this_EQUALS_5= RULE_EQUALS ( (lv_proveedorNube_6_0= ruleProveedorNube ) ) this_SEMICOLON_7= RULE_SEMICOLON )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==19) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // InternalCeffective.g:115:4: otherlv_4= 'proveedorNube' this_EQUALS_5= RULE_EQUALS ( (lv_proveedorNube_6_0= ruleProveedorNube ) ) this_SEMICOLON_7= RULE_SEMICOLON
                    {
                    otherlv_4=(Token)match(input,19,FOLLOW_6); 

                    				newLeafNode(otherlv_4, grammarAccess.getCeffectiveAccess().getProveedorNubeKeyword_4_0());
                    			
                    this_EQUALS_5=(Token)match(input,RULE_EQUALS,FOLLOW_4); 

                    				newLeafNode(this_EQUALS_5, grammarAccess.getCeffectiveAccess().getEQUALSTerminalRuleCall_4_1());
                    			
                    // InternalCeffective.g:123:4: ( (lv_proveedorNube_6_0= ruleProveedorNube ) )
                    // InternalCeffective.g:124:5: (lv_proveedorNube_6_0= ruleProveedorNube )
                    {
                    // InternalCeffective.g:124:5: (lv_proveedorNube_6_0= ruleProveedorNube )
                    // InternalCeffective.g:125:6: lv_proveedorNube_6_0= ruleProveedorNube
                    {

                    						newCompositeNode(grammarAccess.getCeffectiveAccess().getProveedorNubeProveedorNubeParserRuleCall_4_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_proveedorNube_6_0=ruleProveedorNube();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getCeffectiveRule());
                    						}
                    						set(
                    							current,
                    							"proveedorNube",
                    							lv_proveedorNube_6_0,
                    							"org.xtext.example.ceffective.Ceffective.ProveedorNube");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_7=(Token)match(input,RULE_SEMICOLON,FOLLOW_8); 

                    				newLeafNode(this_SEMICOLON_7, grammarAccess.getCeffectiveAccess().getSEMICOLONTerminalRuleCall_4_3());
                    			

                    }
                    break;

            }

            this_OBJECT_END_8=(Token)match(input,RULE_OBJECT_END,FOLLOW_2); 

            			newLeafNode(this_OBJECT_END_8, grammarAccess.getCeffectiveAccess().getOBJECT_ENDTerminalRuleCall_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCeffective"


    // $ANTLR start "entryRuleProveedorNube"
    // InternalCeffective.g:155:1: entryRuleProveedorNube returns [EObject current=null] : iv_ruleProveedorNube= ruleProveedorNube EOF ;
    public final EObject entryRuleProveedorNube() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleProveedorNube = null;


        try {
            // InternalCeffective.g:155:54: (iv_ruleProveedorNube= ruleProveedorNube EOF )
            // InternalCeffective.g:156:2: iv_ruleProveedorNube= ruleProveedorNube EOF
            {
             newCompositeNode(grammarAccess.getProveedorNubeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleProveedorNube=ruleProveedorNube();

            state._fsp--;

             current =iv_ruleProveedorNube; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleProveedorNube"


    // $ANTLR start "ruleProveedorNube"
    // InternalCeffective.g:162:1: ruleProveedorNube returns [EObject current=null] : (this_OBJECT_START_0= RULE_OBJECT_START otherlv_1= 'tipoProveedor' this_EQUALS_2= RULE_EQUALS ( (lv_nombre_3_0= ruleEString ) ) this_SEMICOLON_4= RULE_SEMICOLON otherlv_5= 'autenticacionUsuario' this_EQUALS_6= RULE_EQUALS ( (lv_autenticacionUsuario_7_0= ruleAutenticacionUsuario ) ) (this_COMA_8= RULE_COMA ( (lv_autenticacionUsuario_9_0= ruleAutenticacionUsuario ) ) )* this_SEMICOLON_10= RULE_SEMICOLON (otherlv_11= 'ambientes' this_EQUALS_12= RULE_EQUALS this_LIST_START_13= RULE_LIST_START ( (lv_ambientedespliegue_14_0= ruleAmbienteDespliegue ) ) (this_COMA_15= RULE_COMA ( (lv_ambientedespliegue_16_0= ruleAmbienteDespliegue ) ) )* this_LIST_END_17= RULE_LIST_END )? this_OBJECT_END_18= RULE_OBJECT_END ) ;
    public final EObject ruleProveedorNube() throws RecognitionException {
        EObject current = null;

        Token this_OBJECT_START_0=null;
        Token otherlv_1=null;
        Token this_EQUALS_2=null;
        Token this_SEMICOLON_4=null;
        Token otherlv_5=null;
        Token this_EQUALS_6=null;
        Token this_COMA_8=null;
        Token this_SEMICOLON_10=null;
        Token otherlv_11=null;
        Token this_EQUALS_12=null;
        Token this_LIST_START_13=null;
        Token this_COMA_15=null;
        Token this_LIST_END_17=null;
        Token this_OBJECT_END_18=null;
        AntlrDatatypeRuleToken lv_nombre_3_0 = null;

        EObject lv_autenticacionUsuario_7_0 = null;

        EObject lv_autenticacionUsuario_9_0 = null;

        EObject lv_ambientedespliegue_14_0 = null;

        EObject lv_ambientedespliegue_16_0 = null;



        	enterRule();

        try {
            // InternalCeffective.g:168:2: ( (this_OBJECT_START_0= RULE_OBJECT_START otherlv_1= 'tipoProveedor' this_EQUALS_2= RULE_EQUALS ( (lv_nombre_3_0= ruleEString ) ) this_SEMICOLON_4= RULE_SEMICOLON otherlv_5= 'autenticacionUsuario' this_EQUALS_6= RULE_EQUALS ( (lv_autenticacionUsuario_7_0= ruleAutenticacionUsuario ) ) (this_COMA_8= RULE_COMA ( (lv_autenticacionUsuario_9_0= ruleAutenticacionUsuario ) ) )* this_SEMICOLON_10= RULE_SEMICOLON (otherlv_11= 'ambientes' this_EQUALS_12= RULE_EQUALS this_LIST_START_13= RULE_LIST_START ( (lv_ambientedespliegue_14_0= ruleAmbienteDespliegue ) ) (this_COMA_15= RULE_COMA ( (lv_ambientedespliegue_16_0= ruleAmbienteDespliegue ) ) )* this_LIST_END_17= RULE_LIST_END )? this_OBJECT_END_18= RULE_OBJECT_END ) )
            // InternalCeffective.g:169:2: (this_OBJECT_START_0= RULE_OBJECT_START otherlv_1= 'tipoProveedor' this_EQUALS_2= RULE_EQUALS ( (lv_nombre_3_0= ruleEString ) ) this_SEMICOLON_4= RULE_SEMICOLON otherlv_5= 'autenticacionUsuario' this_EQUALS_6= RULE_EQUALS ( (lv_autenticacionUsuario_7_0= ruleAutenticacionUsuario ) ) (this_COMA_8= RULE_COMA ( (lv_autenticacionUsuario_9_0= ruleAutenticacionUsuario ) ) )* this_SEMICOLON_10= RULE_SEMICOLON (otherlv_11= 'ambientes' this_EQUALS_12= RULE_EQUALS this_LIST_START_13= RULE_LIST_START ( (lv_ambientedespliegue_14_0= ruleAmbienteDespliegue ) ) (this_COMA_15= RULE_COMA ( (lv_ambientedespliegue_16_0= ruleAmbienteDespliegue ) ) )* this_LIST_END_17= RULE_LIST_END )? this_OBJECT_END_18= RULE_OBJECT_END )
            {
            // InternalCeffective.g:169:2: (this_OBJECT_START_0= RULE_OBJECT_START otherlv_1= 'tipoProveedor' this_EQUALS_2= RULE_EQUALS ( (lv_nombre_3_0= ruleEString ) ) this_SEMICOLON_4= RULE_SEMICOLON otherlv_5= 'autenticacionUsuario' this_EQUALS_6= RULE_EQUALS ( (lv_autenticacionUsuario_7_0= ruleAutenticacionUsuario ) ) (this_COMA_8= RULE_COMA ( (lv_autenticacionUsuario_9_0= ruleAutenticacionUsuario ) ) )* this_SEMICOLON_10= RULE_SEMICOLON (otherlv_11= 'ambientes' this_EQUALS_12= RULE_EQUALS this_LIST_START_13= RULE_LIST_START ( (lv_ambientedespliegue_14_0= ruleAmbienteDespliegue ) ) (this_COMA_15= RULE_COMA ( (lv_ambientedespliegue_16_0= ruleAmbienteDespliegue ) ) )* this_LIST_END_17= RULE_LIST_END )? this_OBJECT_END_18= RULE_OBJECT_END )
            // InternalCeffective.g:170:3: this_OBJECT_START_0= RULE_OBJECT_START otherlv_1= 'tipoProveedor' this_EQUALS_2= RULE_EQUALS ( (lv_nombre_3_0= ruleEString ) ) this_SEMICOLON_4= RULE_SEMICOLON otherlv_5= 'autenticacionUsuario' this_EQUALS_6= RULE_EQUALS ( (lv_autenticacionUsuario_7_0= ruleAutenticacionUsuario ) ) (this_COMA_8= RULE_COMA ( (lv_autenticacionUsuario_9_0= ruleAutenticacionUsuario ) ) )* this_SEMICOLON_10= RULE_SEMICOLON (otherlv_11= 'ambientes' this_EQUALS_12= RULE_EQUALS this_LIST_START_13= RULE_LIST_START ( (lv_ambientedespliegue_14_0= ruleAmbienteDespliegue ) ) (this_COMA_15= RULE_COMA ( (lv_ambientedespliegue_16_0= ruleAmbienteDespliegue ) ) )* this_LIST_END_17= RULE_LIST_END )? this_OBJECT_END_18= RULE_OBJECT_END
            {
            this_OBJECT_START_0=(Token)match(input,RULE_OBJECT_START,FOLLOW_9); 

            			newLeafNode(this_OBJECT_START_0, grammarAccess.getProveedorNubeAccess().getOBJECT_STARTTerminalRuleCall_0());
            		
            otherlv_1=(Token)match(input,20,FOLLOW_6); 

            			newLeafNode(otherlv_1, grammarAccess.getProveedorNubeAccess().getTipoProveedorKeyword_1());
            		
            this_EQUALS_2=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

            			newLeafNode(this_EQUALS_2, grammarAccess.getProveedorNubeAccess().getEQUALSTerminalRuleCall_2());
            		
            // InternalCeffective.g:182:3: ( (lv_nombre_3_0= ruleEString ) )
            // InternalCeffective.g:183:4: (lv_nombre_3_0= ruleEString )
            {
            // InternalCeffective.g:183:4: (lv_nombre_3_0= ruleEString )
            // InternalCeffective.g:184:5: lv_nombre_3_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getProveedorNubeAccess().getNombreEStringParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_7);
            lv_nombre_3_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getProveedorNubeRule());
            					}
            					set(
            						current,
            						"nombre",
            						lv_nombre_3_0,
            						"org.xtext.example.ceffective.Ceffective.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_SEMICOLON_4=(Token)match(input,RULE_SEMICOLON,FOLLOW_11); 

            			newLeafNode(this_SEMICOLON_4, grammarAccess.getProveedorNubeAccess().getSEMICOLONTerminalRuleCall_4());
            		
            otherlv_5=(Token)match(input,21,FOLLOW_6); 

            			newLeafNode(otherlv_5, grammarAccess.getProveedorNubeAccess().getAutenticacionUsuarioKeyword_5());
            		
            this_EQUALS_6=(Token)match(input,RULE_EQUALS,FOLLOW_12); 

            			newLeafNode(this_EQUALS_6, grammarAccess.getProveedorNubeAccess().getEQUALSTerminalRuleCall_6());
            		
            // InternalCeffective.g:213:3: ( (lv_autenticacionUsuario_7_0= ruleAutenticacionUsuario ) )
            // InternalCeffective.g:214:4: (lv_autenticacionUsuario_7_0= ruleAutenticacionUsuario )
            {
            // InternalCeffective.g:214:4: (lv_autenticacionUsuario_7_0= ruleAutenticacionUsuario )
            // InternalCeffective.g:215:5: lv_autenticacionUsuario_7_0= ruleAutenticacionUsuario
            {

            					newCompositeNode(grammarAccess.getProveedorNubeAccess().getAutenticacionUsuarioAutenticacionUsuarioParserRuleCall_7_0());
            				
            pushFollow(FOLLOW_13);
            lv_autenticacionUsuario_7_0=ruleAutenticacionUsuario();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getProveedorNubeRule());
            					}
            					add(
            						current,
            						"autenticacionUsuario",
            						lv_autenticacionUsuario_7_0,
            						"org.xtext.example.ceffective.Ceffective.AutenticacionUsuario");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalCeffective.g:232:3: (this_COMA_8= RULE_COMA ( (lv_autenticacionUsuario_9_0= ruleAutenticacionUsuario ) ) )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==RULE_COMA) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalCeffective.g:233:4: this_COMA_8= RULE_COMA ( (lv_autenticacionUsuario_9_0= ruleAutenticacionUsuario ) )
            	    {
            	    this_COMA_8=(Token)match(input,RULE_COMA,FOLLOW_12); 

            	    				newLeafNode(this_COMA_8, grammarAccess.getProveedorNubeAccess().getCOMATerminalRuleCall_8_0());
            	    			
            	    // InternalCeffective.g:237:4: ( (lv_autenticacionUsuario_9_0= ruleAutenticacionUsuario ) )
            	    // InternalCeffective.g:238:5: (lv_autenticacionUsuario_9_0= ruleAutenticacionUsuario )
            	    {
            	    // InternalCeffective.g:238:5: (lv_autenticacionUsuario_9_0= ruleAutenticacionUsuario )
            	    // InternalCeffective.g:239:6: lv_autenticacionUsuario_9_0= ruleAutenticacionUsuario
            	    {

            	    						newCompositeNode(grammarAccess.getProveedorNubeAccess().getAutenticacionUsuarioAutenticacionUsuarioParserRuleCall_8_1_0());
            	    					
            	    pushFollow(FOLLOW_13);
            	    lv_autenticacionUsuario_9_0=ruleAutenticacionUsuario();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getProveedorNubeRule());
            	    						}
            	    						add(
            	    							current,
            	    							"autenticacionUsuario",
            	    							lv_autenticacionUsuario_9_0,
            	    							"org.xtext.example.ceffective.Ceffective.AutenticacionUsuario");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            this_SEMICOLON_10=(Token)match(input,RULE_SEMICOLON,FOLLOW_14); 

            			newLeafNode(this_SEMICOLON_10, grammarAccess.getProveedorNubeAccess().getSEMICOLONTerminalRuleCall_9());
            		
            // InternalCeffective.g:261:3: (otherlv_11= 'ambientes' this_EQUALS_12= RULE_EQUALS this_LIST_START_13= RULE_LIST_START ( (lv_ambientedespliegue_14_0= ruleAmbienteDespliegue ) ) (this_COMA_15= RULE_COMA ( (lv_ambientedespliegue_16_0= ruleAmbienteDespliegue ) ) )* this_LIST_END_17= RULE_LIST_END )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==22) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalCeffective.g:262:4: otherlv_11= 'ambientes' this_EQUALS_12= RULE_EQUALS this_LIST_START_13= RULE_LIST_START ( (lv_ambientedespliegue_14_0= ruleAmbienteDespliegue ) ) (this_COMA_15= RULE_COMA ( (lv_ambientedespliegue_16_0= ruleAmbienteDespliegue ) ) )* this_LIST_END_17= RULE_LIST_END
                    {
                    otherlv_11=(Token)match(input,22,FOLLOW_6); 

                    				newLeafNode(otherlv_11, grammarAccess.getProveedorNubeAccess().getAmbientesKeyword_10_0());
                    			
                    this_EQUALS_12=(Token)match(input,RULE_EQUALS,FOLLOW_15); 

                    				newLeafNode(this_EQUALS_12, grammarAccess.getProveedorNubeAccess().getEQUALSTerminalRuleCall_10_1());
                    			
                    this_LIST_START_13=(Token)match(input,RULE_LIST_START,FOLLOW_4); 

                    				newLeafNode(this_LIST_START_13, grammarAccess.getProveedorNubeAccess().getLIST_STARTTerminalRuleCall_10_2());
                    			
                    // InternalCeffective.g:274:4: ( (lv_ambientedespliegue_14_0= ruleAmbienteDespliegue ) )
                    // InternalCeffective.g:275:5: (lv_ambientedespliegue_14_0= ruleAmbienteDespliegue )
                    {
                    // InternalCeffective.g:275:5: (lv_ambientedespliegue_14_0= ruleAmbienteDespliegue )
                    // InternalCeffective.g:276:6: lv_ambientedespliegue_14_0= ruleAmbienteDespliegue
                    {

                    						newCompositeNode(grammarAccess.getProveedorNubeAccess().getAmbientedespliegueAmbienteDespliegueParserRuleCall_10_3_0());
                    					
                    pushFollow(FOLLOW_16);
                    lv_ambientedespliegue_14_0=ruleAmbienteDespliegue();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getProveedorNubeRule());
                    						}
                    						add(
                    							current,
                    							"ambientedespliegue",
                    							lv_ambientedespliegue_14_0,
                    							"org.xtext.example.ceffective.Ceffective.AmbienteDespliegue");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalCeffective.g:293:4: (this_COMA_15= RULE_COMA ( (lv_ambientedespliegue_16_0= ruleAmbienteDespliegue ) ) )*
                    loop4:
                    do {
                        int alt4=2;
                        int LA4_0 = input.LA(1);

                        if ( (LA4_0==RULE_COMA) ) {
                            alt4=1;
                        }


                        switch (alt4) {
                    	case 1 :
                    	    // InternalCeffective.g:294:5: this_COMA_15= RULE_COMA ( (lv_ambientedespliegue_16_0= ruleAmbienteDespliegue ) )
                    	    {
                    	    this_COMA_15=(Token)match(input,RULE_COMA,FOLLOW_4); 

                    	    					newLeafNode(this_COMA_15, grammarAccess.getProveedorNubeAccess().getCOMATerminalRuleCall_10_4_0());
                    	    				
                    	    // InternalCeffective.g:298:5: ( (lv_ambientedespliegue_16_0= ruleAmbienteDespliegue ) )
                    	    // InternalCeffective.g:299:6: (lv_ambientedespliegue_16_0= ruleAmbienteDespliegue )
                    	    {
                    	    // InternalCeffective.g:299:6: (lv_ambientedespliegue_16_0= ruleAmbienteDespliegue )
                    	    // InternalCeffective.g:300:7: lv_ambientedespliegue_16_0= ruleAmbienteDespliegue
                    	    {

                    	    							newCompositeNode(grammarAccess.getProveedorNubeAccess().getAmbientedespliegueAmbienteDespliegueParserRuleCall_10_4_1_0());
                    	    						
                    	    pushFollow(FOLLOW_16);
                    	    lv_ambientedespliegue_16_0=ruleAmbienteDespliegue();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getProveedorNubeRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"ambientedespliegue",
                    	    								lv_ambientedespliegue_16_0,
                    	    								"org.xtext.example.ceffective.Ceffective.AmbienteDespliegue");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop4;
                        }
                    } while (true);

                    this_LIST_END_17=(Token)match(input,RULE_LIST_END,FOLLOW_8); 

                    				newLeafNode(this_LIST_END_17, grammarAccess.getProveedorNubeAccess().getLIST_ENDTerminalRuleCall_10_5());
                    			

                    }
                    break;

            }

            this_OBJECT_END_18=(Token)match(input,RULE_OBJECT_END,FOLLOW_2); 

            			newLeafNode(this_OBJECT_END_18, grammarAccess.getProveedorNubeAccess().getOBJECT_ENDTerminalRuleCall_11());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleProveedorNube"


    // $ANTLR start "entryRuleAutenticacionUsuario"
    // InternalCeffective.g:331:1: entryRuleAutenticacionUsuario returns [EObject current=null] : iv_ruleAutenticacionUsuario= ruleAutenticacionUsuario EOF ;
    public final EObject entryRuleAutenticacionUsuario() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAutenticacionUsuario = null;


        try {
            // InternalCeffective.g:331:61: (iv_ruleAutenticacionUsuario= ruleAutenticacionUsuario EOF )
            // InternalCeffective.g:332:2: iv_ruleAutenticacionUsuario= ruleAutenticacionUsuario EOF
            {
             newCompositeNode(grammarAccess.getAutenticacionUsuarioRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAutenticacionUsuario=ruleAutenticacionUsuario();

            state._fsp--;

             current =iv_ruleAutenticacionUsuario; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAutenticacionUsuario"


    // $ANTLR start "ruleAutenticacionUsuario"
    // InternalCeffective.g:338:1: ruleAutenticacionUsuario returns [EObject current=null] : (this_AutenticacionBasica_0= ruleAutenticacionBasica | this_AutenticacionFirma_1= ruleAutenticacionFirma | this_AutenticacionUsuario_Impl_2= ruleAutenticacionUsuario_Impl ) ;
    public final EObject ruleAutenticacionUsuario() throws RecognitionException {
        EObject current = null;

        EObject this_AutenticacionBasica_0 = null;

        EObject this_AutenticacionFirma_1 = null;

        EObject this_AutenticacionUsuario_Impl_2 = null;



        	enterRule();

        try {
            // InternalCeffective.g:344:2: ( (this_AutenticacionBasica_0= ruleAutenticacionBasica | this_AutenticacionFirma_1= ruleAutenticacionFirma | this_AutenticacionUsuario_Impl_2= ruleAutenticacionUsuario_Impl ) )
            // InternalCeffective.g:345:2: (this_AutenticacionBasica_0= ruleAutenticacionBasica | this_AutenticacionFirma_1= ruleAutenticacionFirma | this_AutenticacionUsuario_Impl_2= ruleAutenticacionUsuario_Impl )
            {
            // InternalCeffective.g:345:2: (this_AutenticacionBasica_0= ruleAutenticacionBasica | this_AutenticacionFirma_1= ruleAutenticacionFirma | this_AutenticacionUsuario_Impl_2= ruleAutenticacionUsuario_Impl )
            int alt6=3;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==RULE_OBJECT_START) ) {
                int LA6_1 = input.LA(2);

                if ( ((LA6_1>=24 && LA6_1<=25)) ) {
                    alt6=1;
                }
                else if ( (LA6_1==27) ) {
                    alt6=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 6, 1, input);

                    throw nvae;
                }
            }
            else if ( (LA6_0==23) ) {
                alt6=3;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // InternalCeffective.g:346:3: this_AutenticacionBasica_0= ruleAutenticacionBasica
                    {

                    			newCompositeNode(grammarAccess.getAutenticacionUsuarioAccess().getAutenticacionBasicaParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_AutenticacionBasica_0=ruleAutenticacionBasica();

                    state._fsp--;


                    			current = this_AutenticacionBasica_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalCeffective.g:355:3: this_AutenticacionFirma_1= ruleAutenticacionFirma
                    {

                    			newCompositeNode(grammarAccess.getAutenticacionUsuarioAccess().getAutenticacionFirmaParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_AutenticacionFirma_1=ruleAutenticacionFirma();

                    state._fsp--;


                    			current = this_AutenticacionFirma_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalCeffective.g:364:3: this_AutenticacionUsuario_Impl_2= ruleAutenticacionUsuario_Impl
                    {

                    			newCompositeNode(grammarAccess.getAutenticacionUsuarioAccess().getAutenticacionUsuario_ImplParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_AutenticacionUsuario_Impl_2=ruleAutenticacionUsuario_Impl();

                    state._fsp--;


                    			current = this_AutenticacionUsuario_Impl_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAutenticacionUsuario"


    // $ANTLR start "entryRuleAutenticacionUsuario_Impl"
    // InternalCeffective.g:376:1: entryRuleAutenticacionUsuario_Impl returns [EObject current=null] : iv_ruleAutenticacionUsuario_Impl= ruleAutenticacionUsuario_Impl EOF ;
    public final EObject entryRuleAutenticacionUsuario_Impl() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAutenticacionUsuario_Impl = null;


        try {
            // InternalCeffective.g:376:66: (iv_ruleAutenticacionUsuario_Impl= ruleAutenticacionUsuario_Impl EOF )
            // InternalCeffective.g:377:2: iv_ruleAutenticacionUsuario_Impl= ruleAutenticacionUsuario_Impl EOF
            {
             newCompositeNode(grammarAccess.getAutenticacionUsuario_ImplRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAutenticacionUsuario_Impl=ruleAutenticacionUsuario_Impl();

            state._fsp--;

             current =iv_ruleAutenticacionUsuario_Impl; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAutenticacionUsuario_Impl"


    // $ANTLR start "ruleAutenticacionUsuario_Impl"
    // InternalCeffective.g:383:1: ruleAutenticacionUsuario_Impl returns [EObject current=null] : ( () otherlv_1= 'AutenticacionUsuario' this_OBJECT_START_2= RULE_OBJECT_START (otherlv_3= 'usuario' this_EQUALS_4= RULE_EQUALS ( (lv_usuario_5_0= ruleEString ) ) this_SEMICOLON_6= RULE_SEMICOLON )? (otherlv_7= 'correo' this_EQUALS_8= RULE_EQUALS ( (lv_correo_9_0= ruleEString ) ) this_SEMICOLON_10= RULE_SEMICOLON )? this_OBJECT_END_11= RULE_OBJECT_END ) ;
    public final EObject ruleAutenticacionUsuario_Impl() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token this_OBJECT_START_2=null;
        Token otherlv_3=null;
        Token this_EQUALS_4=null;
        Token this_SEMICOLON_6=null;
        Token otherlv_7=null;
        Token this_EQUALS_8=null;
        Token this_SEMICOLON_10=null;
        Token this_OBJECT_END_11=null;
        AntlrDatatypeRuleToken lv_usuario_5_0 = null;

        AntlrDatatypeRuleToken lv_correo_9_0 = null;



        	enterRule();

        try {
            // InternalCeffective.g:389:2: ( ( () otherlv_1= 'AutenticacionUsuario' this_OBJECT_START_2= RULE_OBJECT_START (otherlv_3= 'usuario' this_EQUALS_4= RULE_EQUALS ( (lv_usuario_5_0= ruleEString ) ) this_SEMICOLON_6= RULE_SEMICOLON )? (otherlv_7= 'correo' this_EQUALS_8= RULE_EQUALS ( (lv_correo_9_0= ruleEString ) ) this_SEMICOLON_10= RULE_SEMICOLON )? this_OBJECT_END_11= RULE_OBJECT_END ) )
            // InternalCeffective.g:390:2: ( () otherlv_1= 'AutenticacionUsuario' this_OBJECT_START_2= RULE_OBJECT_START (otherlv_3= 'usuario' this_EQUALS_4= RULE_EQUALS ( (lv_usuario_5_0= ruleEString ) ) this_SEMICOLON_6= RULE_SEMICOLON )? (otherlv_7= 'correo' this_EQUALS_8= RULE_EQUALS ( (lv_correo_9_0= ruleEString ) ) this_SEMICOLON_10= RULE_SEMICOLON )? this_OBJECT_END_11= RULE_OBJECT_END )
            {
            // InternalCeffective.g:390:2: ( () otherlv_1= 'AutenticacionUsuario' this_OBJECT_START_2= RULE_OBJECT_START (otherlv_3= 'usuario' this_EQUALS_4= RULE_EQUALS ( (lv_usuario_5_0= ruleEString ) ) this_SEMICOLON_6= RULE_SEMICOLON )? (otherlv_7= 'correo' this_EQUALS_8= RULE_EQUALS ( (lv_correo_9_0= ruleEString ) ) this_SEMICOLON_10= RULE_SEMICOLON )? this_OBJECT_END_11= RULE_OBJECT_END )
            // InternalCeffective.g:391:3: () otherlv_1= 'AutenticacionUsuario' this_OBJECT_START_2= RULE_OBJECT_START (otherlv_3= 'usuario' this_EQUALS_4= RULE_EQUALS ( (lv_usuario_5_0= ruleEString ) ) this_SEMICOLON_6= RULE_SEMICOLON )? (otherlv_7= 'correo' this_EQUALS_8= RULE_EQUALS ( (lv_correo_9_0= ruleEString ) ) this_SEMICOLON_10= RULE_SEMICOLON )? this_OBJECT_END_11= RULE_OBJECT_END
            {
            // InternalCeffective.g:391:3: ()
            // InternalCeffective.g:392:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getAutenticacionUsuario_ImplAccess().getAutenticacionUsuarioAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,23,FOLLOW_4); 

            			newLeafNode(otherlv_1, grammarAccess.getAutenticacionUsuario_ImplAccess().getAutenticacionUsuarioKeyword_1());
            		
            this_OBJECT_START_2=(Token)match(input,RULE_OBJECT_START,FOLLOW_17); 

            			newLeafNode(this_OBJECT_START_2, grammarAccess.getAutenticacionUsuario_ImplAccess().getOBJECT_STARTTerminalRuleCall_2());
            		
            // InternalCeffective.g:406:3: (otherlv_3= 'usuario' this_EQUALS_4= RULE_EQUALS ( (lv_usuario_5_0= ruleEString ) ) this_SEMICOLON_6= RULE_SEMICOLON )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==24) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalCeffective.g:407:4: otherlv_3= 'usuario' this_EQUALS_4= RULE_EQUALS ( (lv_usuario_5_0= ruleEString ) ) this_SEMICOLON_6= RULE_SEMICOLON
                    {
                    otherlv_3=(Token)match(input,24,FOLLOW_6); 

                    				newLeafNode(otherlv_3, grammarAccess.getAutenticacionUsuario_ImplAccess().getUsuarioKeyword_3_0());
                    			
                    this_EQUALS_4=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_4, grammarAccess.getAutenticacionUsuario_ImplAccess().getEQUALSTerminalRuleCall_3_1());
                    			
                    // InternalCeffective.g:415:4: ( (lv_usuario_5_0= ruleEString ) )
                    // InternalCeffective.g:416:5: (lv_usuario_5_0= ruleEString )
                    {
                    // InternalCeffective.g:416:5: (lv_usuario_5_0= ruleEString )
                    // InternalCeffective.g:417:6: lv_usuario_5_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getAutenticacionUsuario_ImplAccess().getUsuarioEStringParserRuleCall_3_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_usuario_5_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getAutenticacionUsuario_ImplRule());
                    						}
                    						set(
                    							current,
                    							"usuario",
                    							lv_usuario_5_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_18); 

                    				newLeafNode(this_SEMICOLON_6, grammarAccess.getAutenticacionUsuario_ImplAccess().getSEMICOLONTerminalRuleCall_3_3());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:439:3: (otherlv_7= 'correo' this_EQUALS_8= RULE_EQUALS ( (lv_correo_9_0= ruleEString ) ) this_SEMICOLON_10= RULE_SEMICOLON )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==25) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalCeffective.g:440:4: otherlv_7= 'correo' this_EQUALS_8= RULE_EQUALS ( (lv_correo_9_0= ruleEString ) ) this_SEMICOLON_10= RULE_SEMICOLON
                    {
                    otherlv_7=(Token)match(input,25,FOLLOW_6); 

                    				newLeafNode(otherlv_7, grammarAccess.getAutenticacionUsuario_ImplAccess().getCorreoKeyword_4_0());
                    			
                    this_EQUALS_8=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_8, grammarAccess.getAutenticacionUsuario_ImplAccess().getEQUALSTerminalRuleCall_4_1());
                    			
                    // InternalCeffective.g:448:4: ( (lv_correo_9_0= ruleEString ) )
                    // InternalCeffective.g:449:5: (lv_correo_9_0= ruleEString )
                    {
                    // InternalCeffective.g:449:5: (lv_correo_9_0= ruleEString )
                    // InternalCeffective.g:450:6: lv_correo_9_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getAutenticacionUsuario_ImplAccess().getCorreoEStringParserRuleCall_4_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_correo_9_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getAutenticacionUsuario_ImplRule());
                    						}
                    						set(
                    							current,
                    							"correo",
                    							lv_correo_9_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_10=(Token)match(input,RULE_SEMICOLON,FOLLOW_8); 

                    				newLeafNode(this_SEMICOLON_10, grammarAccess.getAutenticacionUsuario_ImplAccess().getSEMICOLONTerminalRuleCall_4_3());
                    			

                    }
                    break;

            }

            this_OBJECT_END_11=(Token)match(input,RULE_OBJECT_END,FOLLOW_2); 

            			newLeafNode(this_OBJECT_END_11, grammarAccess.getAutenticacionUsuario_ImplAccess().getOBJECT_ENDTerminalRuleCall_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAutenticacionUsuario_Impl"


    // $ANTLR start "entryRuleAutenticacionBasica"
    // InternalCeffective.g:480:1: entryRuleAutenticacionBasica returns [EObject current=null] : iv_ruleAutenticacionBasica= ruleAutenticacionBasica EOF ;
    public final EObject entryRuleAutenticacionBasica() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAutenticacionBasica = null;


        try {
            // InternalCeffective.g:480:60: (iv_ruleAutenticacionBasica= ruleAutenticacionBasica EOF )
            // InternalCeffective.g:481:2: iv_ruleAutenticacionBasica= ruleAutenticacionBasica EOF
            {
             newCompositeNode(grammarAccess.getAutenticacionBasicaRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAutenticacionBasica=ruleAutenticacionBasica();

            state._fsp--;

             current =iv_ruleAutenticacionBasica; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAutenticacionBasica"


    // $ANTLR start "ruleAutenticacionBasica"
    // InternalCeffective.g:487:1: ruleAutenticacionBasica returns [EObject current=null] : ( () this_OBJECT_START_1= RULE_OBJECT_START (otherlv_2= 'usuario' this_EQUALS_3= RULE_EQUALS ( (lv_usuario_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON )? otherlv_6= 'correo' this_EQUALS_7= RULE_EQUALS ( (lv_correo_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON (otherlv_10= 'password' this_EQUALS_11= RULE_EQUALS ( (lv_password_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? this_OBJECT_END_14= RULE_OBJECT_END ) ;
    public final EObject ruleAutenticacionBasica() throws RecognitionException {
        EObject current = null;

        Token this_OBJECT_START_1=null;
        Token otherlv_2=null;
        Token this_EQUALS_3=null;
        Token this_SEMICOLON_5=null;
        Token otherlv_6=null;
        Token this_EQUALS_7=null;
        Token this_SEMICOLON_9=null;
        Token otherlv_10=null;
        Token this_EQUALS_11=null;
        Token this_SEMICOLON_13=null;
        Token this_OBJECT_END_14=null;
        AntlrDatatypeRuleToken lv_usuario_4_0 = null;

        AntlrDatatypeRuleToken lv_correo_8_0 = null;

        AntlrDatatypeRuleToken lv_password_12_0 = null;



        	enterRule();

        try {
            // InternalCeffective.g:493:2: ( ( () this_OBJECT_START_1= RULE_OBJECT_START (otherlv_2= 'usuario' this_EQUALS_3= RULE_EQUALS ( (lv_usuario_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON )? otherlv_6= 'correo' this_EQUALS_7= RULE_EQUALS ( (lv_correo_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON (otherlv_10= 'password' this_EQUALS_11= RULE_EQUALS ( (lv_password_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? this_OBJECT_END_14= RULE_OBJECT_END ) )
            // InternalCeffective.g:494:2: ( () this_OBJECT_START_1= RULE_OBJECT_START (otherlv_2= 'usuario' this_EQUALS_3= RULE_EQUALS ( (lv_usuario_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON )? otherlv_6= 'correo' this_EQUALS_7= RULE_EQUALS ( (lv_correo_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON (otherlv_10= 'password' this_EQUALS_11= RULE_EQUALS ( (lv_password_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? this_OBJECT_END_14= RULE_OBJECT_END )
            {
            // InternalCeffective.g:494:2: ( () this_OBJECT_START_1= RULE_OBJECT_START (otherlv_2= 'usuario' this_EQUALS_3= RULE_EQUALS ( (lv_usuario_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON )? otherlv_6= 'correo' this_EQUALS_7= RULE_EQUALS ( (lv_correo_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON (otherlv_10= 'password' this_EQUALS_11= RULE_EQUALS ( (lv_password_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? this_OBJECT_END_14= RULE_OBJECT_END )
            // InternalCeffective.g:495:3: () this_OBJECT_START_1= RULE_OBJECT_START (otherlv_2= 'usuario' this_EQUALS_3= RULE_EQUALS ( (lv_usuario_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON )? otherlv_6= 'correo' this_EQUALS_7= RULE_EQUALS ( (lv_correo_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON (otherlv_10= 'password' this_EQUALS_11= RULE_EQUALS ( (lv_password_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? this_OBJECT_END_14= RULE_OBJECT_END
            {
            // InternalCeffective.g:495:3: ()
            // InternalCeffective.g:496:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getAutenticacionBasicaAccess().getAutenticacionBasicaAction_0(),
            					current);
            			

            }

            this_OBJECT_START_1=(Token)match(input,RULE_OBJECT_START,FOLLOW_19); 

            			newLeafNode(this_OBJECT_START_1, grammarAccess.getAutenticacionBasicaAccess().getOBJECT_STARTTerminalRuleCall_1());
            		
            // InternalCeffective.g:506:3: (otherlv_2= 'usuario' this_EQUALS_3= RULE_EQUALS ( (lv_usuario_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==24) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalCeffective.g:507:4: otherlv_2= 'usuario' this_EQUALS_3= RULE_EQUALS ( (lv_usuario_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON
                    {
                    otherlv_2=(Token)match(input,24,FOLLOW_6); 

                    				newLeafNode(otherlv_2, grammarAccess.getAutenticacionBasicaAccess().getUsuarioKeyword_2_0());
                    			
                    this_EQUALS_3=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_3, grammarAccess.getAutenticacionBasicaAccess().getEQUALSTerminalRuleCall_2_1());
                    			
                    // InternalCeffective.g:515:4: ( (lv_usuario_4_0= ruleEString ) )
                    // InternalCeffective.g:516:5: (lv_usuario_4_0= ruleEString )
                    {
                    // InternalCeffective.g:516:5: (lv_usuario_4_0= ruleEString )
                    // InternalCeffective.g:517:6: lv_usuario_4_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getAutenticacionBasicaAccess().getUsuarioEStringParserRuleCall_2_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_usuario_4_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getAutenticacionBasicaRule());
                    						}
                    						set(
                    							current,
                    							"usuario",
                    							lv_usuario_4_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_5=(Token)match(input,RULE_SEMICOLON,FOLLOW_20); 

                    				newLeafNode(this_SEMICOLON_5, grammarAccess.getAutenticacionBasicaAccess().getSEMICOLONTerminalRuleCall_2_3());
                    			

                    }
                    break;

            }

            otherlv_6=(Token)match(input,25,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getAutenticacionBasicaAccess().getCorreoKeyword_3());
            		
            this_EQUALS_7=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

            			newLeafNode(this_EQUALS_7, grammarAccess.getAutenticacionBasicaAccess().getEQUALSTerminalRuleCall_4());
            		
            // InternalCeffective.g:547:3: ( (lv_correo_8_0= ruleEString ) )
            // InternalCeffective.g:548:4: (lv_correo_8_0= ruleEString )
            {
            // InternalCeffective.g:548:4: (lv_correo_8_0= ruleEString )
            // InternalCeffective.g:549:5: lv_correo_8_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getAutenticacionBasicaAccess().getCorreoEStringParserRuleCall_5_0());
            				
            pushFollow(FOLLOW_7);
            lv_correo_8_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getAutenticacionBasicaRule());
            					}
            					set(
            						current,
            						"correo",
            						lv_correo_8_0,
            						"org.xtext.example.ceffective.Ceffective.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_21); 

            			newLeafNode(this_SEMICOLON_9, grammarAccess.getAutenticacionBasicaAccess().getSEMICOLONTerminalRuleCall_6());
            		
            // InternalCeffective.g:570:3: (otherlv_10= 'password' this_EQUALS_11= RULE_EQUALS ( (lv_password_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==26) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalCeffective.g:571:4: otherlv_10= 'password' this_EQUALS_11= RULE_EQUALS ( (lv_password_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON
                    {
                    otherlv_10=(Token)match(input,26,FOLLOW_6); 

                    				newLeafNode(otherlv_10, grammarAccess.getAutenticacionBasicaAccess().getPasswordKeyword_7_0());
                    			
                    this_EQUALS_11=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_11, grammarAccess.getAutenticacionBasicaAccess().getEQUALSTerminalRuleCall_7_1());
                    			
                    // InternalCeffective.g:579:4: ( (lv_password_12_0= ruleEString ) )
                    // InternalCeffective.g:580:5: (lv_password_12_0= ruleEString )
                    {
                    // InternalCeffective.g:580:5: (lv_password_12_0= ruleEString )
                    // InternalCeffective.g:581:6: lv_password_12_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getAutenticacionBasicaAccess().getPasswordEStringParserRuleCall_7_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_password_12_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getAutenticacionBasicaRule());
                    						}
                    						set(
                    							current,
                    							"password",
                    							lv_password_12_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_13=(Token)match(input,RULE_SEMICOLON,FOLLOW_8); 

                    				newLeafNode(this_SEMICOLON_13, grammarAccess.getAutenticacionBasicaAccess().getSEMICOLONTerminalRuleCall_7_3());
                    			

                    }
                    break;

            }

            this_OBJECT_END_14=(Token)match(input,RULE_OBJECT_END,FOLLOW_2); 

            			newLeafNode(this_OBJECT_END_14, grammarAccess.getAutenticacionBasicaAccess().getOBJECT_ENDTerminalRuleCall_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAutenticacionBasica"


    // $ANTLR start "entryRuleAutenticacionFirma"
    // InternalCeffective.g:611:1: entryRuleAutenticacionFirma returns [EObject current=null] : iv_ruleAutenticacionFirma= ruleAutenticacionFirma EOF ;
    public final EObject entryRuleAutenticacionFirma() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAutenticacionFirma = null;


        try {
            // InternalCeffective.g:611:59: (iv_ruleAutenticacionFirma= ruleAutenticacionFirma EOF )
            // InternalCeffective.g:612:2: iv_ruleAutenticacionFirma= ruleAutenticacionFirma EOF
            {
             newCompositeNode(grammarAccess.getAutenticacionFirmaRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAutenticacionFirma=ruleAutenticacionFirma();

            state._fsp--;

             current =iv_ruleAutenticacionFirma; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAutenticacionFirma"


    // $ANTLR start "ruleAutenticacionFirma"
    // InternalCeffective.g:618:1: ruleAutenticacionFirma returns [EObject current=null] : ( () this_OBJECT_START_1= RULE_OBJECT_START otherlv_2= 'accessId' this_EQUALS_3= RULE_EQUALS ( (lv_accessId_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON otherlv_6= 'secret' this_EQUALS_7= RULE_EQUALS ( (lv_secret_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON (otherlv_10= 'usuario' this_EQUALS_11= RULE_EQUALS ( (lv_usuario_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? (otherlv_14= 'correo' this_EQUALS_15= RULE_EQUALS ( (lv_correo_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON )? this_OBJECT_END_18= RULE_OBJECT_END ) ;
    public final EObject ruleAutenticacionFirma() throws RecognitionException {
        EObject current = null;

        Token this_OBJECT_START_1=null;
        Token otherlv_2=null;
        Token this_EQUALS_3=null;
        Token this_SEMICOLON_5=null;
        Token otherlv_6=null;
        Token this_EQUALS_7=null;
        Token this_SEMICOLON_9=null;
        Token otherlv_10=null;
        Token this_EQUALS_11=null;
        Token this_SEMICOLON_13=null;
        Token otherlv_14=null;
        Token this_EQUALS_15=null;
        Token this_SEMICOLON_17=null;
        Token this_OBJECT_END_18=null;
        AntlrDatatypeRuleToken lv_accessId_4_0 = null;

        AntlrDatatypeRuleToken lv_secret_8_0 = null;

        AntlrDatatypeRuleToken lv_usuario_12_0 = null;

        AntlrDatatypeRuleToken lv_correo_16_0 = null;



        	enterRule();

        try {
            // InternalCeffective.g:624:2: ( ( () this_OBJECT_START_1= RULE_OBJECT_START otherlv_2= 'accessId' this_EQUALS_3= RULE_EQUALS ( (lv_accessId_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON otherlv_6= 'secret' this_EQUALS_7= RULE_EQUALS ( (lv_secret_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON (otherlv_10= 'usuario' this_EQUALS_11= RULE_EQUALS ( (lv_usuario_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? (otherlv_14= 'correo' this_EQUALS_15= RULE_EQUALS ( (lv_correo_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON )? this_OBJECT_END_18= RULE_OBJECT_END ) )
            // InternalCeffective.g:625:2: ( () this_OBJECT_START_1= RULE_OBJECT_START otherlv_2= 'accessId' this_EQUALS_3= RULE_EQUALS ( (lv_accessId_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON otherlv_6= 'secret' this_EQUALS_7= RULE_EQUALS ( (lv_secret_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON (otherlv_10= 'usuario' this_EQUALS_11= RULE_EQUALS ( (lv_usuario_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? (otherlv_14= 'correo' this_EQUALS_15= RULE_EQUALS ( (lv_correo_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON )? this_OBJECT_END_18= RULE_OBJECT_END )
            {
            // InternalCeffective.g:625:2: ( () this_OBJECT_START_1= RULE_OBJECT_START otherlv_2= 'accessId' this_EQUALS_3= RULE_EQUALS ( (lv_accessId_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON otherlv_6= 'secret' this_EQUALS_7= RULE_EQUALS ( (lv_secret_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON (otherlv_10= 'usuario' this_EQUALS_11= RULE_EQUALS ( (lv_usuario_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? (otherlv_14= 'correo' this_EQUALS_15= RULE_EQUALS ( (lv_correo_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON )? this_OBJECT_END_18= RULE_OBJECT_END )
            // InternalCeffective.g:626:3: () this_OBJECT_START_1= RULE_OBJECT_START otherlv_2= 'accessId' this_EQUALS_3= RULE_EQUALS ( (lv_accessId_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON otherlv_6= 'secret' this_EQUALS_7= RULE_EQUALS ( (lv_secret_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON (otherlv_10= 'usuario' this_EQUALS_11= RULE_EQUALS ( (lv_usuario_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? (otherlv_14= 'correo' this_EQUALS_15= RULE_EQUALS ( (lv_correo_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON )? this_OBJECT_END_18= RULE_OBJECT_END
            {
            // InternalCeffective.g:626:3: ()
            // InternalCeffective.g:627:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getAutenticacionFirmaAccess().getAutenticacionFirmaAction_0(),
            					current);
            			

            }

            this_OBJECT_START_1=(Token)match(input,RULE_OBJECT_START,FOLLOW_22); 

            			newLeafNode(this_OBJECT_START_1, grammarAccess.getAutenticacionFirmaAccess().getOBJECT_STARTTerminalRuleCall_1());
            		
            otherlv_2=(Token)match(input,27,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getAutenticacionFirmaAccess().getAccessIdKeyword_2());
            		
            this_EQUALS_3=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

            			newLeafNode(this_EQUALS_3, grammarAccess.getAutenticacionFirmaAccess().getEQUALSTerminalRuleCall_3());
            		
            // InternalCeffective.g:645:3: ( (lv_accessId_4_0= ruleEString ) )
            // InternalCeffective.g:646:4: (lv_accessId_4_0= ruleEString )
            {
            // InternalCeffective.g:646:4: (lv_accessId_4_0= ruleEString )
            // InternalCeffective.g:647:5: lv_accessId_4_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getAutenticacionFirmaAccess().getAccessIdEStringParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_7);
            lv_accessId_4_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getAutenticacionFirmaRule());
            					}
            					set(
            						current,
            						"accessId",
            						lv_accessId_4_0,
            						"org.xtext.example.ceffective.Ceffective.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_SEMICOLON_5=(Token)match(input,RULE_SEMICOLON,FOLLOW_23); 

            			newLeafNode(this_SEMICOLON_5, grammarAccess.getAutenticacionFirmaAccess().getSEMICOLONTerminalRuleCall_5());
            		
            otherlv_6=(Token)match(input,28,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getAutenticacionFirmaAccess().getSecretKeyword_6());
            		
            this_EQUALS_7=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

            			newLeafNode(this_EQUALS_7, grammarAccess.getAutenticacionFirmaAccess().getEQUALSTerminalRuleCall_7());
            		
            // InternalCeffective.g:676:3: ( (lv_secret_8_0= ruleEString ) )
            // InternalCeffective.g:677:4: (lv_secret_8_0= ruleEString )
            {
            // InternalCeffective.g:677:4: (lv_secret_8_0= ruleEString )
            // InternalCeffective.g:678:5: lv_secret_8_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getAutenticacionFirmaAccess().getSecretEStringParserRuleCall_8_0());
            				
            pushFollow(FOLLOW_7);
            lv_secret_8_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getAutenticacionFirmaRule());
            					}
            					set(
            						current,
            						"secret",
            						lv_secret_8_0,
            						"org.xtext.example.ceffective.Ceffective.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_17); 

            			newLeafNode(this_SEMICOLON_9, grammarAccess.getAutenticacionFirmaAccess().getSEMICOLONTerminalRuleCall_9());
            		
            // InternalCeffective.g:699:3: (otherlv_10= 'usuario' this_EQUALS_11= RULE_EQUALS ( (lv_usuario_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==24) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // InternalCeffective.g:700:4: otherlv_10= 'usuario' this_EQUALS_11= RULE_EQUALS ( (lv_usuario_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON
                    {
                    otherlv_10=(Token)match(input,24,FOLLOW_6); 

                    				newLeafNode(otherlv_10, grammarAccess.getAutenticacionFirmaAccess().getUsuarioKeyword_10_0());
                    			
                    this_EQUALS_11=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_11, grammarAccess.getAutenticacionFirmaAccess().getEQUALSTerminalRuleCall_10_1());
                    			
                    // InternalCeffective.g:708:4: ( (lv_usuario_12_0= ruleEString ) )
                    // InternalCeffective.g:709:5: (lv_usuario_12_0= ruleEString )
                    {
                    // InternalCeffective.g:709:5: (lv_usuario_12_0= ruleEString )
                    // InternalCeffective.g:710:6: lv_usuario_12_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getAutenticacionFirmaAccess().getUsuarioEStringParserRuleCall_10_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_usuario_12_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getAutenticacionFirmaRule());
                    						}
                    						set(
                    							current,
                    							"usuario",
                    							lv_usuario_12_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_13=(Token)match(input,RULE_SEMICOLON,FOLLOW_18); 

                    				newLeafNode(this_SEMICOLON_13, grammarAccess.getAutenticacionFirmaAccess().getSEMICOLONTerminalRuleCall_10_3());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:732:3: (otherlv_14= 'correo' this_EQUALS_15= RULE_EQUALS ( (lv_correo_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==25) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalCeffective.g:733:4: otherlv_14= 'correo' this_EQUALS_15= RULE_EQUALS ( (lv_correo_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON
                    {
                    otherlv_14=(Token)match(input,25,FOLLOW_6); 

                    				newLeafNode(otherlv_14, grammarAccess.getAutenticacionFirmaAccess().getCorreoKeyword_11_0());
                    			
                    this_EQUALS_15=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_15, grammarAccess.getAutenticacionFirmaAccess().getEQUALSTerminalRuleCall_11_1());
                    			
                    // InternalCeffective.g:741:4: ( (lv_correo_16_0= ruleEString ) )
                    // InternalCeffective.g:742:5: (lv_correo_16_0= ruleEString )
                    {
                    // InternalCeffective.g:742:5: (lv_correo_16_0= ruleEString )
                    // InternalCeffective.g:743:6: lv_correo_16_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getAutenticacionFirmaAccess().getCorreoEStringParserRuleCall_11_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_correo_16_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getAutenticacionFirmaRule());
                    						}
                    						set(
                    							current,
                    							"correo",
                    							lv_correo_16_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_17=(Token)match(input,RULE_SEMICOLON,FOLLOW_8); 

                    				newLeafNode(this_SEMICOLON_17, grammarAccess.getAutenticacionFirmaAccess().getSEMICOLONTerminalRuleCall_11_3());
                    			

                    }
                    break;

            }

            this_OBJECT_END_18=(Token)match(input,RULE_OBJECT_END,FOLLOW_2); 

            			newLeafNode(this_OBJECT_END_18, grammarAccess.getAutenticacionFirmaAccess().getOBJECT_ENDTerminalRuleCall_12());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAutenticacionFirma"


    // $ANTLR start "entryRuleAmbienteDespliegue"
    // InternalCeffective.g:773:1: entryRuleAmbienteDespliegue returns [EObject current=null] : iv_ruleAmbienteDespliegue= ruleAmbienteDespliegue EOF ;
    public final EObject entryRuleAmbienteDespliegue() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAmbienteDespliegue = null;


        try {
            // InternalCeffective.g:773:59: (iv_ruleAmbienteDespliegue= ruleAmbienteDespliegue EOF )
            // InternalCeffective.g:774:2: iv_ruleAmbienteDespliegue= ruleAmbienteDespliegue EOF
            {
             newCompositeNode(grammarAccess.getAmbienteDespliegueRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAmbienteDespliegue=ruleAmbienteDespliegue();

            state._fsp--;

             current =iv_ruleAmbienteDespliegue; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAmbienteDespliegue"


    // $ANTLR start "ruleAmbienteDespliegue"
    // InternalCeffective.g:780:1: ruleAmbienteDespliegue returns [EObject current=null] : ( () this_OBJECT_START_1= RULE_OBJECT_START (otherlv_2= 'ambiente' this_EQUALS_3= RULE_EQUALS ( (lv_ambiente_4_0= ruleTipoAmbiente ) ) this_SEMICOLON_5= RULE_SEMICOLON )? (otherlv_6= 'nombre' this_EQUALS_7= RULE_EQUALS ( (lv_nombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'vpcs' this_EQUALS_11= RULE_EQUALS this_LIST_START_12= RULE_LIST_START ( (lv_vpc_13_0= ruleVPC ) ) (this_COMA_14= RULE_COMA ( (lv_vpc_15_0= ruleVPC ) ) )* this_LIST_END_16= RULE_LIST_END )? (otherlv_17= 'securityresource' this_EQUALS_18= RULE_EQUALS this_LIST_START_19= RULE_LIST_START ( (lv_mecanismoseguridad_20_0= ruleMecanismoSeguridad ) ) (this_COMA_21= RULE_COMA ( (lv_mecanismoseguridad_22_0= ruleMecanismoSeguridad ) ) )* this_LIST_END_23= RULE_LIST_END )? (otherlv_24= 'recursos' this_EQUALS_25= RULE_EQUALS this_LIST_START_26= RULE_LIST_START ( (lv_recursos_27_0= ruleRecurso ) ) (this_COMA_28= RULE_COMA ( (lv_recursos_29_0= ruleRecurso ) ) )* this_LIST_END_30= RULE_LIST_END )? (otherlv_31= 'conexiones' this_EQUALS_32= RULE_EQUALS this_LIST_START_33= RULE_LIST_START ruleConexion (this_COMA_35= RULE_COMA ruleConexion )* this_LIST_END_37= RULE_LIST_END )? this_OBJECT_END_38= RULE_OBJECT_END ) ;
    public final EObject ruleAmbienteDespliegue() throws RecognitionException {
        EObject current = null;

        Token this_OBJECT_START_1=null;
        Token otherlv_2=null;
        Token this_EQUALS_3=null;
        Token this_SEMICOLON_5=null;
        Token otherlv_6=null;
        Token this_EQUALS_7=null;
        Token this_SEMICOLON_9=null;
        Token otherlv_10=null;
        Token this_EQUALS_11=null;
        Token this_LIST_START_12=null;
        Token this_COMA_14=null;
        Token this_LIST_END_16=null;
        Token otherlv_17=null;
        Token this_EQUALS_18=null;
        Token this_LIST_START_19=null;
        Token this_COMA_21=null;
        Token this_LIST_END_23=null;
        Token otherlv_24=null;
        Token this_EQUALS_25=null;
        Token this_LIST_START_26=null;
        Token this_COMA_28=null;
        Token this_LIST_END_30=null;
        Token otherlv_31=null;
        Token this_EQUALS_32=null;
        Token this_LIST_START_33=null;
        Token this_COMA_35=null;
        Token this_LIST_END_37=null;
        Token this_OBJECT_END_38=null;
        Enumerator lv_ambiente_4_0 = null;

        AntlrDatatypeRuleToken lv_nombre_8_0 = null;

        EObject lv_vpc_13_0 = null;

        EObject lv_vpc_15_0 = null;

        EObject lv_mecanismoseguridad_20_0 = null;

        EObject lv_mecanismoseguridad_22_0 = null;

        EObject lv_recursos_27_0 = null;

        EObject lv_recursos_29_0 = null;



        	enterRule();

        try {
            // InternalCeffective.g:786:2: ( ( () this_OBJECT_START_1= RULE_OBJECT_START (otherlv_2= 'ambiente' this_EQUALS_3= RULE_EQUALS ( (lv_ambiente_4_0= ruleTipoAmbiente ) ) this_SEMICOLON_5= RULE_SEMICOLON )? (otherlv_6= 'nombre' this_EQUALS_7= RULE_EQUALS ( (lv_nombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'vpcs' this_EQUALS_11= RULE_EQUALS this_LIST_START_12= RULE_LIST_START ( (lv_vpc_13_0= ruleVPC ) ) (this_COMA_14= RULE_COMA ( (lv_vpc_15_0= ruleVPC ) ) )* this_LIST_END_16= RULE_LIST_END )? (otherlv_17= 'securityresource' this_EQUALS_18= RULE_EQUALS this_LIST_START_19= RULE_LIST_START ( (lv_mecanismoseguridad_20_0= ruleMecanismoSeguridad ) ) (this_COMA_21= RULE_COMA ( (lv_mecanismoseguridad_22_0= ruleMecanismoSeguridad ) ) )* this_LIST_END_23= RULE_LIST_END )? (otherlv_24= 'recursos' this_EQUALS_25= RULE_EQUALS this_LIST_START_26= RULE_LIST_START ( (lv_recursos_27_0= ruleRecurso ) ) (this_COMA_28= RULE_COMA ( (lv_recursos_29_0= ruleRecurso ) ) )* this_LIST_END_30= RULE_LIST_END )? (otherlv_31= 'conexiones' this_EQUALS_32= RULE_EQUALS this_LIST_START_33= RULE_LIST_START ruleConexion (this_COMA_35= RULE_COMA ruleConexion )* this_LIST_END_37= RULE_LIST_END )? this_OBJECT_END_38= RULE_OBJECT_END ) )
            // InternalCeffective.g:787:2: ( () this_OBJECT_START_1= RULE_OBJECT_START (otherlv_2= 'ambiente' this_EQUALS_3= RULE_EQUALS ( (lv_ambiente_4_0= ruleTipoAmbiente ) ) this_SEMICOLON_5= RULE_SEMICOLON )? (otherlv_6= 'nombre' this_EQUALS_7= RULE_EQUALS ( (lv_nombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'vpcs' this_EQUALS_11= RULE_EQUALS this_LIST_START_12= RULE_LIST_START ( (lv_vpc_13_0= ruleVPC ) ) (this_COMA_14= RULE_COMA ( (lv_vpc_15_0= ruleVPC ) ) )* this_LIST_END_16= RULE_LIST_END )? (otherlv_17= 'securityresource' this_EQUALS_18= RULE_EQUALS this_LIST_START_19= RULE_LIST_START ( (lv_mecanismoseguridad_20_0= ruleMecanismoSeguridad ) ) (this_COMA_21= RULE_COMA ( (lv_mecanismoseguridad_22_0= ruleMecanismoSeguridad ) ) )* this_LIST_END_23= RULE_LIST_END )? (otherlv_24= 'recursos' this_EQUALS_25= RULE_EQUALS this_LIST_START_26= RULE_LIST_START ( (lv_recursos_27_0= ruleRecurso ) ) (this_COMA_28= RULE_COMA ( (lv_recursos_29_0= ruleRecurso ) ) )* this_LIST_END_30= RULE_LIST_END )? (otherlv_31= 'conexiones' this_EQUALS_32= RULE_EQUALS this_LIST_START_33= RULE_LIST_START ruleConexion (this_COMA_35= RULE_COMA ruleConexion )* this_LIST_END_37= RULE_LIST_END )? this_OBJECT_END_38= RULE_OBJECT_END )
            {
            // InternalCeffective.g:787:2: ( () this_OBJECT_START_1= RULE_OBJECT_START (otherlv_2= 'ambiente' this_EQUALS_3= RULE_EQUALS ( (lv_ambiente_4_0= ruleTipoAmbiente ) ) this_SEMICOLON_5= RULE_SEMICOLON )? (otherlv_6= 'nombre' this_EQUALS_7= RULE_EQUALS ( (lv_nombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'vpcs' this_EQUALS_11= RULE_EQUALS this_LIST_START_12= RULE_LIST_START ( (lv_vpc_13_0= ruleVPC ) ) (this_COMA_14= RULE_COMA ( (lv_vpc_15_0= ruleVPC ) ) )* this_LIST_END_16= RULE_LIST_END )? (otherlv_17= 'securityresource' this_EQUALS_18= RULE_EQUALS this_LIST_START_19= RULE_LIST_START ( (lv_mecanismoseguridad_20_0= ruleMecanismoSeguridad ) ) (this_COMA_21= RULE_COMA ( (lv_mecanismoseguridad_22_0= ruleMecanismoSeguridad ) ) )* this_LIST_END_23= RULE_LIST_END )? (otherlv_24= 'recursos' this_EQUALS_25= RULE_EQUALS this_LIST_START_26= RULE_LIST_START ( (lv_recursos_27_0= ruleRecurso ) ) (this_COMA_28= RULE_COMA ( (lv_recursos_29_0= ruleRecurso ) ) )* this_LIST_END_30= RULE_LIST_END )? (otherlv_31= 'conexiones' this_EQUALS_32= RULE_EQUALS this_LIST_START_33= RULE_LIST_START ruleConexion (this_COMA_35= RULE_COMA ruleConexion )* this_LIST_END_37= RULE_LIST_END )? this_OBJECT_END_38= RULE_OBJECT_END )
            // InternalCeffective.g:788:3: () this_OBJECT_START_1= RULE_OBJECT_START (otherlv_2= 'ambiente' this_EQUALS_3= RULE_EQUALS ( (lv_ambiente_4_0= ruleTipoAmbiente ) ) this_SEMICOLON_5= RULE_SEMICOLON )? (otherlv_6= 'nombre' this_EQUALS_7= RULE_EQUALS ( (lv_nombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'vpcs' this_EQUALS_11= RULE_EQUALS this_LIST_START_12= RULE_LIST_START ( (lv_vpc_13_0= ruleVPC ) ) (this_COMA_14= RULE_COMA ( (lv_vpc_15_0= ruleVPC ) ) )* this_LIST_END_16= RULE_LIST_END )? (otherlv_17= 'securityresource' this_EQUALS_18= RULE_EQUALS this_LIST_START_19= RULE_LIST_START ( (lv_mecanismoseguridad_20_0= ruleMecanismoSeguridad ) ) (this_COMA_21= RULE_COMA ( (lv_mecanismoseguridad_22_0= ruleMecanismoSeguridad ) ) )* this_LIST_END_23= RULE_LIST_END )? (otherlv_24= 'recursos' this_EQUALS_25= RULE_EQUALS this_LIST_START_26= RULE_LIST_START ( (lv_recursos_27_0= ruleRecurso ) ) (this_COMA_28= RULE_COMA ( (lv_recursos_29_0= ruleRecurso ) ) )* this_LIST_END_30= RULE_LIST_END )? (otherlv_31= 'conexiones' this_EQUALS_32= RULE_EQUALS this_LIST_START_33= RULE_LIST_START ruleConexion (this_COMA_35= RULE_COMA ruleConexion )* this_LIST_END_37= RULE_LIST_END )? this_OBJECT_END_38= RULE_OBJECT_END
            {
            // InternalCeffective.g:788:3: ()
            // InternalCeffective.g:789:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getAmbienteDespliegueAccess().getAmbienteDespliegueAction_0(),
            					current);
            			

            }

            this_OBJECT_START_1=(Token)match(input,RULE_OBJECT_START,FOLLOW_24); 

            			newLeafNode(this_OBJECT_START_1, grammarAccess.getAmbienteDespliegueAccess().getOBJECT_STARTTerminalRuleCall_1());
            		
            // InternalCeffective.g:799:3: (otherlv_2= 'ambiente' this_EQUALS_3= RULE_EQUALS ( (lv_ambiente_4_0= ruleTipoAmbiente ) ) this_SEMICOLON_5= RULE_SEMICOLON )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==29) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalCeffective.g:800:4: otherlv_2= 'ambiente' this_EQUALS_3= RULE_EQUALS ( (lv_ambiente_4_0= ruleTipoAmbiente ) ) this_SEMICOLON_5= RULE_SEMICOLON
                    {
                    otherlv_2=(Token)match(input,29,FOLLOW_6); 

                    				newLeafNode(otherlv_2, grammarAccess.getAmbienteDespliegueAccess().getAmbienteKeyword_2_0());
                    			
                    this_EQUALS_3=(Token)match(input,RULE_EQUALS,FOLLOW_25); 

                    				newLeafNode(this_EQUALS_3, grammarAccess.getAmbienteDespliegueAccess().getEQUALSTerminalRuleCall_2_1());
                    			
                    // InternalCeffective.g:808:4: ( (lv_ambiente_4_0= ruleTipoAmbiente ) )
                    // InternalCeffective.g:809:5: (lv_ambiente_4_0= ruleTipoAmbiente )
                    {
                    // InternalCeffective.g:809:5: (lv_ambiente_4_0= ruleTipoAmbiente )
                    // InternalCeffective.g:810:6: lv_ambiente_4_0= ruleTipoAmbiente
                    {

                    						newCompositeNode(grammarAccess.getAmbienteDespliegueAccess().getAmbienteTipoAmbienteEnumRuleCall_2_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_ambiente_4_0=ruleTipoAmbiente();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getAmbienteDespliegueRule());
                    						}
                    						set(
                    							current,
                    							"ambiente",
                    							lv_ambiente_4_0,
                    							"org.xtext.example.ceffective.Ceffective.TipoAmbiente");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_5=(Token)match(input,RULE_SEMICOLON,FOLLOW_26); 

                    				newLeafNode(this_SEMICOLON_5, grammarAccess.getAmbienteDespliegueAccess().getSEMICOLONTerminalRuleCall_2_3());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:832:3: (otherlv_6= 'nombre' this_EQUALS_7= RULE_EQUALS ( (lv_nombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==30) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalCeffective.g:833:4: otherlv_6= 'nombre' this_EQUALS_7= RULE_EQUALS ( (lv_nombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON
                    {
                    otherlv_6=(Token)match(input,30,FOLLOW_6); 

                    				newLeafNode(otherlv_6, grammarAccess.getAmbienteDespliegueAccess().getNombreKeyword_3_0());
                    			
                    this_EQUALS_7=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_7, grammarAccess.getAmbienteDespliegueAccess().getEQUALSTerminalRuleCall_3_1());
                    			
                    // InternalCeffective.g:841:4: ( (lv_nombre_8_0= ruleEString ) )
                    // InternalCeffective.g:842:5: (lv_nombre_8_0= ruleEString )
                    {
                    // InternalCeffective.g:842:5: (lv_nombre_8_0= ruleEString )
                    // InternalCeffective.g:843:6: lv_nombre_8_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getAmbienteDespliegueAccess().getNombreEStringParserRuleCall_3_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_nombre_8_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getAmbienteDespliegueRule());
                    						}
                    						set(
                    							current,
                    							"nombre",
                    							lv_nombre_8_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_27); 

                    				newLeafNode(this_SEMICOLON_9, grammarAccess.getAmbienteDespliegueAccess().getSEMICOLONTerminalRuleCall_3_3());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:865:3: (otherlv_10= 'vpcs' this_EQUALS_11= RULE_EQUALS this_LIST_START_12= RULE_LIST_START ( (lv_vpc_13_0= ruleVPC ) ) (this_COMA_14= RULE_COMA ( (lv_vpc_15_0= ruleVPC ) ) )* this_LIST_END_16= RULE_LIST_END )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==31) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalCeffective.g:866:4: otherlv_10= 'vpcs' this_EQUALS_11= RULE_EQUALS this_LIST_START_12= RULE_LIST_START ( (lv_vpc_13_0= ruleVPC ) ) (this_COMA_14= RULE_COMA ( (lv_vpc_15_0= ruleVPC ) ) )* this_LIST_END_16= RULE_LIST_END
                    {
                    otherlv_10=(Token)match(input,31,FOLLOW_6); 

                    				newLeafNode(otherlv_10, grammarAccess.getAmbienteDespliegueAccess().getVpcsKeyword_4_0());
                    			
                    this_EQUALS_11=(Token)match(input,RULE_EQUALS,FOLLOW_15); 

                    				newLeafNode(this_EQUALS_11, grammarAccess.getAmbienteDespliegueAccess().getEQUALSTerminalRuleCall_4_1());
                    			
                    this_LIST_START_12=(Token)match(input,RULE_LIST_START,FOLLOW_4); 

                    				newLeafNode(this_LIST_START_12, grammarAccess.getAmbienteDespliegueAccess().getLIST_STARTTerminalRuleCall_4_2());
                    			
                    // InternalCeffective.g:878:4: ( (lv_vpc_13_0= ruleVPC ) )
                    // InternalCeffective.g:879:5: (lv_vpc_13_0= ruleVPC )
                    {
                    // InternalCeffective.g:879:5: (lv_vpc_13_0= ruleVPC )
                    // InternalCeffective.g:880:6: lv_vpc_13_0= ruleVPC
                    {

                    						newCompositeNode(grammarAccess.getAmbienteDespliegueAccess().getVpcVPCParserRuleCall_4_3_0());
                    					
                    pushFollow(FOLLOW_16);
                    lv_vpc_13_0=ruleVPC();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getAmbienteDespliegueRule());
                    						}
                    						add(
                    							current,
                    							"vpc",
                    							lv_vpc_13_0,
                    							"org.xtext.example.ceffective.Ceffective.VPC");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalCeffective.g:897:4: (this_COMA_14= RULE_COMA ( (lv_vpc_15_0= ruleVPC ) ) )*
                    loop15:
                    do {
                        int alt15=2;
                        int LA15_0 = input.LA(1);

                        if ( (LA15_0==RULE_COMA) ) {
                            alt15=1;
                        }


                        switch (alt15) {
                    	case 1 :
                    	    // InternalCeffective.g:898:5: this_COMA_14= RULE_COMA ( (lv_vpc_15_0= ruleVPC ) )
                    	    {
                    	    this_COMA_14=(Token)match(input,RULE_COMA,FOLLOW_4); 

                    	    					newLeafNode(this_COMA_14, grammarAccess.getAmbienteDespliegueAccess().getCOMATerminalRuleCall_4_4_0());
                    	    				
                    	    // InternalCeffective.g:902:5: ( (lv_vpc_15_0= ruleVPC ) )
                    	    // InternalCeffective.g:903:6: (lv_vpc_15_0= ruleVPC )
                    	    {
                    	    // InternalCeffective.g:903:6: (lv_vpc_15_0= ruleVPC )
                    	    // InternalCeffective.g:904:7: lv_vpc_15_0= ruleVPC
                    	    {

                    	    							newCompositeNode(grammarAccess.getAmbienteDespliegueAccess().getVpcVPCParserRuleCall_4_4_1_0());
                    	    						
                    	    pushFollow(FOLLOW_16);
                    	    lv_vpc_15_0=ruleVPC();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getAmbienteDespliegueRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"vpc",
                    	    								lv_vpc_15_0,
                    	    								"org.xtext.example.ceffective.Ceffective.VPC");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop15;
                        }
                    } while (true);

                    this_LIST_END_16=(Token)match(input,RULE_LIST_END,FOLLOW_28); 

                    				newLeafNode(this_LIST_END_16, grammarAccess.getAmbienteDespliegueAccess().getLIST_ENDTerminalRuleCall_4_5());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:927:3: (otherlv_17= 'securityresource' this_EQUALS_18= RULE_EQUALS this_LIST_START_19= RULE_LIST_START ( (lv_mecanismoseguridad_20_0= ruleMecanismoSeguridad ) ) (this_COMA_21= RULE_COMA ( (lv_mecanismoseguridad_22_0= ruleMecanismoSeguridad ) ) )* this_LIST_END_23= RULE_LIST_END )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==32) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // InternalCeffective.g:928:4: otherlv_17= 'securityresource' this_EQUALS_18= RULE_EQUALS this_LIST_START_19= RULE_LIST_START ( (lv_mecanismoseguridad_20_0= ruleMecanismoSeguridad ) ) (this_COMA_21= RULE_COMA ( (lv_mecanismoseguridad_22_0= ruleMecanismoSeguridad ) ) )* this_LIST_END_23= RULE_LIST_END
                    {
                    otherlv_17=(Token)match(input,32,FOLLOW_6); 

                    				newLeafNode(otherlv_17, grammarAccess.getAmbienteDespliegueAccess().getSecurityresourceKeyword_5_0());
                    			
                    this_EQUALS_18=(Token)match(input,RULE_EQUALS,FOLLOW_15); 

                    				newLeafNode(this_EQUALS_18, grammarAccess.getAmbienteDespliegueAccess().getEQUALSTerminalRuleCall_5_1());
                    			
                    this_LIST_START_19=(Token)match(input,RULE_LIST_START,FOLLOW_4); 

                    				newLeafNode(this_LIST_START_19, grammarAccess.getAmbienteDespliegueAccess().getLIST_STARTTerminalRuleCall_5_2());
                    			
                    // InternalCeffective.g:940:4: ( (lv_mecanismoseguridad_20_0= ruleMecanismoSeguridad ) )
                    // InternalCeffective.g:941:5: (lv_mecanismoseguridad_20_0= ruleMecanismoSeguridad )
                    {
                    // InternalCeffective.g:941:5: (lv_mecanismoseguridad_20_0= ruleMecanismoSeguridad )
                    // InternalCeffective.g:942:6: lv_mecanismoseguridad_20_0= ruleMecanismoSeguridad
                    {

                    						newCompositeNode(grammarAccess.getAmbienteDespliegueAccess().getMecanismoseguridadMecanismoSeguridadParserRuleCall_5_3_0());
                    					
                    pushFollow(FOLLOW_16);
                    lv_mecanismoseguridad_20_0=ruleMecanismoSeguridad();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getAmbienteDespliegueRule());
                    						}
                    						add(
                    							current,
                    							"mecanismoseguridad",
                    							lv_mecanismoseguridad_20_0,
                    							"org.xtext.example.ceffective.Ceffective.MecanismoSeguridad");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalCeffective.g:959:4: (this_COMA_21= RULE_COMA ( (lv_mecanismoseguridad_22_0= ruleMecanismoSeguridad ) ) )*
                    loop17:
                    do {
                        int alt17=2;
                        int LA17_0 = input.LA(1);

                        if ( (LA17_0==RULE_COMA) ) {
                            alt17=1;
                        }


                        switch (alt17) {
                    	case 1 :
                    	    // InternalCeffective.g:960:5: this_COMA_21= RULE_COMA ( (lv_mecanismoseguridad_22_0= ruleMecanismoSeguridad ) )
                    	    {
                    	    this_COMA_21=(Token)match(input,RULE_COMA,FOLLOW_4); 

                    	    					newLeafNode(this_COMA_21, grammarAccess.getAmbienteDespliegueAccess().getCOMATerminalRuleCall_5_4_0());
                    	    				
                    	    // InternalCeffective.g:964:5: ( (lv_mecanismoseguridad_22_0= ruleMecanismoSeguridad ) )
                    	    // InternalCeffective.g:965:6: (lv_mecanismoseguridad_22_0= ruleMecanismoSeguridad )
                    	    {
                    	    // InternalCeffective.g:965:6: (lv_mecanismoseguridad_22_0= ruleMecanismoSeguridad )
                    	    // InternalCeffective.g:966:7: lv_mecanismoseguridad_22_0= ruleMecanismoSeguridad
                    	    {

                    	    							newCompositeNode(grammarAccess.getAmbienteDespliegueAccess().getMecanismoseguridadMecanismoSeguridadParserRuleCall_5_4_1_0());
                    	    						
                    	    pushFollow(FOLLOW_16);
                    	    lv_mecanismoseguridad_22_0=ruleMecanismoSeguridad();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getAmbienteDespliegueRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"mecanismoseguridad",
                    	    								lv_mecanismoseguridad_22_0,
                    	    								"org.xtext.example.ceffective.Ceffective.MecanismoSeguridad");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop17;
                        }
                    } while (true);

                    this_LIST_END_23=(Token)match(input,RULE_LIST_END,FOLLOW_29); 

                    				newLeafNode(this_LIST_END_23, grammarAccess.getAmbienteDespliegueAccess().getLIST_ENDTerminalRuleCall_5_5());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:989:3: (otherlv_24= 'recursos' this_EQUALS_25= RULE_EQUALS this_LIST_START_26= RULE_LIST_START ( (lv_recursos_27_0= ruleRecurso ) ) (this_COMA_28= RULE_COMA ( (lv_recursos_29_0= ruleRecurso ) ) )* this_LIST_END_30= RULE_LIST_END )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==33) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // InternalCeffective.g:990:4: otherlv_24= 'recursos' this_EQUALS_25= RULE_EQUALS this_LIST_START_26= RULE_LIST_START ( (lv_recursos_27_0= ruleRecurso ) ) (this_COMA_28= RULE_COMA ( (lv_recursos_29_0= ruleRecurso ) ) )* this_LIST_END_30= RULE_LIST_END
                    {
                    otherlv_24=(Token)match(input,33,FOLLOW_6); 

                    				newLeafNode(otherlv_24, grammarAccess.getAmbienteDespliegueAccess().getRecursosKeyword_6_0());
                    			
                    this_EQUALS_25=(Token)match(input,RULE_EQUALS,FOLLOW_15); 

                    				newLeafNode(this_EQUALS_25, grammarAccess.getAmbienteDespliegueAccess().getEQUALSTerminalRuleCall_6_1());
                    			
                    this_LIST_START_26=(Token)match(input,RULE_LIST_START,FOLLOW_30); 

                    				newLeafNode(this_LIST_START_26, grammarAccess.getAmbienteDespliegueAccess().getLIST_STARTTerminalRuleCall_6_2());
                    			
                    // InternalCeffective.g:1002:4: ( (lv_recursos_27_0= ruleRecurso ) )
                    // InternalCeffective.g:1003:5: (lv_recursos_27_0= ruleRecurso )
                    {
                    // InternalCeffective.g:1003:5: (lv_recursos_27_0= ruleRecurso )
                    // InternalCeffective.g:1004:6: lv_recursos_27_0= ruleRecurso
                    {

                    						newCompositeNode(grammarAccess.getAmbienteDespliegueAccess().getRecursosRecursoParserRuleCall_6_3_0());
                    					
                    pushFollow(FOLLOW_16);
                    lv_recursos_27_0=ruleRecurso();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getAmbienteDespliegueRule());
                    						}
                    						add(
                    							current,
                    							"recursos",
                    							lv_recursos_27_0,
                    							"org.xtext.example.ceffective.Ceffective.Recurso");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalCeffective.g:1021:4: (this_COMA_28= RULE_COMA ( (lv_recursos_29_0= ruleRecurso ) ) )*
                    loop19:
                    do {
                        int alt19=2;
                        int LA19_0 = input.LA(1);

                        if ( (LA19_0==RULE_COMA) ) {
                            alt19=1;
                        }


                        switch (alt19) {
                    	case 1 :
                    	    // InternalCeffective.g:1022:5: this_COMA_28= RULE_COMA ( (lv_recursos_29_0= ruleRecurso ) )
                    	    {
                    	    this_COMA_28=(Token)match(input,RULE_COMA,FOLLOW_30); 

                    	    					newLeafNode(this_COMA_28, grammarAccess.getAmbienteDespliegueAccess().getCOMATerminalRuleCall_6_4_0());
                    	    				
                    	    // InternalCeffective.g:1026:5: ( (lv_recursos_29_0= ruleRecurso ) )
                    	    // InternalCeffective.g:1027:6: (lv_recursos_29_0= ruleRecurso )
                    	    {
                    	    // InternalCeffective.g:1027:6: (lv_recursos_29_0= ruleRecurso )
                    	    // InternalCeffective.g:1028:7: lv_recursos_29_0= ruleRecurso
                    	    {

                    	    							newCompositeNode(grammarAccess.getAmbienteDespliegueAccess().getRecursosRecursoParserRuleCall_6_4_1_0());
                    	    						
                    	    pushFollow(FOLLOW_16);
                    	    lv_recursos_29_0=ruleRecurso();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getAmbienteDespliegueRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"recursos",
                    	    								lv_recursos_29_0,
                    	    								"org.xtext.example.ceffective.Ceffective.Recurso");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop19;
                        }
                    } while (true);

                    this_LIST_END_30=(Token)match(input,RULE_LIST_END,FOLLOW_31); 

                    				newLeafNode(this_LIST_END_30, grammarAccess.getAmbienteDespliegueAccess().getLIST_ENDTerminalRuleCall_6_5());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:1051:3: (otherlv_31= 'conexiones' this_EQUALS_32= RULE_EQUALS this_LIST_START_33= RULE_LIST_START ruleConexion (this_COMA_35= RULE_COMA ruleConexion )* this_LIST_END_37= RULE_LIST_END )?
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==34) ) {
                alt22=1;
            }
            switch (alt22) {
                case 1 :
                    // InternalCeffective.g:1052:4: otherlv_31= 'conexiones' this_EQUALS_32= RULE_EQUALS this_LIST_START_33= RULE_LIST_START ruleConexion (this_COMA_35= RULE_COMA ruleConexion )* this_LIST_END_37= RULE_LIST_END
                    {
                    otherlv_31=(Token)match(input,34,FOLLOW_6); 

                    				newLeafNode(otherlv_31, grammarAccess.getAmbienteDespliegueAccess().getConexionesKeyword_7_0());
                    			
                    this_EQUALS_32=(Token)match(input,RULE_EQUALS,FOLLOW_15); 

                    				newLeafNode(this_EQUALS_32, grammarAccess.getAmbienteDespliegueAccess().getEQUALSTerminalRuleCall_7_1());
                    			
                    this_LIST_START_33=(Token)match(input,RULE_LIST_START,FOLLOW_4); 

                    				newLeafNode(this_LIST_START_33, grammarAccess.getAmbienteDespliegueAccess().getLIST_STARTTerminalRuleCall_7_2());
                    			

                    				newCompositeNode(grammarAccess.getAmbienteDespliegueAccess().getConexionParserRuleCall_7_3());
                    			
                    pushFollow(FOLLOW_16);
                    ruleConexion();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			
                    // InternalCeffective.g:1071:4: (this_COMA_35= RULE_COMA ruleConexion )*
                    loop21:
                    do {
                        int alt21=2;
                        int LA21_0 = input.LA(1);

                        if ( (LA21_0==RULE_COMA) ) {
                            alt21=1;
                        }


                        switch (alt21) {
                    	case 1 :
                    	    // InternalCeffective.g:1072:5: this_COMA_35= RULE_COMA ruleConexion
                    	    {
                    	    this_COMA_35=(Token)match(input,RULE_COMA,FOLLOW_4); 

                    	    					newLeafNode(this_COMA_35, grammarAccess.getAmbienteDespliegueAccess().getCOMATerminalRuleCall_7_4_0());
                    	    				

                    	    					newCompositeNode(grammarAccess.getAmbienteDespliegueAccess().getConexionParserRuleCall_7_4_1());
                    	    				
                    	    pushFollow(FOLLOW_16);
                    	    ruleConexion();

                    	    state._fsp--;


                    	    					afterParserOrEnumRuleCall();
                    	    				

                    	    }
                    	    break;

                    	default :
                    	    break loop21;
                        }
                    } while (true);

                    this_LIST_END_37=(Token)match(input,RULE_LIST_END,FOLLOW_8); 

                    				newLeafNode(this_LIST_END_37, grammarAccess.getAmbienteDespliegueAccess().getLIST_ENDTerminalRuleCall_7_5());
                    			

                    }
                    break;

            }

            this_OBJECT_END_38=(Token)match(input,RULE_OBJECT_END,FOLLOW_2); 

            			newLeafNode(this_OBJECT_END_38, grammarAccess.getAmbienteDespliegueAccess().getOBJECT_ENDTerminalRuleCall_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAmbienteDespliegue"


    // $ANTLR start "entryRuleConexion"
    // InternalCeffective.g:1097:1: entryRuleConexion returns [String current=null] : iv_ruleConexion= ruleConexion EOF ;
    public final String entryRuleConexion() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleConexion = null;


        try {
            // InternalCeffective.g:1097:48: (iv_ruleConexion= ruleConexion EOF )
            // InternalCeffective.g:1098:2: iv_ruleConexion= ruleConexion EOF
            {
             newCompositeNode(grammarAccess.getConexionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleConexion=ruleConexion();

            state._fsp--;

             current =iv_ruleConexion.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConexion"


    // $ANTLR start "ruleConexion"
    // InternalCeffective.g:1104:1: ruleConexion returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_OBJECT_START_0= RULE_OBJECT_START kw= 'recurso1' this_EQUALS_2= RULE_EQUALS this_ID_3= RULE_ID this_SEMICOLON_4= RULE_SEMICOLON kw= 'recurso2' this_EQUALS_6= RULE_EQUALS this_ID_7= RULE_ID this_SEMICOLON_8= RULE_SEMICOLON this_OBJECT_END_9= RULE_OBJECT_END ) ;
    public final AntlrDatatypeRuleToken ruleConexion() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_OBJECT_START_0=null;
        Token kw=null;
        Token this_EQUALS_2=null;
        Token this_ID_3=null;
        Token this_SEMICOLON_4=null;
        Token this_EQUALS_6=null;
        Token this_ID_7=null;
        Token this_SEMICOLON_8=null;
        Token this_OBJECT_END_9=null;


        	enterRule();

        try {
            // InternalCeffective.g:1110:2: ( (this_OBJECT_START_0= RULE_OBJECT_START kw= 'recurso1' this_EQUALS_2= RULE_EQUALS this_ID_3= RULE_ID this_SEMICOLON_4= RULE_SEMICOLON kw= 'recurso2' this_EQUALS_6= RULE_EQUALS this_ID_7= RULE_ID this_SEMICOLON_8= RULE_SEMICOLON this_OBJECT_END_9= RULE_OBJECT_END ) )
            // InternalCeffective.g:1111:2: (this_OBJECT_START_0= RULE_OBJECT_START kw= 'recurso1' this_EQUALS_2= RULE_EQUALS this_ID_3= RULE_ID this_SEMICOLON_4= RULE_SEMICOLON kw= 'recurso2' this_EQUALS_6= RULE_EQUALS this_ID_7= RULE_ID this_SEMICOLON_8= RULE_SEMICOLON this_OBJECT_END_9= RULE_OBJECT_END )
            {
            // InternalCeffective.g:1111:2: (this_OBJECT_START_0= RULE_OBJECT_START kw= 'recurso1' this_EQUALS_2= RULE_EQUALS this_ID_3= RULE_ID this_SEMICOLON_4= RULE_SEMICOLON kw= 'recurso2' this_EQUALS_6= RULE_EQUALS this_ID_7= RULE_ID this_SEMICOLON_8= RULE_SEMICOLON this_OBJECT_END_9= RULE_OBJECT_END )
            // InternalCeffective.g:1112:3: this_OBJECT_START_0= RULE_OBJECT_START kw= 'recurso1' this_EQUALS_2= RULE_EQUALS this_ID_3= RULE_ID this_SEMICOLON_4= RULE_SEMICOLON kw= 'recurso2' this_EQUALS_6= RULE_EQUALS this_ID_7= RULE_ID this_SEMICOLON_8= RULE_SEMICOLON this_OBJECT_END_9= RULE_OBJECT_END
            {
            this_OBJECT_START_0=(Token)match(input,RULE_OBJECT_START,FOLLOW_32); 

            			current.merge(this_OBJECT_START_0);
            		

            			newLeafNode(this_OBJECT_START_0, grammarAccess.getConexionAccess().getOBJECT_STARTTerminalRuleCall_0());
            		
            kw=(Token)match(input,35,FOLLOW_6); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getConexionAccess().getRecurso1Keyword_1());
            		
            this_EQUALS_2=(Token)match(input,RULE_EQUALS,FOLLOW_33); 

            			current.merge(this_EQUALS_2);
            		

            			newLeafNode(this_EQUALS_2, grammarAccess.getConexionAccess().getEQUALSTerminalRuleCall_2());
            		
            this_ID_3=(Token)match(input,RULE_ID,FOLLOW_7); 

            			current.merge(this_ID_3);
            		

            			newLeafNode(this_ID_3, grammarAccess.getConexionAccess().getIDTerminalRuleCall_3());
            		
            this_SEMICOLON_4=(Token)match(input,RULE_SEMICOLON,FOLLOW_34); 

            			current.merge(this_SEMICOLON_4);
            		

            			newLeafNode(this_SEMICOLON_4, grammarAccess.getConexionAccess().getSEMICOLONTerminalRuleCall_4());
            		
            kw=(Token)match(input,36,FOLLOW_6); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getConexionAccess().getRecurso2Keyword_5());
            		
            this_EQUALS_6=(Token)match(input,RULE_EQUALS,FOLLOW_33); 

            			current.merge(this_EQUALS_6);
            		

            			newLeafNode(this_EQUALS_6, grammarAccess.getConexionAccess().getEQUALSTerminalRuleCall_6());
            		
            this_ID_7=(Token)match(input,RULE_ID,FOLLOW_7); 

            			current.merge(this_ID_7);
            		

            			newLeafNode(this_ID_7, grammarAccess.getConexionAccess().getIDTerminalRuleCall_7());
            		
            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_8); 

            			current.merge(this_SEMICOLON_8);
            		

            			newLeafNode(this_SEMICOLON_8, grammarAccess.getConexionAccess().getSEMICOLONTerminalRuleCall_8());
            		
            this_OBJECT_END_9=(Token)match(input,RULE_OBJECT_END,FOLLOW_2); 

            			current.merge(this_OBJECT_END_9);
            		

            			newLeafNode(this_OBJECT_END_9, grammarAccess.getConexionAccess().getOBJECT_ENDTerminalRuleCall_9());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConexion"


    // $ANTLR start "entryRuleVPC"
    // InternalCeffective.g:1182:1: entryRuleVPC returns [EObject current=null] : iv_ruleVPC= ruleVPC EOF ;
    public final EObject entryRuleVPC() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVPC = null;


        try {
            // InternalCeffective.g:1182:44: (iv_ruleVPC= ruleVPC EOF )
            // InternalCeffective.g:1183:2: iv_ruleVPC= ruleVPC EOF
            {
             newCompositeNode(grammarAccess.getVPCRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVPC=ruleVPC();

            state._fsp--;

             current =iv_ruleVPC; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVPC"


    // $ANTLR start "ruleVPC"
    // InternalCeffective.g:1189:1: ruleVPC returns [EObject current=null] : ( () this_OBJECT_START_1= RULE_OBJECT_START (otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= RULE_ID ) ) this_SEMICOLON_5= RULE_SEMICOLON )? otherlv_6= 'id' this_EQUALS_7= RULE_EQUALS ( (lv_name_8_0= RULE_ID ) ) this_SEMICOLON_9= RULE_SEMICOLON (otherlv_10= 'cidrBlock' this_EQUALS_11= RULE_EQUALS ( (lv_cidrBlock_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? this_OBJECT_END_14= RULE_OBJECT_END ) ;
    public final EObject ruleVPC() throws RecognitionException {
        EObject current = null;

        Token this_OBJECT_START_1=null;
        Token otherlv_2=null;
        Token this_EQUALS_3=null;
        Token lv_nombre_4_0=null;
        Token this_SEMICOLON_5=null;
        Token otherlv_6=null;
        Token this_EQUALS_7=null;
        Token lv_name_8_0=null;
        Token this_SEMICOLON_9=null;
        Token otherlv_10=null;
        Token this_EQUALS_11=null;
        Token this_SEMICOLON_13=null;
        Token this_OBJECT_END_14=null;
        AntlrDatatypeRuleToken lv_cidrBlock_12_0 = null;



        	enterRule();

        try {
            // InternalCeffective.g:1195:2: ( ( () this_OBJECT_START_1= RULE_OBJECT_START (otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= RULE_ID ) ) this_SEMICOLON_5= RULE_SEMICOLON )? otherlv_6= 'id' this_EQUALS_7= RULE_EQUALS ( (lv_name_8_0= RULE_ID ) ) this_SEMICOLON_9= RULE_SEMICOLON (otherlv_10= 'cidrBlock' this_EQUALS_11= RULE_EQUALS ( (lv_cidrBlock_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? this_OBJECT_END_14= RULE_OBJECT_END ) )
            // InternalCeffective.g:1196:2: ( () this_OBJECT_START_1= RULE_OBJECT_START (otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= RULE_ID ) ) this_SEMICOLON_5= RULE_SEMICOLON )? otherlv_6= 'id' this_EQUALS_7= RULE_EQUALS ( (lv_name_8_0= RULE_ID ) ) this_SEMICOLON_9= RULE_SEMICOLON (otherlv_10= 'cidrBlock' this_EQUALS_11= RULE_EQUALS ( (lv_cidrBlock_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? this_OBJECT_END_14= RULE_OBJECT_END )
            {
            // InternalCeffective.g:1196:2: ( () this_OBJECT_START_1= RULE_OBJECT_START (otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= RULE_ID ) ) this_SEMICOLON_5= RULE_SEMICOLON )? otherlv_6= 'id' this_EQUALS_7= RULE_EQUALS ( (lv_name_8_0= RULE_ID ) ) this_SEMICOLON_9= RULE_SEMICOLON (otherlv_10= 'cidrBlock' this_EQUALS_11= RULE_EQUALS ( (lv_cidrBlock_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? this_OBJECT_END_14= RULE_OBJECT_END )
            // InternalCeffective.g:1197:3: () this_OBJECT_START_1= RULE_OBJECT_START (otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= RULE_ID ) ) this_SEMICOLON_5= RULE_SEMICOLON )? otherlv_6= 'id' this_EQUALS_7= RULE_EQUALS ( (lv_name_8_0= RULE_ID ) ) this_SEMICOLON_9= RULE_SEMICOLON (otherlv_10= 'cidrBlock' this_EQUALS_11= RULE_EQUALS ( (lv_cidrBlock_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? this_OBJECT_END_14= RULE_OBJECT_END
            {
            // InternalCeffective.g:1197:3: ()
            // InternalCeffective.g:1198:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getVPCAccess().getVPCAction_0(),
            					current);
            			

            }

            this_OBJECT_START_1=(Token)match(input,RULE_OBJECT_START,FOLLOW_35); 

            			newLeafNode(this_OBJECT_START_1, grammarAccess.getVPCAccess().getOBJECT_STARTTerminalRuleCall_1());
            		
            // InternalCeffective.g:1208:3: (otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= RULE_ID ) ) this_SEMICOLON_5= RULE_SEMICOLON )?
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( (LA23_0==30) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // InternalCeffective.g:1209:4: otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= RULE_ID ) ) this_SEMICOLON_5= RULE_SEMICOLON
                    {
                    otherlv_2=(Token)match(input,30,FOLLOW_6); 

                    				newLeafNode(otherlv_2, grammarAccess.getVPCAccess().getNombreKeyword_2_0());
                    			
                    this_EQUALS_3=(Token)match(input,RULE_EQUALS,FOLLOW_33); 

                    				newLeafNode(this_EQUALS_3, grammarAccess.getVPCAccess().getEQUALSTerminalRuleCall_2_1());
                    			
                    // InternalCeffective.g:1217:4: ( (lv_nombre_4_0= RULE_ID ) )
                    // InternalCeffective.g:1218:5: (lv_nombre_4_0= RULE_ID )
                    {
                    // InternalCeffective.g:1218:5: (lv_nombre_4_0= RULE_ID )
                    // InternalCeffective.g:1219:6: lv_nombre_4_0= RULE_ID
                    {
                    lv_nombre_4_0=(Token)match(input,RULE_ID,FOLLOW_7); 

                    						newLeafNode(lv_nombre_4_0, grammarAccess.getVPCAccess().getNombreIDTerminalRuleCall_2_2_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVPCRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"nombre",
                    							lv_nombre_4_0,
                    							"org.eclipse.xtext.common.Terminals.ID");
                    					

                    }


                    }

                    this_SEMICOLON_5=(Token)match(input,RULE_SEMICOLON,FOLLOW_36); 

                    				newLeafNode(this_SEMICOLON_5, grammarAccess.getVPCAccess().getSEMICOLONTerminalRuleCall_2_3());
                    			

                    }
                    break;

            }

            otherlv_6=(Token)match(input,37,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getVPCAccess().getIdKeyword_3());
            		
            this_EQUALS_7=(Token)match(input,RULE_EQUALS,FOLLOW_33); 

            			newLeafNode(this_EQUALS_7, grammarAccess.getVPCAccess().getEQUALSTerminalRuleCall_4());
            		
            // InternalCeffective.g:1248:3: ( (lv_name_8_0= RULE_ID ) )
            // InternalCeffective.g:1249:4: (lv_name_8_0= RULE_ID )
            {
            // InternalCeffective.g:1249:4: (lv_name_8_0= RULE_ID )
            // InternalCeffective.g:1250:5: lv_name_8_0= RULE_ID
            {
            lv_name_8_0=(Token)match(input,RULE_ID,FOLLOW_7); 

            					newLeafNode(lv_name_8_0, grammarAccess.getVPCAccess().getNameIDTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVPCRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_8_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_37); 

            			newLeafNode(this_SEMICOLON_9, grammarAccess.getVPCAccess().getSEMICOLONTerminalRuleCall_6());
            		
            // InternalCeffective.g:1270:3: (otherlv_10= 'cidrBlock' this_EQUALS_11= RULE_EQUALS ( (lv_cidrBlock_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )?
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( (LA24_0==38) ) {
                alt24=1;
            }
            switch (alt24) {
                case 1 :
                    // InternalCeffective.g:1271:4: otherlv_10= 'cidrBlock' this_EQUALS_11= RULE_EQUALS ( (lv_cidrBlock_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON
                    {
                    otherlv_10=(Token)match(input,38,FOLLOW_6); 

                    				newLeafNode(otherlv_10, grammarAccess.getVPCAccess().getCidrBlockKeyword_7_0());
                    			
                    this_EQUALS_11=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_11, grammarAccess.getVPCAccess().getEQUALSTerminalRuleCall_7_1());
                    			
                    // InternalCeffective.g:1279:4: ( (lv_cidrBlock_12_0= ruleEString ) )
                    // InternalCeffective.g:1280:5: (lv_cidrBlock_12_0= ruleEString )
                    {
                    // InternalCeffective.g:1280:5: (lv_cidrBlock_12_0= ruleEString )
                    // InternalCeffective.g:1281:6: lv_cidrBlock_12_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getVPCAccess().getCidrBlockEStringParserRuleCall_7_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_cidrBlock_12_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getVPCRule());
                    						}
                    						set(
                    							current,
                    							"cidrBlock",
                    							lv_cidrBlock_12_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_13=(Token)match(input,RULE_SEMICOLON,FOLLOW_8); 

                    				newLeafNode(this_SEMICOLON_13, grammarAccess.getVPCAccess().getSEMICOLONTerminalRuleCall_7_3());
                    			

                    }
                    break;

            }

            this_OBJECT_END_14=(Token)match(input,RULE_OBJECT_END,FOLLOW_2); 

            			newLeafNode(this_OBJECT_END_14, grammarAccess.getVPCAccess().getOBJECT_ENDTerminalRuleCall_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVPC"


    // $ANTLR start "entryRuleFQN"
    // InternalCeffective.g:1311:1: entryRuleFQN returns [String current=null] : iv_ruleFQN= ruleFQN EOF ;
    public final String entryRuleFQN() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleFQN = null;


        try {
            // InternalCeffective.g:1311:43: (iv_ruleFQN= ruleFQN EOF )
            // InternalCeffective.g:1312:2: iv_ruleFQN= ruleFQN EOF
            {
             newCompositeNode(grammarAccess.getFQNRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFQN=ruleFQN();

            state._fsp--;

             current =iv_ruleFQN.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFQN"


    // $ANTLR start "ruleFQN"
    // InternalCeffective.g:1318:1: ruleFQN returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* ) ;
    public final AntlrDatatypeRuleToken ruleFQN() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_ID_0=null;
        Token kw=null;
        Token this_ID_2=null;


        	enterRule();

        try {
            // InternalCeffective.g:1324:2: ( (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* ) )
            // InternalCeffective.g:1325:2: (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* )
            {
            // InternalCeffective.g:1325:2: (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* )
            // InternalCeffective.g:1326:3: this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )*
            {
            this_ID_0=(Token)match(input,RULE_ID,FOLLOW_38); 

            			current.merge(this_ID_0);
            		

            			newLeafNode(this_ID_0, grammarAccess.getFQNAccess().getIDTerminalRuleCall_0());
            		
            // InternalCeffective.g:1333:3: (kw= '.' this_ID_2= RULE_ID )*
            loop25:
            do {
                int alt25=2;
                int LA25_0 = input.LA(1);

                if ( (LA25_0==39) ) {
                    alt25=1;
                }


                switch (alt25) {
            	case 1 :
            	    // InternalCeffective.g:1334:4: kw= '.' this_ID_2= RULE_ID
            	    {
            	    kw=(Token)match(input,39,FOLLOW_33); 

            	    				current.merge(kw);
            	    				newLeafNode(kw, grammarAccess.getFQNAccess().getFullStopKeyword_1_0());
            	    			
            	    this_ID_2=(Token)match(input,RULE_ID,FOLLOW_38); 

            	    				current.merge(this_ID_2);
            	    			

            	    				newLeafNode(this_ID_2, grammarAccess.getFQNAccess().getIDTerminalRuleCall_1_1());
            	    			

            	    }
            	    break;

            	default :
            	    break loop25;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFQN"


    // $ANTLR start "entryRuleMecanismoSeguridad"
    // InternalCeffective.g:1351:1: entryRuleMecanismoSeguridad returns [EObject current=null] : iv_ruleMecanismoSeguridad= ruleMecanismoSeguridad EOF ;
    public final EObject entryRuleMecanismoSeguridad() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMecanismoSeguridad = null;


        try {
            // InternalCeffective.g:1351:59: (iv_ruleMecanismoSeguridad= ruleMecanismoSeguridad EOF )
            // InternalCeffective.g:1352:2: iv_ruleMecanismoSeguridad= ruleMecanismoSeguridad EOF
            {
             newCompositeNode(grammarAccess.getMecanismoSeguridadRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMecanismoSeguridad=ruleMecanismoSeguridad();

            state._fsp--;

             current =iv_ruleMecanismoSeguridad; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMecanismoSeguridad"


    // $ANTLR start "ruleMecanismoSeguridad"
    // InternalCeffective.g:1358:1: ruleMecanismoSeguridad returns [EObject current=null] : (this_Subred_0= ruleSubred | this_InternetGateway_1= ruleInternetGateway | this_GrupoSeguridad_2= ruleGrupoSeguridad ) ;
    public final EObject ruleMecanismoSeguridad() throws RecognitionException {
        EObject current = null;

        EObject this_Subred_0 = null;

        EObject this_InternetGateway_1 = null;

        EObject this_GrupoSeguridad_2 = null;



        	enterRule();

        try {
            // InternalCeffective.g:1364:2: ( (this_Subred_0= ruleSubred | this_InternetGateway_1= ruleInternetGateway | this_GrupoSeguridad_2= ruleGrupoSeguridad ) )
            // InternalCeffective.g:1365:2: (this_Subred_0= ruleSubred | this_InternetGateway_1= ruleInternetGateway | this_GrupoSeguridad_2= ruleGrupoSeguridad )
            {
            // InternalCeffective.g:1365:2: (this_Subred_0= ruleSubred | this_InternetGateway_1= ruleInternetGateway | this_GrupoSeguridad_2= ruleGrupoSeguridad )
            int alt26=3;
            alt26 = dfa26.predict(input);
            switch (alt26) {
                case 1 :
                    // InternalCeffective.g:1366:3: this_Subred_0= ruleSubred
                    {

                    			newCompositeNode(grammarAccess.getMecanismoSeguridadAccess().getSubredParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_Subred_0=ruleSubred();

                    state._fsp--;


                    			current = this_Subred_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalCeffective.g:1375:3: this_InternetGateway_1= ruleInternetGateway
                    {

                    			newCompositeNode(grammarAccess.getMecanismoSeguridadAccess().getInternetGatewayParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_InternetGateway_1=ruleInternetGateway();

                    state._fsp--;


                    			current = this_InternetGateway_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalCeffective.g:1384:3: this_GrupoSeguridad_2= ruleGrupoSeguridad
                    {

                    			newCompositeNode(grammarAccess.getMecanismoSeguridadAccess().getGrupoSeguridadParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_GrupoSeguridad_2=ruleGrupoSeguridad();

                    state._fsp--;


                    			current = this_GrupoSeguridad_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMecanismoSeguridad"


    // $ANTLR start "entryRuleSubred"
    // InternalCeffective.g:1396:1: entryRuleSubred returns [EObject current=null] : iv_ruleSubred= ruleSubred EOF ;
    public final EObject entryRuleSubred() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSubred = null;


        try {
            // InternalCeffective.g:1396:47: (iv_ruleSubred= ruleSubred EOF )
            // InternalCeffective.g:1397:2: iv_ruleSubred= ruleSubred EOF
            {
             newCompositeNode(grammarAccess.getSubredRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSubred=ruleSubred();

            state._fsp--;

             current =iv_ruleSubred; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSubred"


    // $ANTLR start "ruleSubred"
    // InternalCeffective.g:1403:1: ruleSubred returns [EObject current=null] : ( () this_OBJECT_START_1= RULE_OBJECT_START otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON (otherlv_6= 'zonaNombre' this_EQUALS_7= RULE_EQUALS ( (lv_zonaNombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'zonaDisponibilidad' this_EQUALS_11= RULE_EQUALS ( (lv_zonaDisponibilidad_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? otherlv_14= 'id' this_EQUALS_15= RULE_EQUALS ( (lv_id_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON otherlv_18= 'cidrBlock' this_EQUALS_19= RULE_EQUALS ( (lv_cidrBlock_20_0= ruleEString ) ) this_SEMICOLON_21= RULE_SEMICOLON (otherlv_22= 'vpc' this_EQUALS_23= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_25= RULE_SEMICOLON )? this_OBJECT_END_26= RULE_OBJECT_END ) ;
    public final EObject ruleSubred() throws RecognitionException {
        EObject current = null;

        Token this_OBJECT_START_1=null;
        Token otherlv_2=null;
        Token this_EQUALS_3=null;
        Token this_SEMICOLON_5=null;
        Token otherlv_6=null;
        Token this_EQUALS_7=null;
        Token this_SEMICOLON_9=null;
        Token otherlv_10=null;
        Token this_EQUALS_11=null;
        Token this_SEMICOLON_13=null;
        Token otherlv_14=null;
        Token this_EQUALS_15=null;
        Token this_SEMICOLON_17=null;
        Token otherlv_18=null;
        Token this_EQUALS_19=null;
        Token this_SEMICOLON_21=null;
        Token otherlv_22=null;
        Token this_EQUALS_23=null;
        Token this_SEMICOLON_25=null;
        Token this_OBJECT_END_26=null;
        AntlrDatatypeRuleToken lv_nombre_4_0 = null;

        AntlrDatatypeRuleToken lv_zonaNombre_8_0 = null;

        AntlrDatatypeRuleToken lv_zonaDisponibilidad_12_0 = null;

        AntlrDatatypeRuleToken lv_id_16_0 = null;

        AntlrDatatypeRuleToken lv_cidrBlock_20_0 = null;



        	enterRule();

        try {
            // InternalCeffective.g:1409:2: ( ( () this_OBJECT_START_1= RULE_OBJECT_START otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON (otherlv_6= 'zonaNombre' this_EQUALS_7= RULE_EQUALS ( (lv_zonaNombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'zonaDisponibilidad' this_EQUALS_11= RULE_EQUALS ( (lv_zonaDisponibilidad_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? otherlv_14= 'id' this_EQUALS_15= RULE_EQUALS ( (lv_id_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON otherlv_18= 'cidrBlock' this_EQUALS_19= RULE_EQUALS ( (lv_cidrBlock_20_0= ruleEString ) ) this_SEMICOLON_21= RULE_SEMICOLON (otherlv_22= 'vpc' this_EQUALS_23= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_25= RULE_SEMICOLON )? this_OBJECT_END_26= RULE_OBJECT_END ) )
            // InternalCeffective.g:1410:2: ( () this_OBJECT_START_1= RULE_OBJECT_START otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON (otherlv_6= 'zonaNombre' this_EQUALS_7= RULE_EQUALS ( (lv_zonaNombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'zonaDisponibilidad' this_EQUALS_11= RULE_EQUALS ( (lv_zonaDisponibilidad_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? otherlv_14= 'id' this_EQUALS_15= RULE_EQUALS ( (lv_id_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON otherlv_18= 'cidrBlock' this_EQUALS_19= RULE_EQUALS ( (lv_cidrBlock_20_0= ruleEString ) ) this_SEMICOLON_21= RULE_SEMICOLON (otherlv_22= 'vpc' this_EQUALS_23= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_25= RULE_SEMICOLON )? this_OBJECT_END_26= RULE_OBJECT_END )
            {
            // InternalCeffective.g:1410:2: ( () this_OBJECT_START_1= RULE_OBJECT_START otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON (otherlv_6= 'zonaNombre' this_EQUALS_7= RULE_EQUALS ( (lv_zonaNombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'zonaDisponibilidad' this_EQUALS_11= RULE_EQUALS ( (lv_zonaDisponibilidad_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? otherlv_14= 'id' this_EQUALS_15= RULE_EQUALS ( (lv_id_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON otherlv_18= 'cidrBlock' this_EQUALS_19= RULE_EQUALS ( (lv_cidrBlock_20_0= ruleEString ) ) this_SEMICOLON_21= RULE_SEMICOLON (otherlv_22= 'vpc' this_EQUALS_23= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_25= RULE_SEMICOLON )? this_OBJECT_END_26= RULE_OBJECT_END )
            // InternalCeffective.g:1411:3: () this_OBJECT_START_1= RULE_OBJECT_START otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON (otherlv_6= 'zonaNombre' this_EQUALS_7= RULE_EQUALS ( (lv_zonaNombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'zonaDisponibilidad' this_EQUALS_11= RULE_EQUALS ( (lv_zonaDisponibilidad_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? otherlv_14= 'id' this_EQUALS_15= RULE_EQUALS ( (lv_id_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON otherlv_18= 'cidrBlock' this_EQUALS_19= RULE_EQUALS ( (lv_cidrBlock_20_0= ruleEString ) ) this_SEMICOLON_21= RULE_SEMICOLON (otherlv_22= 'vpc' this_EQUALS_23= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_25= RULE_SEMICOLON )? this_OBJECT_END_26= RULE_OBJECT_END
            {
            // InternalCeffective.g:1411:3: ()
            // InternalCeffective.g:1412:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getSubredAccess().getSubredAction_0(),
            					current);
            			

            }

            this_OBJECT_START_1=(Token)match(input,RULE_OBJECT_START,FOLLOW_39); 

            			newLeafNode(this_OBJECT_START_1, grammarAccess.getSubredAccess().getOBJECT_STARTTerminalRuleCall_1());
            		
            otherlv_2=(Token)match(input,30,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getSubredAccess().getNombreKeyword_2());
            		
            this_EQUALS_3=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

            			newLeafNode(this_EQUALS_3, grammarAccess.getSubredAccess().getEQUALSTerminalRuleCall_3());
            		
            // InternalCeffective.g:1430:3: ( (lv_nombre_4_0= ruleEString ) )
            // InternalCeffective.g:1431:4: (lv_nombre_4_0= ruleEString )
            {
            // InternalCeffective.g:1431:4: (lv_nombre_4_0= ruleEString )
            // InternalCeffective.g:1432:5: lv_nombre_4_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getSubredAccess().getNombreEStringParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_7);
            lv_nombre_4_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getSubredRule());
            					}
            					set(
            						current,
            						"nombre",
            						lv_nombre_4_0,
            						"org.xtext.example.ceffective.Ceffective.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_SEMICOLON_5=(Token)match(input,RULE_SEMICOLON,FOLLOW_40); 

            			newLeafNode(this_SEMICOLON_5, grammarAccess.getSubredAccess().getSEMICOLONTerminalRuleCall_5());
            		
            // InternalCeffective.g:1453:3: (otherlv_6= 'zonaNombre' this_EQUALS_7= RULE_EQUALS ( (lv_zonaNombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )?
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==40) ) {
                alt27=1;
            }
            switch (alt27) {
                case 1 :
                    // InternalCeffective.g:1454:4: otherlv_6= 'zonaNombre' this_EQUALS_7= RULE_EQUALS ( (lv_zonaNombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON
                    {
                    otherlv_6=(Token)match(input,40,FOLLOW_6); 

                    				newLeafNode(otherlv_6, grammarAccess.getSubredAccess().getZonaNombreKeyword_6_0());
                    			
                    this_EQUALS_7=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_7, grammarAccess.getSubredAccess().getEQUALSTerminalRuleCall_6_1());
                    			
                    // InternalCeffective.g:1462:4: ( (lv_zonaNombre_8_0= ruleEString ) )
                    // InternalCeffective.g:1463:5: (lv_zonaNombre_8_0= ruleEString )
                    {
                    // InternalCeffective.g:1463:5: (lv_zonaNombre_8_0= ruleEString )
                    // InternalCeffective.g:1464:6: lv_zonaNombre_8_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getSubredAccess().getZonaNombreEStringParserRuleCall_6_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_zonaNombre_8_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSubredRule());
                    						}
                    						set(
                    							current,
                    							"zonaNombre",
                    							lv_zonaNombre_8_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_41); 

                    				newLeafNode(this_SEMICOLON_9, grammarAccess.getSubredAccess().getSEMICOLONTerminalRuleCall_6_3());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:1486:3: (otherlv_10= 'zonaDisponibilidad' this_EQUALS_11= RULE_EQUALS ( (lv_zonaDisponibilidad_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )?
            int alt28=2;
            int LA28_0 = input.LA(1);

            if ( (LA28_0==41) ) {
                alt28=1;
            }
            switch (alt28) {
                case 1 :
                    // InternalCeffective.g:1487:4: otherlv_10= 'zonaDisponibilidad' this_EQUALS_11= RULE_EQUALS ( (lv_zonaDisponibilidad_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON
                    {
                    otherlv_10=(Token)match(input,41,FOLLOW_6); 

                    				newLeafNode(otherlv_10, grammarAccess.getSubredAccess().getZonaDisponibilidadKeyword_7_0());
                    			
                    this_EQUALS_11=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_11, grammarAccess.getSubredAccess().getEQUALSTerminalRuleCall_7_1());
                    			
                    // InternalCeffective.g:1495:4: ( (lv_zonaDisponibilidad_12_0= ruleEString ) )
                    // InternalCeffective.g:1496:5: (lv_zonaDisponibilidad_12_0= ruleEString )
                    {
                    // InternalCeffective.g:1496:5: (lv_zonaDisponibilidad_12_0= ruleEString )
                    // InternalCeffective.g:1497:6: lv_zonaDisponibilidad_12_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getSubredAccess().getZonaDisponibilidadEStringParserRuleCall_7_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_zonaDisponibilidad_12_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSubredRule());
                    						}
                    						set(
                    							current,
                    							"zonaDisponibilidad",
                    							lv_zonaDisponibilidad_12_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_13=(Token)match(input,RULE_SEMICOLON,FOLLOW_36); 

                    				newLeafNode(this_SEMICOLON_13, grammarAccess.getSubredAccess().getSEMICOLONTerminalRuleCall_7_3());
                    			

                    }
                    break;

            }

            otherlv_14=(Token)match(input,37,FOLLOW_6); 

            			newLeafNode(otherlv_14, grammarAccess.getSubredAccess().getIdKeyword_8());
            		
            this_EQUALS_15=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

            			newLeafNode(this_EQUALS_15, grammarAccess.getSubredAccess().getEQUALSTerminalRuleCall_9());
            		
            // InternalCeffective.g:1527:3: ( (lv_id_16_0= ruleEString ) )
            // InternalCeffective.g:1528:4: (lv_id_16_0= ruleEString )
            {
            // InternalCeffective.g:1528:4: (lv_id_16_0= ruleEString )
            // InternalCeffective.g:1529:5: lv_id_16_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getSubredAccess().getIdEStringParserRuleCall_10_0());
            				
            pushFollow(FOLLOW_7);
            lv_id_16_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getSubredRule());
            					}
            					set(
            						current,
            						"id",
            						lv_id_16_0,
            						"org.xtext.example.ceffective.Ceffective.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_SEMICOLON_17=(Token)match(input,RULE_SEMICOLON,FOLLOW_42); 

            			newLeafNode(this_SEMICOLON_17, grammarAccess.getSubredAccess().getSEMICOLONTerminalRuleCall_11());
            		
            otherlv_18=(Token)match(input,38,FOLLOW_6); 

            			newLeafNode(otherlv_18, grammarAccess.getSubredAccess().getCidrBlockKeyword_12());
            		
            this_EQUALS_19=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

            			newLeafNode(this_EQUALS_19, grammarAccess.getSubredAccess().getEQUALSTerminalRuleCall_13());
            		
            // InternalCeffective.g:1558:3: ( (lv_cidrBlock_20_0= ruleEString ) )
            // InternalCeffective.g:1559:4: (lv_cidrBlock_20_0= ruleEString )
            {
            // InternalCeffective.g:1559:4: (lv_cidrBlock_20_0= ruleEString )
            // InternalCeffective.g:1560:5: lv_cidrBlock_20_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getSubredAccess().getCidrBlockEStringParserRuleCall_14_0());
            				
            pushFollow(FOLLOW_7);
            lv_cidrBlock_20_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getSubredRule());
            					}
            					set(
            						current,
            						"cidrBlock",
            						lv_cidrBlock_20_0,
            						"org.xtext.example.ceffective.Ceffective.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_SEMICOLON_21=(Token)match(input,RULE_SEMICOLON,FOLLOW_43); 

            			newLeafNode(this_SEMICOLON_21, grammarAccess.getSubredAccess().getSEMICOLONTerminalRuleCall_15());
            		
            // InternalCeffective.g:1581:3: (otherlv_22= 'vpc' this_EQUALS_23= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_25= RULE_SEMICOLON )?
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==42) ) {
                alt29=1;
            }
            switch (alt29) {
                case 1 :
                    // InternalCeffective.g:1582:4: otherlv_22= 'vpc' this_EQUALS_23= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_25= RULE_SEMICOLON
                    {
                    otherlv_22=(Token)match(input,42,FOLLOW_6); 

                    				newLeafNode(otherlv_22, grammarAccess.getSubredAccess().getVpcKeyword_16_0());
                    			
                    this_EQUALS_23=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_23, grammarAccess.getSubredAccess().getEQUALSTerminalRuleCall_16_1());
                    			
                    // InternalCeffective.g:1590:4: ( ( ruleEString ) )
                    // InternalCeffective.g:1591:5: ( ruleEString )
                    {
                    // InternalCeffective.g:1591:5: ( ruleEString )
                    // InternalCeffective.g:1592:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getSubredRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getSubredAccess().getVpcVPCCrossReference_16_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_25=(Token)match(input,RULE_SEMICOLON,FOLLOW_8); 

                    				newLeafNode(this_SEMICOLON_25, grammarAccess.getSubredAccess().getSEMICOLONTerminalRuleCall_16_3());
                    			

                    }
                    break;

            }

            this_OBJECT_END_26=(Token)match(input,RULE_OBJECT_END,FOLLOW_2); 

            			newLeafNode(this_OBJECT_END_26, grammarAccess.getSubredAccess().getOBJECT_ENDTerminalRuleCall_17());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSubred"


    // $ANTLR start "entryRuleInternetGateway"
    // InternalCeffective.g:1619:1: entryRuleInternetGateway returns [EObject current=null] : iv_ruleInternetGateway= ruleInternetGateway EOF ;
    public final EObject entryRuleInternetGateway() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInternetGateway = null;


        try {
            // InternalCeffective.g:1619:56: (iv_ruleInternetGateway= ruleInternetGateway EOF )
            // InternalCeffective.g:1620:2: iv_ruleInternetGateway= ruleInternetGateway EOF
            {
             newCompositeNode(grammarAccess.getInternetGatewayRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInternetGateway=ruleInternetGateway();

            state._fsp--;

             current =iv_ruleInternetGateway; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInternetGateway"


    // $ANTLR start "ruleInternetGateway"
    // InternalCeffective.g:1626:1: ruleInternetGateway returns [EObject current=null] : ( () this_OBJECT_START_1= RULE_OBJECT_START otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON (otherlv_6= 'zonaNombre' this_EQUALS_7= RULE_EQUALS ( (lv_zonaNombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'zonaDisponibilidad' this_EQUALS_11= RULE_EQUALS ( (lv_zonaDisponibilidad_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? otherlv_14= 'id' this_EQUALS_15= RULE_EQUALS ( (lv_id_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON (otherlv_18= 'vpc' this_EQUALS_19= RULE_EQUALS ( ( ruleFQN ) ) this_SEMICOLON_21= RULE_SEMICOLON )? this_OBJECT_END_22= RULE_OBJECT_END ) ;
    public final EObject ruleInternetGateway() throws RecognitionException {
        EObject current = null;

        Token this_OBJECT_START_1=null;
        Token otherlv_2=null;
        Token this_EQUALS_3=null;
        Token this_SEMICOLON_5=null;
        Token otherlv_6=null;
        Token this_EQUALS_7=null;
        Token this_SEMICOLON_9=null;
        Token otherlv_10=null;
        Token this_EQUALS_11=null;
        Token this_SEMICOLON_13=null;
        Token otherlv_14=null;
        Token this_EQUALS_15=null;
        Token this_SEMICOLON_17=null;
        Token otherlv_18=null;
        Token this_EQUALS_19=null;
        Token this_SEMICOLON_21=null;
        Token this_OBJECT_END_22=null;
        AntlrDatatypeRuleToken lv_nombre_4_0 = null;

        AntlrDatatypeRuleToken lv_zonaNombre_8_0 = null;

        AntlrDatatypeRuleToken lv_zonaDisponibilidad_12_0 = null;

        AntlrDatatypeRuleToken lv_id_16_0 = null;



        	enterRule();

        try {
            // InternalCeffective.g:1632:2: ( ( () this_OBJECT_START_1= RULE_OBJECT_START otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON (otherlv_6= 'zonaNombre' this_EQUALS_7= RULE_EQUALS ( (lv_zonaNombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'zonaDisponibilidad' this_EQUALS_11= RULE_EQUALS ( (lv_zonaDisponibilidad_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? otherlv_14= 'id' this_EQUALS_15= RULE_EQUALS ( (lv_id_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON (otherlv_18= 'vpc' this_EQUALS_19= RULE_EQUALS ( ( ruleFQN ) ) this_SEMICOLON_21= RULE_SEMICOLON )? this_OBJECT_END_22= RULE_OBJECT_END ) )
            // InternalCeffective.g:1633:2: ( () this_OBJECT_START_1= RULE_OBJECT_START otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON (otherlv_6= 'zonaNombre' this_EQUALS_7= RULE_EQUALS ( (lv_zonaNombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'zonaDisponibilidad' this_EQUALS_11= RULE_EQUALS ( (lv_zonaDisponibilidad_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? otherlv_14= 'id' this_EQUALS_15= RULE_EQUALS ( (lv_id_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON (otherlv_18= 'vpc' this_EQUALS_19= RULE_EQUALS ( ( ruleFQN ) ) this_SEMICOLON_21= RULE_SEMICOLON )? this_OBJECT_END_22= RULE_OBJECT_END )
            {
            // InternalCeffective.g:1633:2: ( () this_OBJECT_START_1= RULE_OBJECT_START otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON (otherlv_6= 'zonaNombre' this_EQUALS_7= RULE_EQUALS ( (lv_zonaNombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'zonaDisponibilidad' this_EQUALS_11= RULE_EQUALS ( (lv_zonaDisponibilidad_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? otherlv_14= 'id' this_EQUALS_15= RULE_EQUALS ( (lv_id_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON (otherlv_18= 'vpc' this_EQUALS_19= RULE_EQUALS ( ( ruleFQN ) ) this_SEMICOLON_21= RULE_SEMICOLON )? this_OBJECT_END_22= RULE_OBJECT_END )
            // InternalCeffective.g:1634:3: () this_OBJECT_START_1= RULE_OBJECT_START otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON (otherlv_6= 'zonaNombre' this_EQUALS_7= RULE_EQUALS ( (lv_zonaNombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'zonaDisponibilidad' this_EQUALS_11= RULE_EQUALS ( (lv_zonaDisponibilidad_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? otherlv_14= 'id' this_EQUALS_15= RULE_EQUALS ( (lv_id_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON (otherlv_18= 'vpc' this_EQUALS_19= RULE_EQUALS ( ( ruleFQN ) ) this_SEMICOLON_21= RULE_SEMICOLON )? this_OBJECT_END_22= RULE_OBJECT_END
            {
            // InternalCeffective.g:1634:3: ()
            // InternalCeffective.g:1635:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getInternetGatewayAccess().getInternetGatewayAction_0(),
            					current);
            			

            }

            this_OBJECT_START_1=(Token)match(input,RULE_OBJECT_START,FOLLOW_39); 

            			newLeafNode(this_OBJECT_START_1, grammarAccess.getInternetGatewayAccess().getOBJECT_STARTTerminalRuleCall_1());
            		
            otherlv_2=(Token)match(input,30,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getInternetGatewayAccess().getNombreKeyword_2());
            		
            this_EQUALS_3=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

            			newLeafNode(this_EQUALS_3, grammarAccess.getInternetGatewayAccess().getEQUALSTerminalRuleCall_3());
            		
            // InternalCeffective.g:1653:3: ( (lv_nombre_4_0= ruleEString ) )
            // InternalCeffective.g:1654:4: (lv_nombre_4_0= ruleEString )
            {
            // InternalCeffective.g:1654:4: (lv_nombre_4_0= ruleEString )
            // InternalCeffective.g:1655:5: lv_nombre_4_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getInternetGatewayAccess().getNombreEStringParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_7);
            lv_nombre_4_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getInternetGatewayRule());
            					}
            					set(
            						current,
            						"nombre",
            						lv_nombre_4_0,
            						"org.xtext.example.ceffective.Ceffective.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_SEMICOLON_5=(Token)match(input,RULE_SEMICOLON,FOLLOW_40); 

            			newLeafNode(this_SEMICOLON_5, grammarAccess.getInternetGatewayAccess().getSEMICOLONTerminalRuleCall_5());
            		
            // InternalCeffective.g:1676:3: (otherlv_6= 'zonaNombre' this_EQUALS_7= RULE_EQUALS ( (lv_zonaNombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )?
            int alt30=2;
            int LA30_0 = input.LA(1);

            if ( (LA30_0==40) ) {
                alt30=1;
            }
            switch (alt30) {
                case 1 :
                    // InternalCeffective.g:1677:4: otherlv_6= 'zonaNombre' this_EQUALS_7= RULE_EQUALS ( (lv_zonaNombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON
                    {
                    otherlv_6=(Token)match(input,40,FOLLOW_6); 

                    				newLeafNode(otherlv_6, grammarAccess.getInternetGatewayAccess().getZonaNombreKeyword_6_0());
                    			
                    this_EQUALS_7=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_7, grammarAccess.getInternetGatewayAccess().getEQUALSTerminalRuleCall_6_1());
                    			
                    // InternalCeffective.g:1685:4: ( (lv_zonaNombre_8_0= ruleEString ) )
                    // InternalCeffective.g:1686:5: (lv_zonaNombre_8_0= ruleEString )
                    {
                    // InternalCeffective.g:1686:5: (lv_zonaNombre_8_0= ruleEString )
                    // InternalCeffective.g:1687:6: lv_zonaNombre_8_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getInternetGatewayAccess().getZonaNombreEStringParserRuleCall_6_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_zonaNombre_8_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getInternetGatewayRule());
                    						}
                    						set(
                    							current,
                    							"zonaNombre",
                    							lv_zonaNombre_8_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_41); 

                    				newLeafNode(this_SEMICOLON_9, grammarAccess.getInternetGatewayAccess().getSEMICOLONTerminalRuleCall_6_3());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:1709:3: (otherlv_10= 'zonaDisponibilidad' this_EQUALS_11= RULE_EQUALS ( (lv_zonaDisponibilidad_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )?
            int alt31=2;
            int LA31_0 = input.LA(1);

            if ( (LA31_0==41) ) {
                alt31=1;
            }
            switch (alt31) {
                case 1 :
                    // InternalCeffective.g:1710:4: otherlv_10= 'zonaDisponibilidad' this_EQUALS_11= RULE_EQUALS ( (lv_zonaDisponibilidad_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON
                    {
                    otherlv_10=(Token)match(input,41,FOLLOW_6); 

                    				newLeafNode(otherlv_10, grammarAccess.getInternetGatewayAccess().getZonaDisponibilidadKeyword_7_0());
                    			
                    this_EQUALS_11=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_11, grammarAccess.getInternetGatewayAccess().getEQUALSTerminalRuleCall_7_1());
                    			
                    // InternalCeffective.g:1718:4: ( (lv_zonaDisponibilidad_12_0= ruleEString ) )
                    // InternalCeffective.g:1719:5: (lv_zonaDisponibilidad_12_0= ruleEString )
                    {
                    // InternalCeffective.g:1719:5: (lv_zonaDisponibilidad_12_0= ruleEString )
                    // InternalCeffective.g:1720:6: lv_zonaDisponibilidad_12_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getInternetGatewayAccess().getZonaDisponibilidadEStringParserRuleCall_7_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_zonaDisponibilidad_12_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getInternetGatewayRule());
                    						}
                    						set(
                    							current,
                    							"zonaDisponibilidad",
                    							lv_zonaDisponibilidad_12_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_13=(Token)match(input,RULE_SEMICOLON,FOLLOW_36); 

                    				newLeafNode(this_SEMICOLON_13, grammarAccess.getInternetGatewayAccess().getSEMICOLONTerminalRuleCall_7_3());
                    			

                    }
                    break;

            }

            otherlv_14=(Token)match(input,37,FOLLOW_6); 

            			newLeafNode(otherlv_14, grammarAccess.getInternetGatewayAccess().getIdKeyword_8());
            		
            this_EQUALS_15=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

            			newLeafNode(this_EQUALS_15, grammarAccess.getInternetGatewayAccess().getEQUALSTerminalRuleCall_9());
            		
            // InternalCeffective.g:1750:3: ( (lv_id_16_0= ruleEString ) )
            // InternalCeffective.g:1751:4: (lv_id_16_0= ruleEString )
            {
            // InternalCeffective.g:1751:4: (lv_id_16_0= ruleEString )
            // InternalCeffective.g:1752:5: lv_id_16_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getInternetGatewayAccess().getIdEStringParserRuleCall_10_0());
            				
            pushFollow(FOLLOW_7);
            lv_id_16_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getInternetGatewayRule());
            					}
            					set(
            						current,
            						"id",
            						lv_id_16_0,
            						"org.xtext.example.ceffective.Ceffective.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_SEMICOLON_17=(Token)match(input,RULE_SEMICOLON,FOLLOW_43); 

            			newLeafNode(this_SEMICOLON_17, grammarAccess.getInternetGatewayAccess().getSEMICOLONTerminalRuleCall_11());
            		
            // InternalCeffective.g:1773:3: (otherlv_18= 'vpc' this_EQUALS_19= RULE_EQUALS ( ( ruleFQN ) ) this_SEMICOLON_21= RULE_SEMICOLON )?
            int alt32=2;
            int LA32_0 = input.LA(1);

            if ( (LA32_0==42) ) {
                alt32=1;
            }
            switch (alt32) {
                case 1 :
                    // InternalCeffective.g:1774:4: otherlv_18= 'vpc' this_EQUALS_19= RULE_EQUALS ( ( ruleFQN ) ) this_SEMICOLON_21= RULE_SEMICOLON
                    {
                    otherlv_18=(Token)match(input,42,FOLLOW_6); 

                    				newLeafNode(otherlv_18, grammarAccess.getInternetGatewayAccess().getVpcKeyword_12_0());
                    			
                    this_EQUALS_19=(Token)match(input,RULE_EQUALS,FOLLOW_33); 

                    				newLeafNode(this_EQUALS_19, grammarAccess.getInternetGatewayAccess().getEQUALSTerminalRuleCall_12_1());
                    			
                    // InternalCeffective.g:1782:4: ( ( ruleFQN ) )
                    // InternalCeffective.g:1783:5: ( ruleFQN )
                    {
                    // InternalCeffective.g:1783:5: ( ruleFQN )
                    // InternalCeffective.g:1784:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getInternetGatewayRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getInternetGatewayAccess().getVpcVPCCrossReference_12_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_21=(Token)match(input,RULE_SEMICOLON,FOLLOW_8); 

                    				newLeafNode(this_SEMICOLON_21, grammarAccess.getInternetGatewayAccess().getSEMICOLONTerminalRuleCall_12_3());
                    			

                    }
                    break;

            }

            this_OBJECT_END_22=(Token)match(input,RULE_OBJECT_END,FOLLOW_2); 

            			newLeafNode(this_OBJECT_END_22, grammarAccess.getInternetGatewayAccess().getOBJECT_ENDTerminalRuleCall_13());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInternetGateway"


    // $ANTLR start "entryRuleGrupoSeguridad"
    // InternalCeffective.g:1811:1: entryRuleGrupoSeguridad returns [EObject current=null] : iv_ruleGrupoSeguridad= ruleGrupoSeguridad EOF ;
    public final EObject entryRuleGrupoSeguridad() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleGrupoSeguridad = null;


        try {
            // InternalCeffective.g:1811:55: (iv_ruleGrupoSeguridad= ruleGrupoSeguridad EOF )
            // InternalCeffective.g:1812:2: iv_ruleGrupoSeguridad= ruleGrupoSeguridad EOF
            {
             newCompositeNode(grammarAccess.getGrupoSeguridadRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleGrupoSeguridad=ruleGrupoSeguridad();

            state._fsp--;

             current =iv_ruleGrupoSeguridad; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleGrupoSeguridad"


    // $ANTLR start "ruleGrupoSeguridad"
    // InternalCeffective.g:1818:1: ruleGrupoSeguridad returns [EObject current=null] : ( () this_OBJECT_START_1= RULE_OBJECT_START otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON (otherlv_6= 'zonaNombre' this_EQUALS_7= RULE_EQUALS ( (lv_zonaNombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'zonaDisponibilidad' this_EQUALS_11= RULE_EQUALS ( (lv_zonaDisponibilidad_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? otherlv_14= 'id' this_EQUALS_15= RULE_EQUALS ( (lv_id_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON (otherlv_18= 'descripcion' this_EQUALS_19= RULE_EQUALS ( (lv_descripcion_20_0= ruleEString ) ) this_SEMICOLON_21= RULE_SEMICOLON )? (otherlv_22= 'vpc' this_EQUALS_23= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_25= RULE_SEMICOLON )? otherlv_26= 'reglas' this_EQUALS_27= RULE_EQUALS this_LIST_START_28= RULE_LIST_START ( (lv_reglas_29_0= ruleRegla ) ) (this_COMA_30= RULE_COMA ( (lv_reglas_31_0= ruleRegla ) ) )* this_LIST_END_32= RULE_LIST_END this_OBJECT_END_33= RULE_OBJECT_END ) ;
    public final EObject ruleGrupoSeguridad() throws RecognitionException {
        EObject current = null;

        Token this_OBJECT_START_1=null;
        Token otherlv_2=null;
        Token this_EQUALS_3=null;
        Token this_SEMICOLON_5=null;
        Token otherlv_6=null;
        Token this_EQUALS_7=null;
        Token this_SEMICOLON_9=null;
        Token otherlv_10=null;
        Token this_EQUALS_11=null;
        Token this_SEMICOLON_13=null;
        Token otherlv_14=null;
        Token this_EQUALS_15=null;
        Token this_SEMICOLON_17=null;
        Token otherlv_18=null;
        Token this_EQUALS_19=null;
        Token this_SEMICOLON_21=null;
        Token otherlv_22=null;
        Token this_EQUALS_23=null;
        Token this_SEMICOLON_25=null;
        Token otherlv_26=null;
        Token this_EQUALS_27=null;
        Token this_LIST_START_28=null;
        Token this_COMA_30=null;
        Token this_LIST_END_32=null;
        Token this_OBJECT_END_33=null;
        AntlrDatatypeRuleToken lv_nombre_4_0 = null;

        AntlrDatatypeRuleToken lv_zonaNombre_8_0 = null;

        AntlrDatatypeRuleToken lv_zonaDisponibilidad_12_0 = null;

        AntlrDatatypeRuleToken lv_id_16_0 = null;

        AntlrDatatypeRuleToken lv_descripcion_20_0 = null;

        EObject lv_reglas_29_0 = null;

        EObject lv_reglas_31_0 = null;



        	enterRule();

        try {
            // InternalCeffective.g:1824:2: ( ( () this_OBJECT_START_1= RULE_OBJECT_START otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON (otherlv_6= 'zonaNombre' this_EQUALS_7= RULE_EQUALS ( (lv_zonaNombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'zonaDisponibilidad' this_EQUALS_11= RULE_EQUALS ( (lv_zonaDisponibilidad_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? otherlv_14= 'id' this_EQUALS_15= RULE_EQUALS ( (lv_id_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON (otherlv_18= 'descripcion' this_EQUALS_19= RULE_EQUALS ( (lv_descripcion_20_0= ruleEString ) ) this_SEMICOLON_21= RULE_SEMICOLON )? (otherlv_22= 'vpc' this_EQUALS_23= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_25= RULE_SEMICOLON )? otherlv_26= 'reglas' this_EQUALS_27= RULE_EQUALS this_LIST_START_28= RULE_LIST_START ( (lv_reglas_29_0= ruleRegla ) ) (this_COMA_30= RULE_COMA ( (lv_reglas_31_0= ruleRegla ) ) )* this_LIST_END_32= RULE_LIST_END this_OBJECT_END_33= RULE_OBJECT_END ) )
            // InternalCeffective.g:1825:2: ( () this_OBJECT_START_1= RULE_OBJECT_START otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON (otherlv_6= 'zonaNombre' this_EQUALS_7= RULE_EQUALS ( (lv_zonaNombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'zonaDisponibilidad' this_EQUALS_11= RULE_EQUALS ( (lv_zonaDisponibilidad_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? otherlv_14= 'id' this_EQUALS_15= RULE_EQUALS ( (lv_id_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON (otherlv_18= 'descripcion' this_EQUALS_19= RULE_EQUALS ( (lv_descripcion_20_0= ruleEString ) ) this_SEMICOLON_21= RULE_SEMICOLON )? (otherlv_22= 'vpc' this_EQUALS_23= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_25= RULE_SEMICOLON )? otherlv_26= 'reglas' this_EQUALS_27= RULE_EQUALS this_LIST_START_28= RULE_LIST_START ( (lv_reglas_29_0= ruleRegla ) ) (this_COMA_30= RULE_COMA ( (lv_reglas_31_0= ruleRegla ) ) )* this_LIST_END_32= RULE_LIST_END this_OBJECT_END_33= RULE_OBJECT_END )
            {
            // InternalCeffective.g:1825:2: ( () this_OBJECT_START_1= RULE_OBJECT_START otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON (otherlv_6= 'zonaNombre' this_EQUALS_7= RULE_EQUALS ( (lv_zonaNombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'zonaDisponibilidad' this_EQUALS_11= RULE_EQUALS ( (lv_zonaDisponibilidad_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? otherlv_14= 'id' this_EQUALS_15= RULE_EQUALS ( (lv_id_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON (otherlv_18= 'descripcion' this_EQUALS_19= RULE_EQUALS ( (lv_descripcion_20_0= ruleEString ) ) this_SEMICOLON_21= RULE_SEMICOLON )? (otherlv_22= 'vpc' this_EQUALS_23= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_25= RULE_SEMICOLON )? otherlv_26= 'reglas' this_EQUALS_27= RULE_EQUALS this_LIST_START_28= RULE_LIST_START ( (lv_reglas_29_0= ruleRegla ) ) (this_COMA_30= RULE_COMA ( (lv_reglas_31_0= ruleRegla ) ) )* this_LIST_END_32= RULE_LIST_END this_OBJECT_END_33= RULE_OBJECT_END )
            // InternalCeffective.g:1826:3: () this_OBJECT_START_1= RULE_OBJECT_START otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON (otherlv_6= 'zonaNombre' this_EQUALS_7= RULE_EQUALS ( (lv_zonaNombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'zonaDisponibilidad' this_EQUALS_11= RULE_EQUALS ( (lv_zonaDisponibilidad_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? otherlv_14= 'id' this_EQUALS_15= RULE_EQUALS ( (lv_id_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON (otherlv_18= 'descripcion' this_EQUALS_19= RULE_EQUALS ( (lv_descripcion_20_0= ruleEString ) ) this_SEMICOLON_21= RULE_SEMICOLON )? (otherlv_22= 'vpc' this_EQUALS_23= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_25= RULE_SEMICOLON )? otherlv_26= 'reglas' this_EQUALS_27= RULE_EQUALS this_LIST_START_28= RULE_LIST_START ( (lv_reglas_29_0= ruleRegla ) ) (this_COMA_30= RULE_COMA ( (lv_reglas_31_0= ruleRegla ) ) )* this_LIST_END_32= RULE_LIST_END this_OBJECT_END_33= RULE_OBJECT_END
            {
            // InternalCeffective.g:1826:3: ()
            // InternalCeffective.g:1827:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getGrupoSeguridadAccess().getGrupoSeguridadAction_0(),
            					current);
            			

            }

            this_OBJECT_START_1=(Token)match(input,RULE_OBJECT_START,FOLLOW_39); 

            			newLeafNode(this_OBJECT_START_1, grammarAccess.getGrupoSeguridadAccess().getOBJECT_STARTTerminalRuleCall_1());
            		
            otherlv_2=(Token)match(input,30,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getGrupoSeguridadAccess().getNombreKeyword_2());
            		
            this_EQUALS_3=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

            			newLeafNode(this_EQUALS_3, grammarAccess.getGrupoSeguridadAccess().getEQUALSTerminalRuleCall_3());
            		
            // InternalCeffective.g:1845:3: ( (lv_nombre_4_0= ruleEString ) )
            // InternalCeffective.g:1846:4: (lv_nombre_4_0= ruleEString )
            {
            // InternalCeffective.g:1846:4: (lv_nombre_4_0= ruleEString )
            // InternalCeffective.g:1847:5: lv_nombre_4_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getGrupoSeguridadAccess().getNombreEStringParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_7);
            lv_nombre_4_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getGrupoSeguridadRule());
            					}
            					set(
            						current,
            						"nombre",
            						lv_nombre_4_0,
            						"org.xtext.example.ceffective.Ceffective.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_SEMICOLON_5=(Token)match(input,RULE_SEMICOLON,FOLLOW_40); 

            			newLeafNode(this_SEMICOLON_5, grammarAccess.getGrupoSeguridadAccess().getSEMICOLONTerminalRuleCall_5());
            		
            // InternalCeffective.g:1868:3: (otherlv_6= 'zonaNombre' this_EQUALS_7= RULE_EQUALS ( (lv_zonaNombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )?
            int alt33=2;
            int LA33_0 = input.LA(1);

            if ( (LA33_0==40) ) {
                alt33=1;
            }
            switch (alt33) {
                case 1 :
                    // InternalCeffective.g:1869:4: otherlv_6= 'zonaNombre' this_EQUALS_7= RULE_EQUALS ( (lv_zonaNombre_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON
                    {
                    otherlv_6=(Token)match(input,40,FOLLOW_6); 

                    				newLeafNode(otherlv_6, grammarAccess.getGrupoSeguridadAccess().getZonaNombreKeyword_6_0());
                    			
                    this_EQUALS_7=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_7, grammarAccess.getGrupoSeguridadAccess().getEQUALSTerminalRuleCall_6_1());
                    			
                    // InternalCeffective.g:1877:4: ( (lv_zonaNombre_8_0= ruleEString ) )
                    // InternalCeffective.g:1878:5: (lv_zonaNombre_8_0= ruleEString )
                    {
                    // InternalCeffective.g:1878:5: (lv_zonaNombre_8_0= ruleEString )
                    // InternalCeffective.g:1879:6: lv_zonaNombre_8_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getGrupoSeguridadAccess().getZonaNombreEStringParserRuleCall_6_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_zonaNombre_8_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getGrupoSeguridadRule());
                    						}
                    						set(
                    							current,
                    							"zonaNombre",
                    							lv_zonaNombre_8_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_41); 

                    				newLeafNode(this_SEMICOLON_9, grammarAccess.getGrupoSeguridadAccess().getSEMICOLONTerminalRuleCall_6_3());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:1901:3: (otherlv_10= 'zonaDisponibilidad' this_EQUALS_11= RULE_EQUALS ( (lv_zonaDisponibilidad_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )?
            int alt34=2;
            int LA34_0 = input.LA(1);

            if ( (LA34_0==41) ) {
                alt34=1;
            }
            switch (alt34) {
                case 1 :
                    // InternalCeffective.g:1902:4: otherlv_10= 'zonaDisponibilidad' this_EQUALS_11= RULE_EQUALS ( (lv_zonaDisponibilidad_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON
                    {
                    otherlv_10=(Token)match(input,41,FOLLOW_6); 

                    				newLeafNode(otherlv_10, grammarAccess.getGrupoSeguridadAccess().getZonaDisponibilidadKeyword_7_0());
                    			
                    this_EQUALS_11=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_11, grammarAccess.getGrupoSeguridadAccess().getEQUALSTerminalRuleCall_7_1());
                    			
                    // InternalCeffective.g:1910:4: ( (lv_zonaDisponibilidad_12_0= ruleEString ) )
                    // InternalCeffective.g:1911:5: (lv_zonaDisponibilidad_12_0= ruleEString )
                    {
                    // InternalCeffective.g:1911:5: (lv_zonaDisponibilidad_12_0= ruleEString )
                    // InternalCeffective.g:1912:6: lv_zonaDisponibilidad_12_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getGrupoSeguridadAccess().getZonaDisponibilidadEStringParserRuleCall_7_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_zonaDisponibilidad_12_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getGrupoSeguridadRule());
                    						}
                    						set(
                    							current,
                    							"zonaDisponibilidad",
                    							lv_zonaDisponibilidad_12_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_13=(Token)match(input,RULE_SEMICOLON,FOLLOW_36); 

                    				newLeafNode(this_SEMICOLON_13, grammarAccess.getGrupoSeguridadAccess().getSEMICOLONTerminalRuleCall_7_3());
                    			

                    }
                    break;

            }

            otherlv_14=(Token)match(input,37,FOLLOW_6); 

            			newLeafNode(otherlv_14, grammarAccess.getGrupoSeguridadAccess().getIdKeyword_8());
            		
            this_EQUALS_15=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

            			newLeafNode(this_EQUALS_15, grammarAccess.getGrupoSeguridadAccess().getEQUALSTerminalRuleCall_9());
            		
            // InternalCeffective.g:1942:3: ( (lv_id_16_0= ruleEString ) )
            // InternalCeffective.g:1943:4: (lv_id_16_0= ruleEString )
            {
            // InternalCeffective.g:1943:4: (lv_id_16_0= ruleEString )
            // InternalCeffective.g:1944:5: lv_id_16_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getGrupoSeguridadAccess().getIdEStringParserRuleCall_10_0());
            				
            pushFollow(FOLLOW_7);
            lv_id_16_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getGrupoSeguridadRule());
            					}
            					set(
            						current,
            						"id",
            						lv_id_16_0,
            						"org.xtext.example.ceffective.Ceffective.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_SEMICOLON_17=(Token)match(input,RULE_SEMICOLON,FOLLOW_44); 

            			newLeafNode(this_SEMICOLON_17, grammarAccess.getGrupoSeguridadAccess().getSEMICOLONTerminalRuleCall_11());
            		
            // InternalCeffective.g:1965:3: (otherlv_18= 'descripcion' this_EQUALS_19= RULE_EQUALS ( (lv_descripcion_20_0= ruleEString ) ) this_SEMICOLON_21= RULE_SEMICOLON )?
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( (LA35_0==43) ) {
                alt35=1;
            }
            switch (alt35) {
                case 1 :
                    // InternalCeffective.g:1966:4: otherlv_18= 'descripcion' this_EQUALS_19= RULE_EQUALS ( (lv_descripcion_20_0= ruleEString ) ) this_SEMICOLON_21= RULE_SEMICOLON
                    {
                    otherlv_18=(Token)match(input,43,FOLLOW_6); 

                    				newLeafNode(otherlv_18, grammarAccess.getGrupoSeguridadAccess().getDescripcionKeyword_12_0());
                    			
                    this_EQUALS_19=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_19, grammarAccess.getGrupoSeguridadAccess().getEQUALSTerminalRuleCall_12_1());
                    			
                    // InternalCeffective.g:1974:4: ( (lv_descripcion_20_0= ruleEString ) )
                    // InternalCeffective.g:1975:5: (lv_descripcion_20_0= ruleEString )
                    {
                    // InternalCeffective.g:1975:5: (lv_descripcion_20_0= ruleEString )
                    // InternalCeffective.g:1976:6: lv_descripcion_20_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getGrupoSeguridadAccess().getDescripcionEStringParserRuleCall_12_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_descripcion_20_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getGrupoSeguridadRule());
                    						}
                    						set(
                    							current,
                    							"descripcion",
                    							lv_descripcion_20_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_21=(Token)match(input,RULE_SEMICOLON,FOLLOW_45); 

                    				newLeafNode(this_SEMICOLON_21, grammarAccess.getGrupoSeguridadAccess().getSEMICOLONTerminalRuleCall_12_3());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:1998:3: (otherlv_22= 'vpc' this_EQUALS_23= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_25= RULE_SEMICOLON )?
            int alt36=2;
            int LA36_0 = input.LA(1);

            if ( (LA36_0==42) ) {
                alt36=1;
            }
            switch (alt36) {
                case 1 :
                    // InternalCeffective.g:1999:4: otherlv_22= 'vpc' this_EQUALS_23= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_25= RULE_SEMICOLON
                    {
                    otherlv_22=(Token)match(input,42,FOLLOW_6); 

                    				newLeafNode(otherlv_22, grammarAccess.getGrupoSeguridadAccess().getVpcKeyword_13_0());
                    			
                    this_EQUALS_23=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_23, grammarAccess.getGrupoSeguridadAccess().getEQUALSTerminalRuleCall_13_1());
                    			
                    // InternalCeffective.g:2007:4: ( ( ruleEString ) )
                    // InternalCeffective.g:2008:5: ( ruleEString )
                    {
                    // InternalCeffective.g:2008:5: ( ruleEString )
                    // InternalCeffective.g:2009:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getGrupoSeguridadRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getGrupoSeguridadAccess().getVpcVPCCrossReference_13_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_25=(Token)match(input,RULE_SEMICOLON,FOLLOW_46); 

                    				newLeafNode(this_SEMICOLON_25, grammarAccess.getGrupoSeguridadAccess().getSEMICOLONTerminalRuleCall_13_3());
                    			

                    }
                    break;

            }

            otherlv_26=(Token)match(input,44,FOLLOW_6); 

            			newLeafNode(otherlv_26, grammarAccess.getGrupoSeguridadAccess().getReglasKeyword_14());
            		
            this_EQUALS_27=(Token)match(input,RULE_EQUALS,FOLLOW_15); 

            			newLeafNode(this_EQUALS_27, grammarAccess.getGrupoSeguridadAccess().getEQUALSTerminalRuleCall_15());
            		
            this_LIST_START_28=(Token)match(input,RULE_LIST_START,FOLLOW_4); 

            			newLeafNode(this_LIST_START_28, grammarAccess.getGrupoSeguridadAccess().getLIST_STARTTerminalRuleCall_16());
            		
            // InternalCeffective.g:2040:3: ( (lv_reglas_29_0= ruleRegla ) )
            // InternalCeffective.g:2041:4: (lv_reglas_29_0= ruleRegla )
            {
            // InternalCeffective.g:2041:4: (lv_reglas_29_0= ruleRegla )
            // InternalCeffective.g:2042:5: lv_reglas_29_0= ruleRegla
            {

            					newCompositeNode(grammarAccess.getGrupoSeguridadAccess().getReglasReglaParserRuleCall_17_0());
            				
            pushFollow(FOLLOW_16);
            lv_reglas_29_0=ruleRegla();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getGrupoSeguridadRule());
            					}
            					add(
            						current,
            						"reglas",
            						lv_reglas_29_0,
            						"org.xtext.example.ceffective.Ceffective.Regla");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalCeffective.g:2059:3: (this_COMA_30= RULE_COMA ( (lv_reglas_31_0= ruleRegla ) ) )*
            loop37:
            do {
                int alt37=2;
                int LA37_0 = input.LA(1);

                if ( (LA37_0==RULE_COMA) ) {
                    alt37=1;
                }


                switch (alt37) {
            	case 1 :
            	    // InternalCeffective.g:2060:4: this_COMA_30= RULE_COMA ( (lv_reglas_31_0= ruleRegla ) )
            	    {
            	    this_COMA_30=(Token)match(input,RULE_COMA,FOLLOW_4); 

            	    				newLeafNode(this_COMA_30, grammarAccess.getGrupoSeguridadAccess().getCOMATerminalRuleCall_18_0());
            	    			
            	    // InternalCeffective.g:2064:4: ( (lv_reglas_31_0= ruleRegla ) )
            	    // InternalCeffective.g:2065:5: (lv_reglas_31_0= ruleRegla )
            	    {
            	    // InternalCeffective.g:2065:5: (lv_reglas_31_0= ruleRegla )
            	    // InternalCeffective.g:2066:6: lv_reglas_31_0= ruleRegla
            	    {

            	    						newCompositeNode(grammarAccess.getGrupoSeguridadAccess().getReglasReglaParserRuleCall_18_1_0());
            	    					
            	    pushFollow(FOLLOW_16);
            	    lv_reglas_31_0=ruleRegla();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getGrupoSeguridadRule());
            	    						}
            	    						add(
            	    							current,
            	    							"reglas",
            	    							lv_reglas_31_0,
            	    							"org.xtext.example.ceffective.Ceffective.Regla");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop37;
                }
            } while (true);

            this_LIST_END_32=(Token)match(input,RULE_LIST_END,FOLLOW_8); 

            			newLeafNode(this_LIST_END_32, grammarAccess.getGrupoSeguridadAccess().getLIST_ENDTerminalRuleCall_19());
            		
            this_OBJECT_END_33=(Token)match(input,RULE_OBJECT_END,FOLLOW_2); 

            			newLeafNode(this_OBJECT_END_33, grammarAccess.getGrupoSeguridadAccess().getOBJECT_ENDTerminalRuleCall_20());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleGrupoSeguridad"


    // $ANTLR start "entryRuleRegla"
    // InternalCeffective.g:2096:1: entryRuleRegla returns [EObject current=null] : iv_ruleRegla= ruleRegla EOF ;
    public final EObject entryRuleRegla() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRegla = null;


        try {
            // InternalCeffective.g:2096:46: (iv_ruleRegla= ruleRegla EOF )
            // InternalCeffective.g:2097:2: iv_ruleRegla= ruleRegla EOF
            {
             newCompositeNode(grammarAccess.getReglaRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRegla=ruleRegla();

            state._fsp--;

             current =iv_ruleRegla; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRegla"


    // $ANTLR start "ruleRegla"
    // InternalCeffective.g:2103:1: ruleRegla returns [EObject current=null] : ( () this_OBJECT_START_1= RULE_OBJECT_START (otherlv_2= 'tipo' this_EQUALS_3= RULE_EQUALS ( (lv_tipo_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON )? (otherlv_6= 'protocolo' this_EQUALS_7= RULE_EQUALS ( (lv_protocolo_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'puerto' this_EQUALS_11= RULE_EQUALS ( (lv_puerto_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? (otherlv_14= 'origen' this_EQUALS_15= RULE_EQUALS ( (lv_origen_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON )? (otherlv_18= 'descripcion' this_EQUALS_19= RULE_EQUALS ( (lv_descripcion_20_0= ruleEString ) ) this_SEMICOLON_21= RULE_SEMICOLON )? otherlv_22= 'direccion' this_EQUALS_23= RULE_EQUALS ( (lv_direccion_24_0= ruleDireccionRegla ) ) this_SEMICOLON_25= RULE_SEMICOLON this_OBJECT_END_26= RULE_OBJECT_END ) ;
    public final EObject ruleRegla() throws RecognitionException {
        EObject current = null;

        Token this_OBJECT_START_1=null;
        Token otherlv_2=null;
        Token this_EQUALS_3=null;
        Token this_SEMICOLON_5=null;
        Token otherlv_6=null;
        Token this_EQUALS_7=null;
        Token this_SEMICOLON_9=null;
        Token otherlv_10=null;
        Token this_EQUALS_11=null;
        Token this_SEMICOLON_13=null;
        Token otherlv_14=null;
        Token this_EQUALS_15=null;
        Token this_SEMICOLON_17=null;
        Token otherlv_18=null;
        Token this_EQUALS_19=null;
        Token this_SEMICOLON_21=null;
        Token otherlv_22=null;
        Token this_EQUALS_23=null;
        Token this_SEMICOLON_25=null;
        Token this_OBJECT_END_26=null;
        AntlrDatatypeRuleToken lv_tipo_4_0 = null;

        AntlrDatatypeRuleToken lv_protocolo_8_0 = null;

        AntlrDatatypeRuleToken lv_puerto_12_0 = null;

        AntlrDatatypeRuleToken lv_origen_16_0 = null;

        AntlrDatatypeRuleToken lv_descripcion_20_0 = null;

        Enumerator lv_direccion_24_0 = null;



        	enterRule();

        try {
            // InternalCeffective.g:2109:2: ( ( () this_OBJECT_START_1= RULE_OBJECT_START (otherlv_2= 'tipo' this_EQUALS_3= RULE_EQUALS ( (lv_tipo_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON )? (otherlv_6= 'protocolo' this_EQUALS_7= RULE_EQUALS ( (lv_protocolo_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'puerto' this_EQUALS_11= RULE_EQUALS ( (lv_puerto_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? (otherlv_14= 'origen' this_EQUALS_15= RULE_EQUALS ( (lv_origen_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON )? (otherlv_18= 'descripcion' this_EQUALS_19= RULE_EQUALS ( (lv_descripcion_20_0= ruleEString ) ) this_SEMICOLON_21= RULE_SEMICOLON )? otherlv_22= 'direccion' this_EQUALS_23= RULE_EQUALS ( (lv_direccion_24_0= ruleDireccionRegla ) ) this_SEMICOLON_25= RULE_SEMICOLON this_OBJECT_END_26= RULE_OBJECT_END ) )
            // InternalCeffective.g:2110:2: ( () this_OBJECT_START_1= RULE_OBJECT_START (otherlv_2= 'tipo' this_EQUALS_3= RULE_EQUALS ( (lv_tipo_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON )? (otherlv_6= 'protocolo' this_EQUALS_7= RULE_EQUALS ( (lv_protocolo_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'puerto' this_EQUALS_11= RULE_EQUALS ( (lv_puerto_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? (otherlv_14= 'origen' this_EQUALS_15= RULE_EQUALS ( (lv_origen_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON )? (otherlv_18= 'descripcion' this_EQUALS_19= RULE_EQUALS ( (lv_descripcion_20_0= ruleEString ) ) this_SEMICOLON_21= RULE_SEMICOLON )? otherlv_22= 'direccion' this_EQUALS_23= RULE_EQUALS ( (lv_direccion_24_0= ruleDireccionRegla ) ) this_SEMICOLON_25= RULE_SEMICOLON this_OBJECT_END_26= RULE_OBJECT_END )
            {
            // InternalCeffective.g:2110:2: ( () this_OBJECT_START_1= RULE_OBJECT_START (otherlv_2= 'tipo' this_EQUALS_3= RULE_EQUALS ( (lv_tipo_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON )? (otherlv_6= 'protocolo' this_EQUALS_7= RULE_EQUALS ( (lv_protocolo_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'puerto' this_EQUALS_11= RULE_EQUALS ( (lv_puerto_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? (otherlv_14= 'origen' this_EQUALS_15= RULE_EQUALS ( (lv_origen_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON )? (otherlv_18= 'descripcion' this_EQUALS_19= RULE_EQUALS ( (lv_descripcion_20_0= ruleEString ) ) this_SEMICOLON_21= RULE_SEMICOLON )? otherlv_22= 'direccion' this_EQUALS_23= RULE_EQUALS ( (lv_direccion_24_0= ruleDireccionRegla ) ) this_SEMICOLON_25= RULE_SEMICOLON this_OBJECT_END_26= RULE_OBJECT_END )
            // InternalCeffective.g:2111:3: () this_OBJECT_START_1= RULE_OBJECT_START (otherlv_2= 'tipo' this_EQUALS_3= RULE_EQUALS ( (lv_tipo_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON )? (otherlv_6= 'protocolo' this_EQUALS_7= RULE_EQUALS ( (lv_protocolo_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'puerto' this_EQUALS_11= RULE_EQUALS ( (lv_puerto_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? (otherlv_14= 'origen' this_EQUALS_15= RULE_EQUALS ( (lv_origen_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON )? (otherlv_18= 'descripcion' this_EQUALS_19= RULE_EQUALS ( (lv_descripcion_20_0= ruleEString ) ) this_SEMICOLON_21= RULE_SEMICOLON )? otherlv_22= 'direccion' this_EQUALS_23= RULE_EQUALS ( (lv_direccion_24_0= ruleDireccionRegla ) ) this_SEMICOLON_25= RULE_SEMICOLON this_OBJECT_END_26= RULE_OBJECT_END
            {
            // InternalCeffective.g:2111:3: ()
            // InternalCeffective.g:2112:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getReglaAccess().getReglaAction_0(),
            					current);
            			

            }

            this_OBJECT_START_1=(Token)match(input,RULE_OBJECT_START,FOLLOW_47); 

            			newLeafNode(this_OBJECT_START_1, grammarAccess.getReglaAccess().getOBJECT_STARTTerminalRuleCall_1());
            		
            // InternalCeffective.g:2122:3: (otherlv_2= 'tipo' this_EQUALS_3= RULE_EQUALS ( (lv_tipo_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON )?
            int alt38=2;
            int LA38_0 = input.LA(1);

            if ( (LA38_0==45) ) {
                alt38=1;
            }
            switch (alt38) {
                case 1 :
                    // InternalCeffective.g:2123:4: otherlv_2= 'tipo' this_EQUALS_3= RULE_EQUALS ( (lv_tipo_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON
                    {
                    otherlv_2=(Token)match(input,45,FOLLOW_6); 

                    				newLeafNode(otherlv_2, grammarAccess.getReglaAccess().getTipoKeyword_2_0());
                    			
                    this_EQUALS_3=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_3, grammarAccess.getReglaAccess().getEQUALSTerminalRuleCall_2_1());
                    			
                    // InternalCeffective.g:2131:4: ( (lv_tipo_4_0= ruleEString ) )
                    // InternalCeffective.g:2132:5: (lv_tipo_4_0= ruleEString )
                    {
                    // InternalCeffective.g:2132:5: (lv_tipo_4_0= ruleEString )
                    // InternalCeffective.g:2133:6: lv_tipo_4_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getReglaAccess().getTipoEStringParserRuleCall_2_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_tipo_4_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getReglaRule());
                    						}
                    						set(
                    							current,
                    							"tipo",
                    							lv_tipo_4_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_5=(Token)match(input,RULE_SEMICOLON,FOLLOW_48); 

                    				newLeafNode(this_SEMICOLON_5, grammarAccess.getReglaAccess().getSEMICOLONTerminalRuleCall_2_3());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:2155:3: (otherlv_6= 'protocolo' this_EQUALS_7= RULE_EQUALS ( (lv_protocolo_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )?
            int alt39=2;
            int LA39_0 = input.LA(1);

            if ( (LA39_0==46) ) {
                alt39=1;
            }
            switch (alt39) {
                case 1 :
                    // InternalCeffective.g:2156:4: otherlv_6= 'protocolo' this_EQUALS_7= RULE_EQUALS ( (lv_protocolo_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON
                    {
                    otherlv_6=(Token)match(input,46,FOLLOW_6); 

                    				newLeafNode(otherlv_6, grammarAccess.getReglaAccess().getProtocoloKeyword_3_0());
                    			
                    this_EQUALS_7=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_7, grammarAccess.getReglaAccess().getEQUALSTerminalRuleCall_3_1());
                    			
                    // InternalCeffective.g:2164:4: ( (lv_protocolo_8_0= ruleEString ) )
                    // InternalCeffective.g:2165:5: (lv_protocolo_8_0= ruleEString )
                    {
                    // InternalCeffective.g:2165:5: (lv_protocolo_8_0= ruleEString )
                    // InternalCeffective.g:2166:6: lv_protocolo_8_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getReglaAccess().getProtocoloEStringParserRuleCall_3_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_protocolo_8_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getReglaRule());
                    						}
                    						set(
                    							current,
                    							"protocolo",
                    							lv_protocolo_8_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_49); 

                    				newLeafNode(this_SEMICOLON_9, grammarAccess.getReglaAccess().getSEMICOLONTerminalRuleCall_3_3());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:2188:3: (otherlv_10= 'puerto' this_EQUALS_11= RULE_EQUALS ( (lv_puerto_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )?
            int alt40=2;
            int LA40_0 = input.LA(1);

            if ( (LA40_0==47) ) {
                alt40=1;
            }
            switch (alt40) {
                case 1 :
                    // InternalCeffective.g:2189:4: otherlv_10= 'puerto' this_EQUALS_11= RULE_EQUALS ( (lv_puerto_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON
                    {
                    otherlv_10=(Token)match(input,47,FOLLOW_6); 

                    				newLeafNode(otherlv_10, grammarAccess.getReglaAccess().getPuertoKeyword_4_0());
                    			
                    this_EQUALS_11=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_11, grammarAccess.getReglaAccess().getEQUALSTerminalRuleCall_4_1());
                    			
                    // InternalCeffective.g:2197:4: ( (lv_puerto_12_0= ruleEString ) )
                    // InternalCeffective.g:2198:5: (lv_puerto_12_0= ruleEString )
                    {
                    // InternalCeffective.g:2198:5: (lv_puerto_12_0= ruleEString )
                    // InternalCeffective.g:2199:6: lv_puerto_12_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getReglaAccess().getPuertoEStringParserRuleCall_4_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_puerto_12_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getReglaRule());
                    						}
                    						set(
                    							current,
                    							"puerto",
                    							lv_puerto_12_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_13=(Token)match(input,RULE_SEMICOLON,FOLLOW_50); 

                    				newLeafNode(this_SEMICOLON_13, grammarAccess.getReglaAccess().getSEMICOLONTerminalRuleCall_4_3());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:2221:3: (otherlv_14= 'origen' this_EQUALS_15= RULE_EQUALS ( (lv_origen_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON )?
            int alt41=2;
            int LA41_0 = input.LA(1);

            if ( (LA41_0==48) ) {
                alt41=1;
            }
            switch (alt41) {
                case 1 :
                    // InternalCeffective.g:2222:4: otherlv_14= 'origen' this_EQUALS_15= RULE_EQUALS ( (lv_origen_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON
                    {
                    otherlv_14=(Token)match(input,48,FOLLOW_6); 

                    				newLeafNode(otherlv_14, grammarAccess.getReglaAccess().getOrigenKeyword_5_0());
                    			
                    this_EQUALS_15=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_15, grammarAccess.getReglaAccess().getEQUALSTerminalRuleCall_5_1());
                    			
                    // InternalCeffective.g:2230:4: ( (lv_origen_16_0= ruleEString ) )
                    // InternalCeffective.g:2231:5: (lv_origen_16_0= ruleEString )
                    {
                    // InternalCeffective.g:2231:5: (lv_origen_16_0= ruleEString )
                    // InternalCeffective.g:2232:6: lv_origen_16_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getReglaAccess().getOrigenEStringParserRuleCall_5_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_origen_16_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getReglaRule());
                    						}
                    						set(
                    							current,
                    							"origen",
                    							lv_origen_16_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_17=(Token)match(input,RULE_SEMICOLON,FOLLOW_51); 

                    				newLeafNode(this_SEMICOLON_17, grammarAccess.getReglaAccess().getSEMICOLONTerminalRuleCall_5_3());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:2254:3: (otherlv_18= 'descripcion' this_EQUALS_19= RULE_EQUALS ( (lv_descripcion_20_0= ruleEString ) ) this_SEMICOLON_21= RULE_SEMICOLON )?
            int alt42=2;
            int LA42_0 = input.LA(1);

            if ( (LA42_0==43) ) {
                alt42=1;
            }
            switch (alt42) {
                case 1 :
                    // InternalCeffective.g:2255:4: otherlv_18= 'descripcion' this_EQUALS_19= RULE_EQUALS ( (lv_descripcion_20_0= ruleEString ) ) this_SEMICOLON_21= RULE_SEMICOLON
                    {
                    otherlv_18=(Token)match(input,43,FOLLOW_6); 

                    				newLeafNode(otherlv_18, grammarAccess.getReglaAccess().getDescripcionKeyword_6_0());
                    			
                    this_EQUALS_19=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_19, grammarAccess.getReglaAccess().getEQUALSTerminalRuleCall_6_1());
                    			
                    // InternalCeffective.g:2263:4: ( (lv_descripcion_20_0= ruleEString ) )
                    // InternalCeffective.g:2264:5: (lv_descripcion_20_0= ruleEString )
                    {
                    // InternalCeffective.g:2264:5: (lv_descripcion_20_0= ruleEString )
                    // InternalCeffective.g:2265:6: lv_descripcion_20_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getReglaAccess().getDescripcionEStringParserRuleCall_6_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_descripcion_20_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getReglaRule());
                    						}
                    						set(
                    							current,
                    							"descripcion",
                    							lv_descripcion_20_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_21=(Token)match(input,RULE_SEMICOLON,FOLLOW_52); 

                    				newLeafNode(this_SEMICOLON_21, grammarAccess.getReglaAccess().getSEMICOLONTerminalRuleCall_6_3());
                    			

                    }
                    break;

            }

            otherlv_22=(Token)match(input,49,FOLLOW_6); 

            			newLeafNode(otherlv_22, grammarAccess.getReglaAccess().getDireccionKeyword_7());
            		
            this_EQUALS_23=(Token)match(input,RULE_EQUALS,FOLLOW_53); 

            			newLeafNode(this_EQUALS_23, grammarAccess.getReglaAccess().getEQUALSTerminalRuleCall_8());
            		
            // InternalCeffective.g:2295:3: ( (lv_direccion_24_0= ruleDireccionRegla ) )
            // InternalCeffective.g:2296:4: (lv_direccion_24_0= ruleDireccionRegla )
            {
            // InternalCeffective.g:2296:4: (lv_direccion_24_0= ruleDireccionRegla )
            // InternalCeffective.g:2297:5: lv_direccion_24_0= ruleDireccionRegla
            {

            					newCompositeNode(grammarAccess.getReglaAccess().getDireccionDireccionReglaEnumRuleCall_9_0());
            				
            pushFollow(FOLLOW_7);
            lv_direccion_24_0=ruleDireccionRegla();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getReglaRule());
            					}
            					set(
            						current,
            						"direccion",
            						lv_direccion_24_0,
            						"org.xtext.example.ceffective.Ceffective.DireccionRegla");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_SEMICOLON_25=(Token)match(input,RULE_SEMICOLON,FOLLOW_8); 

            			newLeafNode(this_SEMICOLON_25, grammarAccess.getReglaAccess().getSEMICOLONTerminalRuleCall_10());
            		
            this_OBJECT_END_26=(Token)match(input,RULE_OBJECT_END,FOLLOW_2); 

            			newLeafNode(this_OBJECT_END_26, grammarAccess.getReglaAccess().getOBJECT_ENDTerminalRuleCall_11());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRegla"


    // $ANTLR start "entryRuleRecurso"
    // InternalCeffective.g:2326:1: entryRuleRecurso returns [EObject current=null] : iv_ruleRecurso= ruleRecurso EOF ;
    public final EObject entryRuleRecurso() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRecurso = null;


        try {
            // InternalCeffective.g:2326:48: (iv_ruleRecurso= ruleRecurso EOF )
            // InternalCeffective.g:2327:2: iv_ruleRecurso= ruleRecurso EOF
            {
             newCompositeNode(grammarAccess.getRecursoRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRecurso=ruleRecurso();

            state._fsp--;

             current =iv_ruleRecurso; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRecurso"


    // $ANTLR start "ruleRecurso"
    // InternalCeffective.g:2333:1: ruleRecurso returns [EObject current=null] : (this_ServidorAplicaciones_0= ruleServidorAplicaciones | this_Almacenamiento_1= ruleAlmacenamiento | this_ServidorBD_2= ruleServidorBD | this_Servidor_Impl_3= ruleServidor_Impl ) ;
    public final EObject ruleRecurso() throws RecognitionException {
        EObject current = null;

        EObject this_ServidorAplicaciones_0 = null;

        EObject this_Almacenamiento_1 = null;

        EObject this_ServidorBD_2 = null;

        EObject this_Servidor_Impl_3 = null;



        	enterRule();

        try {
            // InternalCeffective.g:2339:2: ( (this_ServidorAplicaciones_0= ruleServidorAplicaciones | this_Almacenamiento_1= ruleAlmacenamiento | this_ServidorBD_2= ruleServidorBD | this_Servidor_Impl_3= ruleServidor_Impl ) )
            // InternalCeffective.g:2340:2: (this_ServidorAplicaciones_0= ruleServidorAplicaciones | this_Almacenamiento_1= ruleAlmacenamiento | this_ServidorBD_2= ruleServidorBD | this_Servidor_Impl_3= ruleServidor_Impl )
            {
            // InternalCeffective.g:2340:2: (this_ServidorAplicaciones_0= ruleServidorAplicaciones | this_Almacenamiento_1= ruleAlmacenamiento | this_ServidorBD_2= ruleServidorBD | this_Servidor_Impl_3= ruleServidor_Impl )
            int alt43=4;
            alt43 = dfa43.predict(input);
            switch (alt43) {
                case 1 :
                    // InternalCeffective.g:2341:3: this_ServidorAplicaciones_0= ruleServidorAplicaciones
                    {

                    			newCompositeNode(grammarAccess.getRecursoAccess().getServidorAplicacionesParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_ServidorAplicaciones_0=ruleServidorAplicaciones();

                    state._fsp--;


                    			current = this_ServidorAplicaciones_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalCeffective.g:2350:3: this_Almacenamiento_1= ruleAlmacenamiento
                    {

                    			newCompositeNode(grammarAccess.getRecursoAccess().getAlmacenamientoParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Almacenamiento_1=ruleAlmacenamiento();

                    state._fsp--;


                    			current = this_Almacenamiento_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalCeffective.g:2359:3: this_ServidorBD_2= ruleServidorBD
                    {

                    			newCompositeNode(grammarAccess.getRecursoAccess().getServidorBDParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_ServidorBD_2=ruleServidorBD();

                    state._fsp--;


                    			current = this_ServidorBD_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalCeffective.g:2368:3: this_Servidor_Impl_3= ruleServidor_Impl
                    {

                    			newCompositeNode(grammarAccess.getRecursoAccess().getServidor_ImplParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_Servidor_Impl_3=ruleServidor_Impl();

                    state._fsp--;


                    			current = this_Servidor_Impl_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRecurso"


    // $ANTLR start "entryRuleServidor_Impl"
    // InternalCeffective.g:2380:1: entryRuleServidor_Impl returns [EObject current=null] : iv_ruleServidor_Impl= ruleServidor_Impl EOF ;
    public final EObject entryRuleServidor_Impl() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleServidor_Impl = null;


        try {
            // InternalCeffective.g:2380:54: (iv_ruleServidor_Impl= ruleServidor_Impl EOF )
            // InternalCeffective.g:2381:2: iv_ruleServidor_Impl= ruleServidor_Impl EOF
            {
             newCompositeNode(grammarAccess.getServidor_ImplRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleServidor_Impl=ruleServidor_Impl();

            state._fsp--;

             current =iv_ruleServidor_Impl; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleServidor_Impl"


    // $ANTLR start "ruleServidor_Impl"
    // InternalCeffective.g:2387:1: ruleServidor_Impl returns [EObject current=null] : (otherlv_0= 'Servidor' this_OBJECT_START_1= RULE_OBJECT_START (otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON )? (otherlv_6= 'zonaDisponibilidad' this_EQUALS_7= RULE_EQUALS ( (lv_zonaDisponibilidad_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'zonaNombre' this_EQUALS_11= RULE_EQUALS ( (lv_zonaNombre_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? (otherlv_14= 'id' this_EQUALS_15= RULE_EQUALS ( (lv_id_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON )? (otherlv_18= 'tamano' this_EQUALS_19= RULE_EQUALS ( (lv_tamano_20_0= ruleTamanoServidor ) ) this_SEMICOLON_21= RULE_SEMICOLON )? (otherlv_22= 'recursos' this_EQUALS_23= RULE_EQUALS otherlv_24= '(' ( ( ruleEString ) ) (this_COMA_26= RULE_COMA ( ( ruleEString ) ) )* otherlv_28= ')' this_SEMICOLON_29= RULE_SEMICOLON )? otherlv_30= 'vpc' this_EQUALS_31= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_33= RULE_SEMICOLON this_OBJECT_END_34= RULE_OBJECT_END ) ;
    public final EObject ruleServidor_Impl() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OBJECT_START_1=null;
        Token otherlv_2=null;
        Token this_EQUALS_3=null;
        Token this_SEMICOLON_5=null;
        Token otherlv_6=null;
        Token this_EQUALS_7=null;
        Token this_SEMICOLON_9=null;
        Token otherlv_10=null;
        Token this_EQUALS_11=null;
        Token this_SEMICOLON_13=null;
        Token otherlv_14=null;
        Token this_EQUALS_15=null;
        Token this_SEMICOLON_17=null;
        Token otherlv_18=null;
        Token this_EQUALS_19=null;
        Token this_SEMICOLON_21=null;
        Token otherlv_22=null;
        Token this_EQUALS_23=null;
        Token otherlv_24=null;
        Token this_COMA_26=null;
        Token otherlv_28=null;
        Token this_SEMICOLON_29=null;
        Token otherlv_30=null;
        Token this_EQUALS_31=null;
        Token this_SEMICOLON_33=null;
        Token this_OBJECT_END_34=null;
        AntlrDatatypeRuleToken lv_nombre_4_0 = null;

        AntlrDatatypeRuleToken lv_zonaDisponibilidad_8_0 = null;

        AntlrDatatypeRuleToken lv_zonaNombre_12_0 = null;

        AntlrDatatypeRuleToken lv_id_16_0 = null;

        Enumerator lv_tamano_20_0 = null;



        	enterRule();

        try {
            // InternalCeffective.g:2393:2: ( (otherlv_0= 'Servidor' this_OBJECT_START_1= RULE_OBJECT_START (otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON )? (otherlv_6= 'zonaDisponibilidad' this_EQUALS_7= RULE_EQUALS ( (lv_zonaDisponibilidad_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'zonaNombre' this_EQUALS_11= RULE_EQUALS ( (lv_zonaNombre_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? (otherlv_14= 'id' this_EQUALS_15= RULE_EQUALS ( (lv_id_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON )? (otherlv_18= 'tamano' this_EQUALS_19= RULE_EQUALS ( (lv_tamano_20_0= ruleTamanoServidor ) ) this_SEMICOLON_21= RULE_SEMICOLON )? (otherlv_22= 'recursos' this_EQUALS_23= RULE_EQUALS otherlv_24= '(' ( ( ruleEString ) ) (this_COMA_26= RULE_COMA ( ( ruleEString ) ) )* otherlv_28= ')' this_SEMICOLON_29= RULE_SEMICOLON )? otherlv_30= 'vpc' this_EQUALS_31= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_33= RULE_SEMICOLON this_OBJECT_END_34= RULE_OBJECT_END ) )
            // InternalCeffective.g:2394:2: (otherlv_0= 'Servidor' this_OBJECT_START_1= RULE_OBJECT_START (otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON )? (otherlv_6= 'zonaDisponibilidad' this_EQUALS_7= RULE_EQUALS ( (lv_zonaDisponibilidad_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'zonaNombre' this_EQUALS_11= RULE_EQUALS ( (lv_zonaNombre_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? (otherlv_14= 'id' this_EQUALS_15= RULE_EQUALS ( (lv_id_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON )? (otherlv_18= 'tamano' this_EQUALS_19= RULE_EQUALS ( (lv_tamano_20_0= ruleTamanoServidor ) ) this_SEMICOLON_21= RULE_SEMICOLON )? (otherlv_22= 'recursos' this_EQUALS_23= RULE_EQUALS otherlv_24= '(' ( ( ruleEString ) ) (this_COMA_26= RULE_COMA ( ( ruleEString ) ) )* otherlv_28= ')' this_SEMICOLON_29= RULE_SEMICOLON )? otherlv_30= 'vpc' this_EQUALS_31= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_33= RULE_SEMICOLON this_OBJECT_END_34= RULE_OBJECT_END )
            {
            // InternalCeffective.g:2394:2: (otherlv_0= 'Servidor' this_OBJECT_START_1= RULE_OBJECT_START (otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON )? (otherlv_6= 'zonaDisponibilidad' this_EQUALS_7= RULE_EQUALS ( (lv_zonaDisponibilidad_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'zonaNombre' this_EQUALS_11= RULE_EQUALS ( (lv_zonaNombre_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? (otherlv_14= 'id' this_EQUALS_15= RULE_EQUALS ( (lv_id_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON )? (otherlv_18= 'tamano' this_EQUALS_19= RULE_EQUALS ( (lv_tamano_20_0= ruleTamanoServidor ) ) this_SEMICOLON_21= RULE_SEMICOLON )? (otherlv_22= 'recursos' this_EQUALS_23= RULE_EQUALS otherlv_24= '(' ( ( ruleEString ) ) (this_COMA_26= RULE_COMA ( ( ruleEString ) ) )* otherlv_28= ')' this_SEMICOLON_29= RULE_SEMICOLON )? otherlv_30= 'vpc' this_EQUALS_31= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_33= RULE_SEMICOLON this_OBJECT_END_34= RULE_OBJECT_END )
            // InternalCeffective.g:2395:3: otherlv_0= 'Servidor' this_OBJECT_START_1= RULE_OBJECT_START (otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON )? (otherlv_6= 'zonaDisponibilidad' this_EQUALS_7= RULE_EQUALS ( (lv_zonaDisponibilidad_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )? (otherlv_10= 'zonaNombre' this_EQUALS_11= RULE_EQUALS ( (lv_zonaNombre_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )? (otherlv_14= 'id' this_EQUALS_15= RULE_EQUALS ( (lv_id_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON )? (otherlv_18= 'tamano' this_EQUALS_19= RULE_EQUALS ( (lv_tamano_20_0= ruleTamanoServidor ) ) this_SEMICOLON_21= RULE_SEMICOLON )? (otherlv_22= 'recursos' this_EQUALS_23= RULE_EQUALS otherlv_24= '(' ( ( ruleEString ) ) (this_COMA_26= RULE_COMA ( ( ruleEString ) ) )* otherlv_28= ')' this_SEMICOLON_29= RULE_SEMICOLON )? otherlv_30= 'vpc' this_EQUALS_31= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_33= RULE_SEMICOLON this_OBJECT_END_34= RULE_OBJECT_END
            {
            otherlv_0=(Token)match(input,50,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getServidor_ImplAccess().getServidorKeyword_0());
            		
            this_OBJECT_START_1=(Token)match(input,RULE_OBJECT_START,FOLLOW_54); 

            			newLeafNode(this_OBJECT_START_1, grammarAccess.getServidor_ImplAccess().getOBJECT_STARTTerminalRuleCall_1());
            		
            // InternalCeffective.g:2403:3: (otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON )?
            int alt44=2;
            int LA44_0 = input.LA(1);

            if ( (LA44_0==30) ) {
                alt44=1;
            }
            switch (alt44) {
                case 1 :
                    // InternalCeffective.g:2404:4: otherlv_2= 'nombre' this_EQUALS_3= RULE_EQUALS ( (lv_nombre_4_0= ruleEString ) ) this_SEMICOLON_5= RULE_SEMICOLON
                    {
                    otherlv_2=(Token)match(input,30,FOLLOW_6); 

                    				newLeafNode(otherlv_2, grammarAccess.getServidor_ImplAccess().getNombreKeyword_2_0());
                    			
                    this_EQUALS_3=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_3, grammarAccess.getServidor_ImplAccess().getEQUALSTerminalRuleCall_2_1());
                    			
                    // InternalCeffective.g:2412:4: ( (lv_nombre_4_0= ruleEString ) )
                    // InternalCeffective.g:2413:5: (lv_nombre_4_0= ruleEString )
                    {
                    // InternalCeffective.g:2413:5: (lv_nombre_4_0= ruleEString )
                    // InternalCeffective.g:2414:6: lv_nombre_4_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getServidor_ImplAccess().getNombreEStringParserRuleCall_2_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_nombre_4_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getServidor_ImplRule());
                    						}
                    						set(
                    							current,
                    							"nombre",
                    							lv_nombre_4_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_5=(Token)match(input,RULE_SEMICOLON,FOLLOW_55); 

                    				newLeafNode(this_SEMICOLON_5, grammarAccess.getServidor_ImplAccess().getSEMICOLONTerminalRuleCall_2_3());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:2436:3: (otherlv_6= 'zonaDisponibilidad' this_EQUALS_7= RULE_EQUALS ( (lv_zonaDisponibilidad_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON )?
            int alt45=2;
            int LA45_0 = input.LA(1);

            if ( (LA45_0==41) ) {
                alt45=1;
            }
            switch (alt45) {
                case 1 :
                    // InternalCeffective.g:2437:4: otherlv_6= 'zonaDisponibilidad' this_EQUALS_7= RULE_EQUALS ( (lv_zonaDisponibilidad_8_0= ruleEString ) ) this_SEMICOLON_9= RULE_SEMICOLON
                    {
                    otherlv_6=(Token)match(input,41,FOLLOW_6); 

                    				newLeafNode(otherlv_6, grammarAccess.getServidor_ImplAccess().getZonaDisponibilidadKeyword_3_0());
                    			
                    this_EQUALS_7=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_7, grammarAccess.getServidor_ImplAccess().getEQUALSTerminalRuleCall_3_1());
                    			
                    // InternalCeffective.g:2445:4: ( (lv_zonaDisponibilidad_8_0= ruleEString ) )
                    // InternalCeffective.g:2446:5: (lv_zonaDisponibilidad_8_0= ruleEString )
                    {
                    // InternalCeffective.g:2446:5: (lv_zonaDisponibilidad_8_0= ruleEString )
                    // InternalCeffective.g:2447:6: lv_zonaDisponibilidad_8_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getServidor_ImplAccess().getZonaDisponibilidadEStringParserRuleCall_3_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_zonaDisponibilidad_8_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getServidor_ImplRule());
                    						}
                    						set(
                    							current,
                    							"zonaDisponibilidad",
                    							lv_zonaDisponibilidad_8_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_56); 

                    				newLeafNode(this_SEMICOLON_9, grammarAccess.getServidor_ImplAccess().getSEMICOLONTerminalRuleCall_3_3());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:2469:3: (otherlv_10= 'zonaNombre' this_EQUALS_11= RULE_EQUALS ( (lv_zonaNombre_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON )?
            int alt46=2;
            int LA46_0 = input.LA(1);

            if ( (LA46_0==40) ) {
                alt46=1;
            }
            switch (alt46) {
                case 1 :
                    // InternalCeffective.g:2470:4: otherlv_10= 'zonaNombre' this_EQUALS_11= RULE_EQUALS ( (lv_zonaNombre_12_0= ruleEString ) ) this_SEMICOLON_13= RULE_SEMICOLON
                    {
                    otherlv_10=(Token)match(input,40,FOLLOW_6); 

                    				newLeafNode(otherlv_10, grammarAccess.getServidor_ImplAccess().getZonaNombreKeyword_4_0());
                    			
                    this_EQUALS_11=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_11, grammarAccess.getServidor_ImplAccess().getEQUALSTerminalRuleCall_4_1());
                    			
                    // InternalCeffective.g:2478:4: ( (lv_zonaNombre_12_0= ruleEString ) )
                    // InternalCeffective.g:2479:5: (lv_zonaNombre_12_0= ruleEString )
                    {
                    // InternalCeffective.g:2479:5: (lv_zonaNombre_12_0= ruleEString )
                    // InternalCeffective.g:2480:6: lv_zonaNombre_12_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getServidor_ImplAccess().getZonaNombreEStringParserRuleCall_4_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_zonaNombre_12_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getServidor_ImplRule());
                    						}
                    						set(
                    							current,
                    							"zonaNombre",
                    							lv_zonaNombre_12_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_13=(Token)match(input,RULE_SEMICOLON,FOLLOW_57); 

                    				newLeafNode(this_SEMICOLON_13, grammarAccess.getServidor_ImplAccess().getSEMICOLONTerminalRuleCall_4_3());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:2502:3: (otherlv_14= 'id' this_EQUALS_15= RULE_EQUALS ( (lv_id_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON )?
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==37) ) {
                alt47=1;
            }
            switch (alt47) {
                case 1 :
                    // InternalCeffective.g:2503:4: otherlv_14= 'id' this_EQUALS_15= RULE_EQUALS ( (lv_id_16_0= ruleEString ) ) this_SEMICOLON_17= RULE_SEMICOLON
                    {
                    otherlv_14=(Token)match(input,37,FOLLOW_6); 

                    				newLeafNode(otherlv_14, grammarAccess.getServidor_ImplAccess().getIdKeyword_5_0());
                    			
                    this_EQUALS_15=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_15, grammarAccess.getServidor_ImplAccess().getEQUALSTerminalRuleCall_5_1());
                    			
                    // InternalCeffective.g:2511:4: ( (lv_id_16_0= ruleEString ) )
                    // InternalCeffective.g:2512:5: (lv_id_16_0= ruleEString )
                    {
                    // InternalCeffective.g:2512:5: (lv_id_16_0= ruleEString )
                    // InternalCeffective.g:2513:6: lv_id_16_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getServidor_ImplAccess().getIdEStringParserRuleCall_5_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_id_16_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getServidor_ImplRule());
                    						}
                    						set(
                    							current,
                    							"id",
                    							lv_id_16_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_17=(Token)match(input,RULE_SEMICOLON,FOLLOW_58); 

                    				newLeafNode(this_SEMICOLON_17, grammarAccess.getServidor_ImplAccess().getSEMICOLONTerminalRuleCall_5_3());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:2535:3: (otherlv_18= 'tamano' this_EQUALS_19= RULE_EQUALS ( (lv_tamano_20_0= ruleTamanoServidor ) ) this_SEMICOLON_21= RULE_SEMICOLON )?
            int alt48=2;
            int LA48_0 = input.LA(1);

            if ( (LA48_0==51) ) {
                alt48=1;
            }
            switch (alt48) {
                case 1 :
                    // InternalCeffective.g:2536:4: otherlv_18= 'tamano' this_EQUALS_19= RULE_EQUALS ( (lv_tamano_20_0= ruleTamanoServidor ) ) this_SEMICOLON_21= RULE_SEMICOLON
                    {
                    otherlv_18=(Token)match(input,51,FOLLOW_6); 

                    				newLeafNode(otherlv_18, grammarAccess.getServidor_ImplAccess().getTamanoKeyword_6_0());
                    			
                    this_EQUALS_19=(Token)match(input,RULE_EQUALS,FOLLOW_59); 

                    				newLeafNode(this_EQUALS_19, grammarAccess.getServidor_ImplAccess().getEQUALSTerminalRuleCall_6_1());
                    			
                    // InternalCeffective.g:2544:4: ( (lv_tamano_20_0= ruleTamanoServidor ) )
                    // InternalCeffective.g:2545:5: (lv_tamano_20_0= ruleTamanoServidor )
                    {
                    // InternalCeffective.g:2545:5: (lv_tamano_20_0= ruleTamanoServidor )
                    // InternalCeffective.g:2546:6: lv_tamano_20_0= ruleTamanoServidor
                    {

                    						newCompositeNode(grammarAccess.getServidor_ImplAccess().getTamanoTamanoServidorEnumRuleCall_6_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_tamano_20_0=ruleTamanoServidor();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getServidor_ImplRule());
                    						}
                    						set(
                    							current,
                    							"tamano",
                    							lv_tamano_20_0,
                    							"org.xtext.example.ceffective.Ceffective.TamanoServidor");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_21=(Token)match(input,RULE_SEMICOLON,FOLLOW_60); 

                    				newLeafNode(this_SEMICOLON_21, grammarAccess.getServidor_ImplAccess().getSEMICOLONTerminalRuleCall_6_3());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:2568:3: (otherlv_22= 'recursos' this_EQUALS_23= RULE_EQUALS otherlv_24= '(' ( ( ruleEString ) ) (this_COMA_26= RULE_COMA ( ( ruleEString ) ) )* otherlv_28= ')' this_SEMICOLON_29= RULE_SEMICOLON )?
            int alt50=2;
            int LA50_0 = input.LA(1);

            if ( (LA50_0==33) ) {
                alt50=1;
            }
            switch (alt50) {
                case 1 :
                    // InternalCeffective.g:2569:4: otherlv_22= 'recursos' this_EQUALS_23= RULE_EQUALS otherlv_24= '(' ( ( ruleEString ) ) (this_COMA_26= RULE_COMA ( ( ruleEString ) ) )* otherlv_28= ')' this_SEMICOLON_29= RULE_SEMICOLON
                    {
                    otherlv_22=(Token)match(input,33,FOLLOW_6); 

                    				newLeafNode(otherlv_22, grammarAccess.getServidor_ImplAccess().getRecursosKeyword_7_0());
                    			
                    this_EQUALS_23=(Token)match(input,RULE_EQUALS,FOLLOW_61); 

                    				newLeafNode(this_EQUALS_23, grammarAccess.getServidor_ImplAccess().getEQUALSTerminalRuleCall_7_1());
                    			
                    otherlv_24=(Token)match(input,52,FOLLOW_10); 

                    				newLeafNode(otherlv_24, grammarAccess.getServidor_ImplAccess().getLeftParenthesisKeyword_7_2());
                    			
                    // InternalCeffective.g:2581:4: ( ( ruleEString ) )
                    // InternalCeffective.g:2582:5: ( ruleEString )
                    {
                    // InternalCeffective.g:2582:5: ( ruleEString )
                    // InternalCeffective.g:2583:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getServidor_ImplRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getServidor_ImplAccess().getRecursosRecursoCrossReference_7_3_0());
                    					
                    pushFollow(FOLLOW_62);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalCeffective.g:2597:4: (this_COMA_26= RULE_COMA ( ( ruleEString ) ) )*
                    loop49:
                    do {
                        int alt49=2;
                        int LA49_0 = input.LA(1);

                        if ( (LA49_0==RULE_COMA) ) {
                            alt49=1;
                        }


                        switch (alt49) {
                    	case 1 :
                    	    // InternalCeffective.g:2598:5: this_COMA_26= RULE_COMA ( ( ruleEString ) )
                    	    {
                    	    this_COMA_26=(Token)match(input,RULE_COMA,FOLLOW_10); 

                    	    					newLeafNode(this_COMA_26, grammarAccess.getServidor_ImplAccess().getCOMATerminalRuleCall_7_4_0());
                    	    				
                    	    // InternalCeffective.g:2602:5: ( ( ruleEString ) )
                    	    // InternalCeffective.g:2603:6: ( ruleEString )
                    	    {
                    	    // InternalCeffective.g:2603:6: ( ruleEString )
                    	    // InternalCeffective.g:2604:7: ruleEString
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getServidor_ImplRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getServidor_ImplAccess().getRecursosRecursoCrossReference_7_4_1_0());
                    	    						
                    	    pushFollow(FOLLOW_62);
                    	    ruleEString();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop49;
                        }
                    } while (true);

                    otherlv_28=(Token)match(input,53,FOLLOW_7); 

                    				newLeafNode(otherlv_28, grammarAccess.getServidor_ImplAccess().getRightParenthesisKeyword_7_5());
                    			
                    this_SEMICOLON_29=(Token)match(input,RULE_SEMICOLON,FOLLOW_63); 

                    				newLeafNode(this_SEMICOLON_29, grammarAccess.getServidor_ImplAccess().getSEMICOLONTerminalRuleCall_7_6());
                    			

                    }
                    break;

            }

            otherlv_30=(Token)match(input,42,FOLLOW_6); 

            			newLeafNode(otherlv_30, grammarAccess.getServidor_ImplAccess().getVpcKeyword_8());
            		
            this_EQUALS_31=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

            			newLeafNode(this_EQUALS_31, grammarAccess.getServidor_ImplAccess().getEQUALSTerminalRuleCall_9());
            		
            // InternalCeffective.g:2636:3: ( ( ruleEString ) )
            // InternalCeffective.g:2637:4: ( ruleEString )
            {
            // InternalCeffective.g:2637:4: ( ruleEString )
            // InternalCeffective.g:2638:5: ruleEString
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getServidor_ImplRule());
            					}
            				

            					newCompositeNode(grammarAccess.getServidor_ImplAccess().getVpcVPCCrossReference_10_0());
            				
            pushFollow(FOLLOW_7);
            ruleEString();

            state._fsp--;


            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_SEMICOLON_33=(Token)match(input,RULE_SEMICOLON,FOLLOW_8); 

            			newLeafNode(this_SEMICOLON_33, grammarAccess.getServidor_ImplAccess().getSEMICOLONTerminalRuleCall_11());
            		
            this_OBJECT_END_34=(Token)match(input,RULE_OBJECT_END,FOLLOW_2); 

            			newLeafNode(this_OBJECT_END_34, grammarAccess.getServidor_ImplAccess().getOBJECT_ENDTerminalRuleCall_12());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleServidor_Impl"


    // $ANTLR start "entryRuleServidorAplicaciones"
    // InternalCeffective.g:2664:1: entryRuleServidorAplicaciones returns [EObject current=null] : iv_ruleServidorAplicaciones= ruleServidorAplicaciones EOF ;
    public final EObject entryRuleServidorAplicaciones() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleServidorAplicaciones = null;


        try {
            // InternalCeffective.g:2664:61: (iv_ruleServidorAplicaciones= ruleServidorAplicaciones EOF )
            // InternalCeffective.g:2665:2: iv_ruleServidorAplicaciones= ruleServidorAplicaciones EOF
            {
             newCompositeNode(grammarAccess.getServidorAplicacionesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleServidorAplicaciones=ruleServidorAplicaciones();

            state._fsp--;

             current =iv_ruleServidorAplicaciones; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleServidorAplicaciones"


    // $ANTLR start "ruleServidorAplicaciones"
    // InternalCeffective.g:2671:1: ruleServidorAplicaciones returns [EObject current=null] : (this_OBJECT_START_0= RULE_OBJECT_START otherlv_1= 'nombre' this_EQUALS_2= RULE_EQUALS ( (lv_nombre_3_0= ruleEString ) ) this_SEMICOLON_4= RULE_SEMICOLON (otherlv_5= 'zonaDisponibilidad' this_EQUALS_6= RULE_EQUALS ( (lv_zonaDisponibilidad_7_0= ruleEString ) ) this_SEMICOLON_8= RULE_SEMICOLON )? (otherlv_9= 'zonaNombre' this_EQUALS_10= RULE_EQUALS ( (lv_zonaNombre_11_0= ruleEString ) ) this_SEMICOLON_12= RULE_SEMICOLON )? otherlv_13= 'id' this_EQUALS_14= RULE_EQUALS ( (lv_id_15_0= ruleEString ) ) this_SEMICOLON_16= RULE_SEMICOLON otherlv_17= 'dimension' this_EQUALS_18= RULE_EQUALS ( (lv_tamano_19_0= ruleTamanoServidor ) ) this_SEMICOLON_20= RULE_SEMICOLON (otherlv_21= 'sistemaOperativo' this_EQUALS_22= RULE_EQUALS ( (lv_sistemaOperativo_23_0= ruleEString ) ) this_SEMICOLON_24= RULE_SEMICOLON )? (otherlv_25= 'recursos' this_EQUALS_26= RULE_EQUALS otherlv_27= '(' ( ( ruleEString ) ) (this_COMA_29= RULE_COMA ( ( ruleEString ) ) )* otherlv_31= ')' this_SEMICOLON_32= RULE_SEMICOLON )? (otherlv_33= 'vpc' this_EQUALS_34= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_36= RULE_SEMICOLON )? this_OBJECT_END_37= RULE_OBJECT_END ) ;
    public final EObject ruleServidorAplicaciones() throws RecognitionException {
        EObject current = null;

        Token this_OBJECT_START_0=null;
        Token otherlv_1=null;
        Token this_EQUALS_2=null;
        Token this_SEMICOLON_4=null;
        Token otherlv_5=null;
        Token this_EQUALS_6=null;
        Token this_SEMICOLON_8=null;
        Token otherlv_9=null;
        Token this_EQUALS_10=null;
        Token this_SEMICOLON_12=null;
        Token otherlv_13=null;
        Token this_EQUALS_14=null;
        Token this_SEMICOLON_16=null;
        Token otherlv_17=null;
        Token this_EQUALS_18=null;
        Token this_SEMICOLON_20=null;
        Token otherlv_21=null;
        Token this_EQUALS_22=null;
        Token this_SEMICOLON_24=null;
        Token otherlv_25=null;
        Token this_EQUALS_26=null;
        Token otherlv_27=null;
        Token this_COMA_29=null;
        Token otherlv_31=null;
        Token this_SEMICOLON_32=null;
        Token otherlv_33=null;
        Token this_EQUALS_34=null;
        Token this_SEMICOLON_36=null;
        Token this_OBJECT_END_37=null;
        AntlrDatatypeRuleToken lv_nombre_3_0 = null;

        AntlrDatatypeRuleToken lv_zonaDisponibilidad_7_0 = null;

        AntlrDatatypeRuleToken lv_zonaNombre_11_0 = null;

        AntlrDatatypeRuleToken lv_id_15_0 = null;

        Enumerator lv_tamano_19_0 = null;

        AntlrDatatypeRuleToken lv_sistemaOperativo_23_0 = null;



        	enterRule();

        try {
            // InternalCeffective.g:2677:2: ( (this_OBJECT_START_0= RULE_OBJECT_START otherlv_1= 'nombre' this_EQUALS_2= RULE_EQUALS ( (lv_nombre_3_0= ruleEString ) ) this_SEMICOLON_4= RULE_SEMICOLON (otherlv_5= 'zonaDisponibilidad' this_EQUALS_6= RULE_EQUALS ( (lv_zonaDisponibilidad_7_0= ruleEString ) ) this_SEMICOLON_8= RULE_SEMICOLON )? (otherlv_9= 'zonaNombre' this_EQUALS_10= RULE_EQUALS ( (lv_zonaNombre_11_0= ruleEString ) ) this_SEMICOLON_12= RULE_SEMICOLON )? otherlv_13= 'id' this_EQUALS_14= RULE_EQUALS ( (lv_id_15_0= ruleEString ) ) this_SEMICOLON_16= RULE_SEMICOLON otherlv_17= 'dimension' this_EQUALS_18= RULE_EQUALS ( (lv_tamano_19_0= ruleTamanoServidor ) ) this_SEMICOLON_20= RULE_SEMICOLON (otherlv_21= 'sistemaOperativo' this_EQUALS_22= RULE_EQUALS ( (lv_sistemaOperativo_23_0= ruleEString ) ) this_SEMICOLON_24= RULE_SEMICOLON )? (otherlv_25= 'recursos' this_EQUALS_26= RULE_EQUALS otherlv_27= '(' ( ( ruleEString ) ) (this_COMA_29= RULE_COMA ( ( ruleEString ) ) )* otherlv_31= ')' this_SEMICOLON_32= RULE_SEMICOLON )? (otherlv_33= 'vpc' this_EQUALS_34= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_36= RULE_SEMICOLON )? this_OBJECT_END_37= RULE_OBJECT_END ) )
            // InternalCeffective.g:2678:2: (this_OBJECT_START_0= RULE_OBJECT_START otherlv_1= 'nombre' this_EQUALS_2= RULE_EQUALS ( (lv_nombre_3_0= ruleEString ) ) this_SEMICOLON_4= RULE_SEMICOLON (otherlv_5= 'zonaDisponibilidad' this_EQUALS_6= RULE_EQUALS ( (lv_zonaDisponibilidad_7_0= ruleEString ) ) this_SEMICOLON_8= RULE_SEMICOLON )? (otherlv_9= 'zonaNombre' this_EQUALS_10= RULE_EQUALS ( (lv_zonaNombre_11_0= ruleEString ) ) this_SEMICOLON_12= RULE_SEMICOLON )? otherlv_13= 'id' this_EQUALS_14= RULE_EQUALS ( (lv_id_15_0= ruleEString ) ) this_SEMICOLON_16= RULE_SEMICOLON otherlv_17= 'dimension' this_EQUALS_18= RULE_EQUALS ( (lv_tamano_19_0= ruleTamanoServidor ) ) this_SEMICOLON_20= RULE_SEMICOLON (otherlv_21= 'sistemaOperativo' this_EQUALS_22= RULE_EQUALS ( (lv_sistemaOperativo_23_0= ruleEString ) ) this_SEMICOLON_24= RULE_SEMICOLON )? (otherlv_25= 'recursos' this_EQUALS_26= RULE_EQUALS otherlv_27= '(' ( ( ruleEString ) ) (this_COMA_29= RULE_COMA ( ( ruleEString ) ) )* otherlv_31= ')' this_SEMICOLON_32= RULE_SEMICOLON )? (otherlv_33= 'vpc' this_EQUALS_34= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_36= RULE_SEMICOLON )? this_OBJECT_END_37= RULE_OBJECT_END )
            {
            // InternalCeffective.g:2678:2: (this_OBJECT_START_0= RULE_OBJECT_START otherlv_1= 'nombre' this_EQUALS_2= RULE_EQUALS ( (lv_nombre_3_0= ruleEString ) ) this_SEMICOLON_4= RULE_SEMICOLON (otherlv_5= 'zonaDisponibilidad' this_EQUALS_6= RULE_EQUALS ( (lv_zonaDisponibilidad_7_0= ruleEString ) ) this_SEMICOLON_8= RULE_SEMICOLON )? (otherlv_9= 'zonaNombre' this_EQUALS_10= RULE_EQUALS ( (lv_zonaNombre_11_0= ruleEString ) ) this_SEMICOLON_12= RULE_SEMICOLON )? otherlv_13= 'id' this_EQUALS_14= RULE_EQUALS ( (lv_id_15_0= ruleEString ) ) this_SEMICOLON_16= RULE_SEMICOLON otherlv_17= 'dimension' this_EQUALS_18= RULE_EQUALS ( (lv_tamano_19_0= ruleTamanoServidor ) ) this_SEMICOLON_20= RULE_SEMICOLON (otherlv_21= 'sistemaOperativo' this_EQUALS_22= RULE_EQUALS ( (lv_sistemaOperativo_23_0= ruleEString ) ) this_SEMICOLON_24= RULE_SEMICOLON )? (otherlv_25= 'recursos' this_EQUALS_26= RULE_EQUALS otherlv_27= '(' ( ( ruleEString ) ) (this_COMA_29= RULE_COMA ( ( ruleEString ) ) )* otherlv_31= ')' this_SEMICOLON_32= RULE_SEMICOLON )? (otherlv_33= 'vpc' this_EQUALS_34= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_36= RULE_SEMICOLON )? this_OBJECT_END_37= RULE_OBJECT_END )
            // InternalCeffective.g:2679:3: this_OBJECT_START_0= RULE_OBJECT_START otherlv_1= 'nombre' this_EQUALS_2= RULE_EQUALS ( (lv_nombre_3_0= ruleEString ) ) this_SEMICOLON_4= RULE_SEMICOLON (otherlv_5= 'zonaDisponibilidad' this_EQUALS_6= RULE_EQUALS ( (lv_zonaDisponibilidad_7_0= ruleEString ) ) this_SEMICOLON_8= RULE_SEMICOLON )? (otherlv_9= 'zonaNombre' this_EQUALS_10= RULE_EQUALS ( (lv_zonaNombre_11_0= ruleEString ) ) this_SEMICOLON_12= RULE_SEMICOLON )? otherlv_13= 'id' this_EQUALS_14= RULE_EQUALS ( (lv_id_15_0= ruleEString ) ) this_SEMICOLON_16= RULE_SEMICOLON otherlv_17= 'dimension' this_EQUALS_18= RULE_EQUALS ( (lv_tamano_19_0= ruleTamanoServidor ) ) this_SEMICOLON_20= RULE_SEMICOLON (otherlv_21= 'sistemaOperativo' this_EQUALS_22= RULE_EQUALS ( (lv_sistemaOperativo_23_0= ruleEString ) ) this_SEMICOLON_24= RULE_SEMICOLON )? (otherlv_25= 'recursos' this_EQUALS_26= RULE_EQUALS otherlv_27= '(' ( ( ruleEString ) ) (this_COMA_29= RULE_COMA ( ( ruleEString ) ) )* otherlv_31= ')' this_SEMICOLON_32= RULE_SEMICOLON )? (otherlv_33= 'vpc' this_EQUALS_34= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_36= RULE_SEMICOLON )? this_OBJECT_END_37= RULE_OBJECT_END
            {
            this_OBJECT_START_0=(Token)match(input,RULE_OBJECT_START,FOLLOW_39); 

            			newLeafNode(this_OBJECT_START_0, grammarAccess.getServidorAplicacionesAccess().getOBJECT_STARTTerminalRuleCall_0());
            		
            otherlv_1=(Token)match(input,30,FOLLOW_6); 

            			newLeafNode(otherlv_1, grammarAccess.getServidorAplicacionesAccess().getNombreKeyword_1());
            		
            this_EQUALS_2=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

            			newLeafNode(this_EQUALS_2, grammarAccess.getServidorAplicacionesAccess().getEQUALSTerminalRuleCall_2());
            		
            // InternalCeffective.g:2691:3: ( (lv_nombre_3_0= ruleEString ) )
            // InternalCeffective.g:2692:4: (lv_nombre_3_0= ruleEString )
            {
            // InternalCeffective.g:2692:4: (lv_nombre_3_0= ruleEString )
            // InternalCeffective.g:2693:5: lv_nombre_3_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getServidorAplicacionesAccess().getNombreEStringParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_7);
            lv_nombre_3_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getServidorAplicacionesRule());
            					}
            					set(
            						current,
            						"nombre",
            						lv_nombre_3_0,
            						"org.xtext.example.ceffective.Ceffective.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_SEMICOLON_4=(Token)match(input,RULE_SEMICOLON,FOLLOW_40); 

            			newLeafNode(this_SEMICOLON_4, grammarAccess.getServidorAplicacionesAccess().getSEMICOLONTerminalRuleCall_4());
            		
            // InternalCeffective.g:2714:3: (otherlv_5= 'zonaDisponibilidad' this_EQUALS_6= RULE_EQUALS ( (lv_zonaDisponibilidad_7_0= ruleEString ) ) this_SEMICOLON_8= RULE_SEMICOLON )?
            int alt51=2;
            int LA51_0 = input.LA(1);

            if ( (LA51_0==41) ) {
                alt51=1;
            }
            switch (alt51) {
                case 1 :
                    // InternalCeffective.g:2715:4: otherlv_5= 'zonaDisponibilidad' this_EQUALS_6= RULE_EQUALS ( (lv_zonaDisponibilidad_7_0= ruleEString ) ) this_SEMICOLON_8= RULE_SEMICOLON
                    {
                    otherlv_5=(Token)match(input,41,FOLLOW_6); 

                    				newLeafNode(otherlv_5, grammarAccess.getServidorAplicacionesAccess().getZonaDisponibilidadKeyword_5_0());
                    			
                    this_EQUALS_6=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_6, grammarAccess.getServidorAplicacionesAccess().getEQUALSTerminalRuleCall_5_1());
                    			
                    // InternalCeffective.g:2723:4: ( (lv_zonaDisponibilidad_7_0= ruleEString ) )
                    // InternalCeffective.g:2724:5: (lv_zonaDisponibilidad_7_0= ruleEString )
                    {
                    // InternalCeffective.g:2724:5: (lv_zonaDisponibilidad_7_0= ruleEString )
                    // InternalCeffective.g:2725:6: lv_zonaDisponibilidad_7_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getServidorAplicacionesAccess().getZonaDisponibilidadEStringParserRuleCall_5_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_zonaDisponibilidad_7_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getServidorAplicacionesRule());
                    						}
                    						set(
                    							current,
                    							"zonaDisponibilidad",
                    							lv_zonaDisponibilidad_7_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_64); 

                    				newLeafNode(this_SEMICOLON_8, grammarAccess.getServidorAplicacionesAccess().getSEMICOLONTerminalRuleCall_5_3());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:2747:3: (otherlv_9= 'zonaNombre' this_EQUALS_10= RULE_EQUALS ( (lv_zonaNombre_11_0= ruleEString ) ) this_SEMICOLON_12= RULE_SEMICOLON )?
            int alt52=2;
            int LA52_0 = input.LA(1);

            if ( (LA52_0==40) ) {
                alt52=1;
            }
            switch (alt52) {
                case 1 :
                    // InternalCeffective.g:2748:4: otherlv_9= 'zonaNombre' this_EQUALS_10= RULE_EQUALS ( (lv_zonaNombre_11_0= ruleEString ) ) this_SEMICOLON_12= RULE_SEMICOLON
                    {
                    otherlv_9=(Token)match(input,40,FOLLOW_6); 

                    				newLeafNode(otherlv_9, grammarAccess.getServidorAplicacionesAccess().getZonaNombreKeyword_6_0());
                    			
                    this_EQUALS_10=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_10, grammarAccess.getServidorAplicacionesAccess().getEQUALSTerminalRuleCall_6_1());
                    			
                    // InternalCeffective.g:2756:4: ( (lv_zonaNombre_11_0= ruleEString ) )
                    // InternalCeffective.g:2757:5: (lv_zonaNombre_11_0= ruleEString )
                    {
                    // InternalCeffective.g:2757:5: (lv_zonaNombre_11_0= ruleEString )
                    // InternalCeffective.g:2758:6: lv_zonaNombre_11_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getServidorAplicacionesAccess().getZonaNombreEStringParserRuleCall_6_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_zonaNombre_11_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getServidorAplicacionesRule());
                    						}
                    						set(
                    							current,
                    							"zonaNombre",
                    							lv_zonaNombre_11_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_12=(Token)match(input,RULE_SEMICOLON,FOLLOW_36); 

                    				newLeafNode(this_SEMICOLON_12, grammarAccess.getServidorAplicacionesAccess().getSEMICOLONTerminalRuleCall_6_3());
                    			

                    }
                    break;

            }

            otherlv_13=(Token)match(input,37,FOLLOW_6); 

            			newLeafNode(otherlv_13, grammarAccess.getServidorAplicacionesAccess().getIdKeyword_7());
            		
            this_EQUALS_14=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

            			newLeafNode(this_EQUALS_14, grammarAccess.getServidorAplicacionesAccess().getEQUALSTerminalRuleCall_8());
            		
            // InternalCeffective.g:2788:3: ( (lv_id_15_0= ruleEString ) )
            // InternalCeffective.g:2789:4: (lv_id_15_0= ruleEString )
            {
            // InternalCeffective.g:2789:4: (lv_id_15_0= ruleEString )
            // InternalCeffective.g:2790:5: lv_id_15_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getServidorAplicacionesAccess().getIdEStringParserRuleCall_9_0());
            				
            pushFollow(FOLLOW_7);
            lv_id_15_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getServidorAplicacionesRule());
            					}
            					set(
            						current,
            						"id",
            						lv_id_15_0,
            						"org.xtext.example.ceffective.Ceffective.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_SEMICOLON_16=(Token)match(input,RULE_SEMICOLON,FOLLOW_65); 

            			newLeafNode(this_SEMICOLON_16, grammarAccess.getServidorAplicacionesAccess().getSEMICOLONTerminalRuleCall_10());
            		
            otherlv_17=(Token)match(input,54,FOLLOW_6); 

            			newLeafNode(otherlv_17, grammarAccess.getServidorAplicacionesAccess().getDimensionKeyword_11());
            		
            this_EQUALS_18=(Token)match(input,RULE_EQUALS,FOLLOW_59); 

            			newLeafNode(this_EQUALS_18, grammarAccess.getServidorAplicacionesAccess().getEQUALSTerminalRuleCall_12());
            		
            // InternalCeffective.g:2819:3: ( (lv_tamano_19_0= ruleTamanoServidor ) )
            // InternalCeffective.g:2820:4: (lv_tamano_19_0= ruleTamanoServidor )
            {
            // InternalCeffective.g:2820:4: (lv_tamano_19_0= ruleTamanoServidor )
            // InternalCeffective.g:2821:5: lv_tamano_19_0= ruleTamanoServidor
            {

            					newCompositeNode(grammarAccess.getServidorAplicacionesAccess().getTamanoTamanoServidorEnumRuleCall_13_0());
            				
            pushFollow(FOLLOW_7);
            lv_tamano_19_0=ruleTamanoServidor();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getServidorAplicacionesRule());
            					}
            					set(
            						current,
            						"tamano",
            						lv_tamano_19_0,
            						"org.xtext.example.ceffective.Ceffective.TamanoServidor");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_SEMICOLON_20=(Token)match(input,RULE_SEMICOLON,FOLLOW_66); 

            			newLeafNode(this_SEMICOLON_20, grammarAccess.getServidorAplicacionesAccess().getSEMICOLONTerminalRuleCall_14());
            		
            // InternalCeffective.g:2842:3: (otherlv_21= 'sistemaOperativo' this_EQUALS_22= RULE_EQUALS ( (lv_sistemaOperativo_23_0= ruleEString ) ) this_SEMICOLON_24= RULE_SEMICOLON )?
            int alt53=2;
            int LA53_0 = input.LA(1);

            if ( (LA53_0==55) ) {
                alt53=1;
            }
            switch (alt53) {
                case 1 :
                    // InternalCeffective.g:2843:4: otherlv_21= 'sistemaOperativo' this_EQUALS_22= RULE_EQUALS ( (lv_sistemaOperativo_23_0= ruleEString ) ) this_SEMICOLON_24= RULE_SEMICOLON
                    {
                    otherlv_21=(Token)match(input,55,FOLLOW_6); 

                    				newLeafNode(otherlv_21, grammarAccess.getServidorAplicacionesAccess().getSistemaOperativoKeyword_15_0());
                    			
                    this_EQUALS_22=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_22, grammarAccess.getServidorAplicacionesAccess().getEQUALSTerminalRuleCall_15_1());
                    			
                    // InternalCeffective.g:2851:4: ( (lv_sistemaOperativo_23_0= ruleEString ) )
                    // InternalCeffective.g:2852:5: (lv_sistemaOperativo_23_0= ruleEString )
                    {
                    // InternalCeffective.g:2852:5: (lv_sistemaOperativo_23_0= ruleEString )
                    // InternalCeffective.g:2853:6: lv_sistemaOperativo_23_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getServidorAplicacionesAccess().getSistemaOperativoEStringParserRuleCall_15_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_sistemaOperativo_23_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getServidorAplicacionesRule());
                    						}
                    						set(
                    							current,
                    							"sistemaOperativo",
                    							lv_sistemaOperativo_23_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_24=(Token)match(input,RULE_SEMICOLON,FOLLOW_67); 

                    				newLeafNode(this_SEMICOLON_24, grammarAccess.getServidorAplicacionesAccess().getSEMICOLONTerminalRuleCall_15_3());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:2875:3: (otherlv_25= 'recursos' this_EQUALS_26= RULE_EQUALS otherlv_27= '(' ( ( ruleEString ) ) (this_COMA_29= RULE_COMA ( ( ruleEString ) ) )* otherlv_31= ')' this_SEMICOLON_32= RULE_SEMICOLON )?
            int alt55=2;
            int LA55_0 = input.LA(1);

            if ( (LA55_0==33) ) {
                alt55=1;
            }
            switch (alt55) {
                case 1 :
                    // InternalCeffective.g:2876:4: otherlv_25= 'recursos' this_EQUALS_26= RULE_EQUALS otherlv_27= '(' ( ( ruleEString ) ) (this_COMA_29= RULE_COMA ( ( ruleEString ) ) )* otherlv_31= ')' this_SEMICOLON_32= RULE_SEMICOLON
                    {
                    otherlv_25=(Token)match(input,33,FOLLOW_6); 

                    				newLeafNode(otherlv_25, grammarAccess.getServidorAplicacionesAccess().getRecursosKeyword_16_0());
                    			
                    this_EQUALS_26=(Token)match(input,RULE_EQUALS,FOLLOW_61); 

                    				newLeafNode(this_EQUALS_26, grammarAccess.getServidorAplicacionesAccess().getEQUALSTerminalRuleCall_16_1());
                    			
                    otherlv_27=(Token)match(input,52,FOLLOW_10); 

                    				newLeafNode(otherlv_27, grammarAccess.getServidorAplicacionesAccess().getLeftParenthesisKeyword_16_2());
                    			
                    // InternalCeffective.g:2888:4: ( ( ruleEString ) )
                    // InternalCeffective.g:2889:5: ( ruleEString )
                    {
                    // InternalCeffective.g:2889:5: ( ruleEString )
                    // InternalCeffective.g:2890:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getServidorAplicacionesRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getServidorAplicacionesAccess().getRecursosRecursoCrossReference_16_3_0());
                    					
                    pushFollow(FOLLOW_62);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalCeffective.g:2904:4: (this_COMA_29= RULE_COMA ( ( ruleEString ) ) )*
                    loop54:
                    do {
                        int alt54=2;
                        int LA54_0 = input.LA(1);

                        if ( (LA54_0==RULE_COMA) ) {
                            alt54=1;
                        }


                        switch (alt54) {
                    	case 1 :
                    	    // InternalCeffective.g:2905:5: this_COMA_29= RULE_COMA ( ( ruleEString ) )
                    	    {
                    	    this_COMA_29=(Token)match(input,RULE_COMA,FOLLOW_10); 

                    	    					newLeafNode(this_COMA_29, grammarAccess.getServidorAplicacionesAccess().getCOMATerminalRuleCall_16_4_0());
                    	    				
                    	    // InternalCeffective.g:2909:5: ( ( ruleEString ) )
                    	    // InternalCeffective.g:2910:6: ( ruleEString )
                    	    {
                    	    // InternalCeffective.g:2910:6: ( ruleEString )
                    	    // InternalCeffective.g:2911:7: ruleEString
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getServidorAplicacionesRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getServidorAplicacionesAccess().getRecursosRecursoCrossReference_16_4_1_0());
                    	    						
                    	    pushFollow(FOLLOW_62);
                    	    ruleEString();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop54;
                        }
                    } while (true);

                    otherlv_31=(Token)match(input,53,FOLLOW_7); 

                    				newLeafNode(otherlv_31, grammarAccess.getServidorAplicacionesAccess().getRightParenthesisKeyword_16_5());
                    			
                    this_SEMICOLON_32=(Token)match(input,RULE_SEMICOLON,FOLLOW_43); 

                    				newLeafNode(this_SEMICOLON_32, grammarAccess.getServidorAplicacionesAccess().getSEMICOLONTerminalRuleCall_16_6());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:2935:3: (otherlv_33= 'vpc' this_EQUALS_34= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_36= RULE_SEMICOLON )?
            int alt56=2;
            int LA56_0 = input.LA(1);

            if ( (LA56_0==42) ) {
                alt56=1;
            }
            switch (alt56) {
                case 1 :
                    // InternalCeffective.g:2936:4: otherlv_33= 'vpc' this_EQUALS_34= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_36= RULE_SEMICOLON
                    {
                    otherlv_33=(Token)match(input,42,FOLLOW_6); 

                    				newLeafNode(otherlv_33, grammarAccess.getServidorAplicacionesAccess().getVpcKeyword_17_0());
                    			
                    this_EQUALS_34=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_34, grammarAccess.getServidorAplicacionesAccess().getEQUALSTerminalRuleCall_17_1());
                    			
                    // InternalCeffective.g:2944:4: ( ( ruleEString ) )
                    // InternalCeffective.g:2945:5: ( ruleEString )
                    {
                    // InternalCeffective.g:2945:5: ( ruleEString )
                    // InternalCeffective.g:2946:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getServidorAplicacionesRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getServidorAplicacionesAccess().getVpcVPCCrossReference_17_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_36=(Token)match(input,RULE_SEMICOLON,FOLLOW_8); 

                    				newLeafNode(this_SEMICOLON_36, grammarAccess.getServidorAplicacionesAccess().getSEMICOLONTerminalRuleCall_17_3());
                    			

                    }
                    break;

            }

            this_OBJECT_END_37=(Token)match(input,RULE_OBJECT_END,FOLLOW_2); 

            			newLeafNode(this_OBJECT_END_37, grammarAccess.getServidorAplicacionesAccess().getOBJECT_ENDTerminalRuleCall_18());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleServidorAplicaciones"


    // $ANTLR start "entryRuleAlmacenamiento"
    // InternalCeffective.g:2973:1: entryRuleAlmacenamiento returns [EObject current=null] : iv_ruleAlmacenamiento= ruleAlmacenamiento EOF ;
    public final EObject entryRuleAlmacenamiento() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAlmacenamiento = null;


        try {
            // InternalCeffective.g:2973:55: (iv_ruleAlmacenamiento= ruleAlmacenamiento EOF )
            // InternalCeffective.g:2974:2: iv_ruleAlmacenamiento= ruleAlmacenamiento EOF
            {
             newCompositeNode(grammarAccess.getAlmacenamientoRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAlmacenamiento=ruleAlmacenamiento();

            state._fsp--;

             current =iv_ruleAlmacenamiento; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAlmacenamiento"


    // $ANTLR start "ruleAlmacenamiento"
    // InternalCeffective.g:2980:1: ruleAlmacenamiento returns [EObject current=null] : (this_OBJECT_START_0= RULE_OBJECT_START (otherlv_1= 'nombre' this_EQUALS_2= RULE_EQUALS ( (lv_nombre_3_0= ruleEString ) ) this_SEMICOLON_4= RULE_SEMICOLON )? (otherlv_5= 'zonaDisponibilidad' this_EQUALS_6= RULE_EQUALS ( (lv_zonaDisponibilidad_7_0= ruleEString ) ) this_SEMICOLON_8= RULE_SEMICOLON )? (otherlv_9= 'zonaNombre' this_EQUALS_10= RULE_EQUALS ( (lv_zonaNombre_11_0= ruleEString ) ) this_SEMICOLON_12= RULE_SEMICOLON )? (otherlv_13= 'id' this_EQUALS_14= RULE_EQUALS ( (lv_id_15_0= ruleEString ) ) this_SEMICOLON_16= RULE_SEMICOLON )? otherlv_17= 'gigas' this_EQUALS_18= RULE_EQUALS ( (lv_tamanoInicial_19_0= ruleEFloat ) ) this_SEMICOLON_20= RULE_SEMICOLON (otherlv_21= 'recursos' this_EQUALS_22= RULE_EQUALS otherlv_23= '(' ( ( ruleEString ) ) (this_COMA_25= RULE_COMA ( ( ruleEString ) ) )* otherlv_27= ')' this_SEMICOLON_28= RULE_SEMICOLON )? (otherlv_29= 'vpc' this_EQUALS_30= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_32= RULE_SEMICOLON )? this_OBJECT_END_33= RULE_OBJECT_END ) ;
    public final EObject ruleAlmacenamiento() throws RecognitionException {
        EObject current = null;

        Token this_OBJECT_START_0=null;
        Token otherlv_1=null;
        Token this_EQUALS_2=null;
        Token this_SEMICOLON_4=null;
        Token otherlv_5=null;
        Token this_EQUALS_6=null;
        Token this_SEMICOLON_8=null;
        Token otherlv_9=null;
        Token this_EQUALS_10=null;
        Token this_SEMICOLON_12=null;
        Token otherlv_13=null;
        Token this_EQUALS_14=null;
        Token this_SEMICOLON_16=null;
        Token otherlv_17=null;
        Token this_EQUALS_18=null;
        Token this_SEMICOLON_20=null;
        Token otherlv_21=null;
        Token this_EQUALS_22=null;
        Token otherlv_23=null;
        Token this_COMA_25=null;
        Token otherlv_27=null;
        Token this_SEMICOLON_28=null;
        Token otherlv_29=null;
        Token this_EQUALS_30=null;
        Token this_SEMICOLON_32=null;
        Token this_OBJECT_END_33=null;
        AntlrDatatypeRuleToken lv_nombre_3_0 = null;

        AntlrDatatypeRuleToken lv_zonaDisponibilidad_7_0 = null;

        AntlrDatatypeRuleToken lv_zonaNombre_11_0 = null;

        AntlrDatatypeRuleToken lv_id_15_0 = null;

        AntlrDatatypeRuleToken lv_tamanoInicial_19_0 = null;



        	enterRule();

        try {
            // InternalCeffective.g:2986:2: ( (this_OBJECT_START_0= RULE_OBJECT_START (otherlv_1= 'nombre' this_EQUALS_2= RULE_EQUALS ( (lv_nombre_3_0= ruleEString ) ) this_SEMICOLON_4= RULE_SEMICOLON )? (otherlv_5= 'zonaDisponibilidad' this_EQUALS_6= RULE_EQUALS ( (lv_zonaDisponibilidad_7_0= ruleEString ) ) this_SEMICOLON_8= RULE_SEMICOLON )? (otherlv_9= 'zonaNombre' this_EQUALS_10= RULE_EQUALS ( (lv_zonaNombre_11_0= ruleEString ) ) this_SEMICOLON_12= RULE_SEMICOLON )? (otherlv_13= 'id' this_EQUALS_14= RULE_EQUALS ( (lv_id_15_0= ruleEString ) ) this_SEMICOLON_16= RULE_SEMICOLON )? otherlv_17= 'gigas' this_EQUALS_18= RULE_EQUALS ( (lv_tamanoInicial_19_0= ruleEFloat ) ) this_SEMICOLON_20= RULE_SEMICOLON (otherlv_21= 'recursos' this_EQUALS_22= RULE_EQUALS otherlv_23= '(' ( ( ruleEString ) ) (this_COMA_25= RULE_COMA ( ( ruleEString ) ) )* otherlv_27= ')' this_SEMICOLON_28= RULE_SEMICOLON )? (otherlv_29= 'vpc' this_EQUALS_30= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_32= RULE_SEMICOLON )? this_OBJECT_END_33= RULE_OBJECT_END ) )
            // InternalCeffective.g:2987:2: (this_OBJECT_START_0= RULE_OBJECT_START (otherlv_1= 'nombre' this_EQUALS_2= RULE_EQUALS ( (lv_nombre_3_0= ruleEString ) ) this_SEMICOLON_4= RULE_SEMICOLON )? (otherlv_5= 'zonaDisponibilidad' this_EQUALS_6= RULE_EQUALS ( (lv_zonaDisponibilidad_7_0= ruleEString ) ) this_SEMICOLON_8= RULE_SEMICOLON )? (otherlv_9= 'zonaNombre' this_EQUALS_10= RULE_EQUALS ( (lv_zonaNombre_11_0= ruleEString ) ) this_SEMICOLON_12= RULE_SEMICOLON )? (otherlv_13= 'id' this_EQUALS_14= RULE_EQUALS ( (lv_id_15_0= ruleEString ) ) this_SEMICOLON_16= RULE_SEMICOLON )? otherlv_17= 'gigas' this_EQUALS_18= RULE_EQUALS ( (lv_tamanoInicial_19_0= ruleEFloat ) ) this_SEMICOLON_20= RULE_SEMICOLON (otherlv_21= 'recursos' this_EQUALS_22= RULE_EQUALS otherlv_23= '(' ( ( ruleEString ) ) (this_COMA_25= RULE_COMA ( ( ruleEString ) ) )* otherlv_27= ')' this_SEMICOLON_28= RULE_SEMICOLON )? (otherlv_29= 'vpc' this_EQUALS_30= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_32= RULE_SEMICOLON )? this_OBJECT_END_33= RULE_OBJECT_END )
            {
            // InternalCeffective.g:2987:2: (this_OBJECT_START_0= RULE_OBJECT_START (otherlv_1= 'nombre' this_EQUALS_2= RULE_EQUALS ( (lv_nombre_3_0= ruleEString ) ) this_SEMICOLON_4= RULE_SEMICOLON )? (otherlv_5= 'zonaDisponibilidad' this_EQUALS_6= RULE_EQUALS ( (lv_zonaDisponibilidad_7_0= ruleEString ) ) this_SEMICOLON_8= RULE_SEMICOLON )? (otherlv_9= 'zonaNombre' this_EQUALS_10= RULE_EQUALS ( (lv_zonaNombre_11_0= ruleEString ) ) this_SEMICOLON_12= RULE_SEMICOLON )? (otherlv_13= 'id' this_EQUALS_14= RULE_EQUALS ( (lv_id_15_0= ruleEString ) ) this_SEMICOLON_16= RULE_SEMICOLON )? otherlv_17= 'gigas' this_EQUALS_18= RULE_EQUALS ( (lv_tamanoInicial_19_0= ruleEFloat ) ) this_SEMICOLON_20= RULE_SEMICOLON (otherlv_21= 'recursos' this_EQUALS_22= RULE_EQUALS otherlv_23= '(' ( ( ruleEString ) ) (this_COMA_25= RULE_COMA ( ( ruleEString ) ) )* otherlv_27= ')' this_SEMICOLON_28= RULE_SEMICOLON )? (otherlv_29= 'vpc' this_EQUALS_30= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_32= RULE_SEMICOLON )? this_OBJECT_END_33= RULE_OBJECT_END )
            // InternalCeffective.g:2988:3: this_OBJECT_START_0= RULE_OBJECT_START (otherlv_1= 'nombre' this_EQUALS_2= RULE_EQUALS ( (lv_nombre_3_0= ruleEString ) ) this_SEMICOLON_4= RULE_SEMICOLON )? (otherlv_5= 'zonaDisponibilidad' this_EQUALS_6= RULE_EQUALS ( (lv_zonaDisponibilidad_7_0= ruleEString ) ) this_SEMICOLON_8= RULE_SEMICOLON )? (otherlv_9= 'zonaNombre' this_EQUALS_10= RULE_EQUALS ( (lv_zonaNombre_11_0= ruleEString ) ) this_SEMICOLON_12= RULE_SEMICOLON )? (otherlv_13= 'id' this_EQUALS_14= RULE_EQUALS ( (lv_id_15_0= ruleEString ) ) this_SEMICOLON_16= RULE_SEMICOLON )? otherlv_17= 'gigas' this_EQUALS_18= RULE_EQUALS ( (lv_tamanoInicial_19_0= ruleEFloat ) ) this_SEMICOLON_20= RULE_SEMICOLON (otherlv_21= 'recursos' this_EQUALS_22= RULE_EQUALS otherlv_23= '(' ( ( ruleEString ) ) (this_COMA_25= RULE_COMA ( ( ruleEString ) ) )* otherlv_27= ')' this_SEMICOLON_28= RULE_SEMICOLON )? (otherlv_29= 'vpc' this_EQUALS_30= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_32= RULE_SEMICOLON )? this_OBJECT_END_33= RULE_OBJECT_END
            {
            this_OBJECT_START_0=(Token)match(input,RULE_OBJECT_START,FOLLOW_68); 

            			newLeafNode(this_OBJECT_START_0, grammarAccess.getAlmacenamientoAccess().getOBJECT_STARTTerminalRuleCall_0());
            		
            // InternalCeffective.g:2992:3: (otherlv_1= 'nombre' this_EQUALS_2= RULE_EQUALS ( (lv_nombre_3_0= ruleEString ) ) this_SEMICOLON_4= RULE_SEMICOLON )?
            int alt57=2;
            int LA57_0 = input.LA(1);

            if ( (LA57_0==30) ) {
                alt57=1;
            }
            switch (alt57) {
                case 1 :
                    // InternalCeffective.g:2993:4: otherlv_1= 'nombre' this_EQUALS_2= RULE_EQUALS ( (lv_nombre_3_0= ruleEString ) ) this_SEMICOLON_4= RULE_SEMICOLON
                    {
                    otherlv_1=(Token)match(input,30,FOLLOW_6); 

                    				newLeafNode(otherlv_1, grammarAccess.getAlmacenamientoAccess().getNombreKeyword_1_0());
                    			
                    this_EQUALS_2=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_2, grammarAccess.getAlmacenamientoAccess().getEQUALSTerminalRuleCall_1_1());
                    			
                    // InternalCeffective.g:3001:4: ( (lv_nombre_3_0= ruleEString ) )
                    // InternalCeffective.g:3002:5: (lv_nombre_3_0= ruleEString )
                    {
                    // InternalCeffective.g:3002:5: (lv_nombre_3_0= ruleEString )
                    // InternalCeffective.g:3003:6: lv_nombre_3_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getAlmacenamientoAccess().getNombreEStringParserRuleCall_1_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_nombre_3_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getAlmacenamientoRule());
                    						}
                    						set(
                    							current,
                    							"nombre",
                    							lv_nombre_3_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_4=(Token)match(input,RULE_SEMICOLON,FOLLOW_69); 

                    				newLeafNode(this_SEMICOLON_4, grammarAccess.getAlmacenamientoAccess().getSEMICOLONTerminalRuleCall_1_3());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:3025:3: (otherlv_5= 'zonaDisponibilidad' this_EQUALS_6= RULE_EQUALS ( (lv_zonaDisponibilidad_7_0= ruleEString ) ) this_SEMICOLON_8= RULE_SEMICOLON )?
            int alt58=2;
            int LA58_0 = input.LA(1);

            if ( (LA58_0==41) ) {
                alt58=1;
            }
            switch (alt58) {
                case 1 :
                    // InternalCeffective.g:3026:4: otherlv_5= 'zonaDisponibilidad' this_EQUALS_6= RULE_EQUALS ( (lv_zonaDisponibilidad_7_0= ruleEString ) ) this_SEMICOLON_8= RULE_SEMICOLON
                    {
                    otherlv_5=(Token)match(input,41,FOLLOW_6); 

                    				newLeafNode(otherlv_5, grammarAccess.getAlmacenamientoAccess().getZonaDisponibilidadKeyword_2_0());
                    			
                    this_EQUALS_6=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_6, grammarAccess.getAlmacenamientoAccess().getEQUALSTerminalRuleCall_2_1());
                    			
                    // InternalCeffective.g:3034:4: ( (lv_zonaDisponibilidad_7_0= ruleEString ) )
                    // InternalCeffective.g:3035:5: (lv_zonaDisponibilidad_7_0= ruleEString )
                    {
                    // InternalCeffective.g:3035:5: (lv_zonaDisponibilidad_7_0= ruleEString )
                    // InternalCeffective.g:3036:6: lv_zonaDisponibilidad_7_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getAlmacenamientoAccess().getZonaDisponibilidadEStringParserRuleCall_2_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_zonaDisponibilidad_7_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getAlmacenamientoRule());
                    						}
                    						set(
                    							current,
                    							"zonaDisponibilidad",
                    							lv_zonaDisponibilidad_7_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_70); 

                    				newLeafNode(this_SEMICOLON_8, grammarAccess.getAlmacenamientoAccess().getSEMICOLONTerminalRuleCall_2_3());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:3058:3: (otherlv_9= 'zonaNombre' this_EQUALS_10= RULE_EQUALS ( (lv_zonaNombre_11_0= ruleEString ) ) this_SEMICOLON_12= RULE_SEMICOLON )?
            int alt59=2;
            int LA59_0 = input.LA(1);

            if ( (LA59_0==40) ) {
                alt59=1;
            }
            switch (alt59) {
                case 1 :
                    // InternalCeffective.g:3059:4: otherlv_9= 'zonaNombre' this_EQUALS_10= RULE_EQUALS ( (lv_zonaNombre_11_0= ruleEString ) ) this_SEMICOLON_12= RULE_SEMICOLON
                    {
                    otherlv_9=(Token)match(input,40,FOLLOW_6); 

                    				newLeafNode(otherlv_9, grammarAccess.getAlmacenamientoAccess().getZonaNombreKeyword_3_0());
                    			
                    this_EQUALS_10=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_10, grammarAccess.getAlmacenamientoAccess().getEQUALSTerminalRuleCall_3_1());
                    			
                    // InternalCeffective.g:3067:4: ( (lv_zonaNombre_11_0= ruleEString ) )
                    // InternalCeffective.g:3068:5: (lv_zonaNombre_11_0= ruleEString )
                    {
                    // InternalCeffective.g:3068:5: (lv_zonaNombre_11_0= ruleEString )
                    // InternalCeffective.g:3069:6: lv_zonaNombre_11_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getAlmacenamientoAccess().getZonaNombreEStringParserRuleCall_3_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_zonaNombre_11_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getAlmacenamientoRule());
                    						}
                    						set(
                    							current,
                    							"zonaNombre",
                    							lv_zonaNombre_11_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_12=(Token)match(input,RULE_SEMICOLON,FOLLOW_71); 

                    				newLeafNode(this_SEMICOLON_12, grammarAccess.getAlmacenamientoAccess().getSEMICOLONTerminalRuleCall_3_3());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:3091:3: (otherlv_13= 'id' this_EQUALS_14= RULE_EQUALS ( (lv_id_15_0= ruleEString ) ) this_SEMICOLON_16= RULE_SEMICOLON )?
            int alt60=2;
            int LA60_0 = input.LA(1);

            if ( (LA60_0==37) ) {
                alt60=1;
            }
            switch (alt60) {
                case 1 :
                    // InternalCeffective.g:3092:4: otherlv_13= 'id' this_EQUALS_14= RULE_EQUALS ( (lv_id_15_0= ruleEString ) ) this_SEMICOLON_16= RULE_SEMICOLON
                    {
                    otherlv_13=(Token)match(input,37,FOLLOW_6); 

                    				newLeafNode(otherlv_13, grammarAccess.getAlmacenamientoAccess().getIdKeyword_4_0());
                    			
                    this_EQUALS_14=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_14, grammarAccess.getAlmacenamientoAccess().getEQUALSTerminalRuleCall_4_1());
                    			
                    // InternalCeffective.g:3100:4: ( (lv_id_15_0= ruleEString ) )
                    // InternalCeffective.g:3101:5: (lv_id_15_0= ruleEString )
                    {
                    // InternalCeffective.g:3101:5: (lv_id_15_0= ruleEString )
                    // InternalCeffective.g:3102:6: lv_id_15_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getAlmacenamientoAccess().getIdEStringParserRuleCall_4_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_id_15_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getAlmacenamientoRule());
                    						}
                    						set(
                    							current,
                    							"id",
                    							lv_id_15_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_16=(Token)match(input,RULE_SEMICOLON,FOLLOW_72); 

                    				newLeafNode(this_SEMICOLON_16, grammarAccess.getAlmacenamientoAccess().getSEMICOLONTerminalRuleCall_4_3());
                    			

                    }
                    break;

            }

            otherlv_17=(Token)match(input,56,FOLLOW_6); 

            			newLeafNode(otherlv_17, grammarAccess.getAlmacenamientoAccess().getGigasKeyword_5());
            		
            this_EQUALS_18=(Token)match(input,RULE_EQUALS,FOLLOW_73); 

            			newLeafNode(this_EQUALS_18, grammarAccess.getAlmacenamientoAccess().getEQUALSTerminalRuleCall_6());
            		
            // InternalCeffective.g:3132:3: ( (lv_tamanoInicial_19_0= ruleEFloat ) )
            // InternalCeffective.g:3133:4: (lv_tamanoInicial_19_0= ruleEFloat )
            {
            // InternalCeffective.g:3133:4: (lv_tamanoInicial_19_0= ruleEFloat )
            // InternalCeffective.g:3134:5: lv_tamanoInicial_19_0= ruleEFloat
            {

            					newCompositeNode(grammarAccess.getAlmacenamientoAccess().getTamanoInicialEFloatParserRuleCall_7_0());
            				
            pushFollow(FOLLOW_7);
            lv_tamanoInicial_19_0=ruleEFloat();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getAlmacenamientoRule());
            					}
            					set(
            						current,
            						"tamanoInicial",
            						lv_tamanoInicial_19_0,
            						"org.xtext.example.ceffective.Ceffective.EFloat");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_SEMICOLON_20=(Token)match(input,RULE_SEMICOLON,FOLLOW_67); 

            			newLeafNode(this_SEMICOLON_20, grammarAccess.getAlmacenamientoAccess().getSEMICOLONTerminalRuleCall_8());
            		
            // InternalCeffective.g:3155:3: (otherlv_21= 'recursos' this_EQUALS_22= RULE_EQUALS otherlv_23= '(' ( ( ruleEString ) ) (this_COMA_25= RULE_COMA ( ( ruleEString ) ) )* otherlv_27= ')' this_SEMICOLON_28= RULE_SEMICOLON )?
            int alt62=2;
            int LA62_0 = input.LA(1);

            if ( (LA62_0==33) ) {
                alt62=1;
            }
            switch (alt62) {
                case 1 :
                    // InternalCeffective.g:3156:4: otherlv_21= 'recursos' this_EQUALS_22= RULE_EQUALS otherlv_23= '(' ( ( ruleEString ) ) (this_COMA_25= RULE_COMA ( ( ruleEString ) ) )* otherlv_27= ')' this_SEMICOLON_28= RULE_SEMICOLON
                    {
                    otherlv_21=(Token)match(input,33,FOLLOW_6); 

                    				newLeafNode(otherlv_21, grammarAccess.getAlmacenamientoAccess().getRecursosKeyword_9_0());
                    			
                    this_EQUALS_22=(Token)match(input,RULE_EQUALS,FOLLOW_61); 

                    				newLeafNode(this_EQUALS_22, grammarAccess.getAlmacenamientoAccess().getEQUALSTerminalRuleCall_9_1());
                    			
                    otherlv_23=(Token)match(input,52,FOLLOW_10); 

                    				newLeafNode(otherlv_23, grammarAccess.getAlmacenamientoAccess().getLeftParenthesisKeyword_9_2());
                    			
                    // InternalCeffective.g:3168:4: ( ( ruleEString ) )
                    // InternalCeffective.g:3169:5: ( ruleEString )
                    {
                    // InternalCeffective.g:3169:5: ( ruleEString )
                    // InternalCeffective.g:3170:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getAlmacenamientoRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getAlmacenamientoAccess().getRecursosRecursoCrossReference_9_3_0());
                    					
                    pushFollow(FOLLOW_62);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalCeffective.g:3184:4: (this_COMA_25= RULE_COMA ( ( ruleEString ) ) )*
                    loop61:
                    do {
                        int alt61=2;
                        int LA61_0 = input.LA(1);

                        if ( (LA61_0==RULE_COMA) ) {
                            alt61=1;
                        }


                        switch (alt61) {
                    	case 1 :
                    	    // InternalCeffective.g:3185:5: this_COMA_25= RULE_COMA ( ( ruleEString ) )
                    	    {
                    	    this_COMA_25=(Token)match(input,RULE_COMA,FOLLOW_10); 

                    	    					newLeafNode(this_COMA_25, grammarAccess.getAlmacenamientoAccess().getCOMATerminalRuleCall_9_4_0());
                    	    				
                    	    // InternalCeffective.g:3189:5: ( ( ruleEString ) )
                    	    // InternalCeffective.g:3190:6: ( ruleEString )
                    	    {
                    	    // InternalCeffective.g:3190:6: ( ruleEString )
                    	    // InternalCeffective.g:3191:7: ruleEString
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getAlmacenamientoRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getAlmacenamientoAccess().getRecursosRecursoCrossReference_9_4_1_0());
                    	    						
                    	    pushFollow(FOLLOW_62);
                    	    ruleEString();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop61;
                        }
                    } while (true);

                    otherlv_27=(Token)match(input,53,FOLLOW_7); 

                    				newLeafNode(otherlv_27, grammarAccess.getAlmacenamientoAccess().getRightParenthesisKeyword_9_5());
                    			
                    this_SEMICOLON_28=(Token)match(input,RULE_SEMICOLON,FOLLOW_43); 

                    				newLeafNode(this_SEMICOLON_28, grammarAccess.getAlmacenamientoAccess().getSEMICOLONTerminalRuleCall_9_6());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:3215:3: (otherlv_29= 'vpc' this_EQUALS_30= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_32= RULE_SEMICOLON )?
            int alt63=2;
            int LA63_0 = input.LA(1);

            if ( (LA63_0==42) ) {
                alt63=1;
            }
            switch (alt63) {
                case 1 :
                    // InternalCeffective.g:3216:4: otherlv_29= 'vpc' this_EQUALS_30= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_32= RULE_SEMICOLON
                    {
                    otherlv_29=(Token)match(input,42,FOLLOW_6); 

                    				newLeafNode(otherlv_29, grammarAccess.getAlmacenamientoAccess().getVpcKeyword_10_0());
                    			
                    this_EQUALS_30=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_30, grammarAccess.getAlmacenamientoAccess().getEQUALSTerminalRuleCall_10_1());
                    			
                    // InternalCeffective.g:3224:4: ( ( ruleEString ) )
                    // InternalCeffective.g:3225:5: ( ruleEString )
                    {
                    // InternalCeffective.g:3225:5: ( ruleEString )
                    // InternalCeffective.g:3226:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getAlmacenamientoRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getAlmacenamientoAccess().getVpcVPCCrossReference_10_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_32=(Token)match(input,RULE_SEMICOLON,FOLLOW_8); 

                    				newLeafNode(this_SEMICOLON_32, grammarAccess.getAlmacenamientoAccess().getSEMICOLONTerminalRuleCall_10_3());
                    			

                    }
                    break;

            }

            this_OBJECT_END_33=(Token)match(input,RULE_OBJECT_END,FOLLOW_2); 

            			newLeafNode(this_OBJECT_END_33, grammarAccess.getAlmacenamientoAccess().getOBJECT_ENDTerminalRuleCall_11());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAlmacenamiento"


    // $ANTLR start "entryRuleServidorBD"
    // InternalCeffective.g:3253:1: entryRuleServidorBD returns [EObject current=null] : iv_ruleServidorBD= ruleServidorBD EOF ;
    public final EObject entryRuleServidorBD() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleServidorBD = null;


        try {
            // InternalCeffective.g:3253:51: (iv_ruleServidorBD= ruleServidorBD EOF )
            // InternalCeffective.g:3254:2: iv_ruleServidorBD= ruleServidorBD EOF
            {
             newCompositeNode(grammarAccess.getServidorBDRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleServidorBD=ruleServidorBD();

            state._fsp--;

             current =iv_ruleServidorBD; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleServidorBD"


    // $ANTLR start "ruleServidorBD"
    // InternalCeffective.g:3260:1: ruleServidorBD returns [EObject current=null] : (this_OBJECT_START_0= RULE_OBJECT_START otherlv_1= 'nombre' this_EQUALS_2= RULE_EQUALS ( (lv_nombre_3_0= ruleEString ) ) this_SEMICOLON_4= RULE_SEMICOLON (otherlv_5= 'zonaDisponibilidad' this_EQUALS_6= RULE_EQUALS ( (lv_zonaDisponibilidad_7_0= ruleEString ) ) this_SEMICOLON_8= RULE_SEMICOLON )? (otherlv_9= 'zonaNombre' this_EQUALS_10= RULE_EQUALS ( (lv_zonaNombre_11_0= ruleEString ) ) this_SEMICOLON_12= RULE_SEMICOLON )? otherlv_13= 'id' this_EQUALS_14= RULE_EQUALS ( (lv_id_15_0= ruleEString ) ) this_SEMICOLON_16= RULE_SEMICOLON otherlv_17= 'dimension' this_EQUALS_18= RULE_EQUALS ( (lv_tamano_19_0= ruleTamanoServidor ) ) this_SEMICOLON_20= RULE_SEMICOLON otherlv_21= 'tipo' this_EQUALS_22= RULE_EQUALS ( (lv_tipo_23_0= ruleTipoBaseDatos ) ) this_SEMICOLON_24= RULE_SEMICOLON (otherlv_25= 'sistemaManejador' this_EQUALS_26= RULE_EQUALS ( (lv_sistemaManejador_27_0= ruleEString ) ) this_SEMICOLON_28= RULE_SEMICOLON )? (otherlv_29= 'recursos' this_EQUALS_30= RULE_EQUALS otherlv_31= '(' ( ( ruleEString ) ) (this_COMA_33= RULE_COMA ( ( ruleEString ) ) )* otherlv_35= ')' this_SEMICOLON_36= RULE_SEMICOLON )? (otherlv_37= 'vpc' this_EQUALS_38= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_40= RULE_SEMICOLON )? this_OBJECT_END_41= RULE_OBJECT_END ) ;
    public final EObject ruleServidorBD() throws RecognitionException {
        EObject current = null;

        Token this_OBJECT_START_0=null;
        Token otherlv_1=null;
        Token this_EQUALS_2=null;
        Token this_SEMICOLON_4=null;
        Token otherlv_5=null;
        Token this_EQUALS_6=null;
        Token this_SEMICOLON_8=null;
        Token otherlv_9=null;
        Token this_EQUALS_10=null;
        Token this_SEMICOLON_12=null;
        Token otherlv_13=null;
        Token this_EQUALS_14=null;
        Token this_SEMICOLON_16=null;
        Token otherlv_17=null;
        Token this_EQUALS_18=null;
        Token this_SEMICOLON_20=null;
        Token otherlv_21=null;
        Token this_EQUALS_22=null;
        Token this_SEMICOLON_24=null;
        Token otherlv_25=null;
        Token this_EQUALS_26=null;
        Token this_SEMICOLON_28=null;
        Token otherlv_29=null;
        Token this_EQUALS_30=null;
        Token otherlv_31=null;
        Token this_COMA_33=null;
        Token otherlv_35=null;
        Token this_SEMICOLON_36=null;
        Token otherlv_37=null;
        Token this_EQUALS_38=null;
        Token this_SEMICOLON_40=null;
        Token this_OBJECT_END_41=null;
        AntlrDatatypeRuleToken lv_nombre_3_0 = null;

        AntlrDatatypeRuleToken lv_zonaDisponibilidad_7_0 = null;

        AntlrDatatypeRuleToken lv_zonaNombre_11_0 = null;

        AntlrDatatypeRuleToken lv_id_15_0 = null;

        Enumerator lv_tamano_19_0 = null;

        Enumerator lv_tipo_23_0 = null;

        AntlrDatatypeRuleToken lv_sistemaManejador_27_0 = null;



        	enterRule();

        try {
            // InternalCeffective.g:3266:2: ( (this_OBJECT_START_0= RULE_OBJECT_START otherlv_1= 'nombre' this_EQUALS_2= RULE_EQUALS ( (lv_nombre_3_0= ruleEString ) ) this_SEMICOLON_4= RULE_SEMICOLON (otherlv_5= 'zonaDisponibilidad' this_EQUALS_6= RULE_EQUALS ( (lv_zonaDisponibilidad_7_0= ruleEString ) ) this_SEMICOLON_8= RULE_SEMICOLON )? (otherlv_9= 'zonaNombre' this_EQUALS_10= RULE_EQUALS ( (lv_zonaNombre_11_0= ruleEString ) ) this_SEMICOLON_12= RULE_SEMICOLON )? otherlv_13= 'id' this_EQUALS_14= RULE_EQUALS ( (lv_id_15_0= ruleEString ) ) this_SEMICOLON_16= RULE_SEMICOLON otherlv_17= 'dimension' this_EQUALS_18= RULE_EQUALS ( (lv_tamano_19_0= ruleTamanoServidor ) ) this_SEMICOLON_20= RULE_SEMICOLON otherlv_21= 'tipo' this_EQUALS_22= RULE_EQUALS ( (lv_tipo_23_0= ruleTipoBaseDatos ) ) this_SEMICOLON_24= RULE_SEMICOLON (otherlv_25= 'sistemaManejador' this_EQUALS_26= RULE_EQUALS ( (lv_sistemaManejador_27_0= ruleEString ) ) this_SEMICOLON_28= RULE_SEMICOLON )? (otherlv_29= 'recursos' this_EQUALS_30= RULE_EQUALS otherlv_31= '(' ( ( ruleEString ) ) (this_COMA_33= RULE_COMA ( ( ruleEString ) ) )* otherlv_35= ')' this_SEMICOLON_36= RULE_SEMICOLON )? (otherlv_37= 'vpc' this_EQUALS_38= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_40= RULE_SEMICOLON )? this_OBJECT_END_41= RULE_OBJECT_END ) )
            // InternalCeffective.g:3267:2: (this_OBJECT_START_0= RULE_OBJECT_START otherlv_1= 'nombre' this_EQUALS_2= RULE_EQUALS ( (lv_nombre_3_0= ruleEString ) ) this_SEMICOLON_4= RULE_SEMICOLON (otherlv_5= 'zonaDisponibilidad' this_EQUALS_6= RULE_EQUALS ( (lv_zonaDisponibilidad_7_0= ruleEString ) ) this_SEMICOLON_8= RULE_SEMICOLON )? (otherlv_9= 'zonaNombre' this_EQUALS_10= RULE_EQUALS ( (lv_zonaNombre_11_0= ruleEString ) ) this_SEMICOLON_12= RULE_SEMICOLON )? otherlv_13= 'id' this_EQUALS_14= RULE_EQUALS ( (lv_id_15_0= ruleEString ) ) this_SEMICOLON_16= RULE_SEMICOLON otherlv_17= 'dimension' this_EQUALS_18= RULE_EQUALS ( (lv_tamano_19_0= ruleTamanoServidor ) ) this_SEMICOLON_20= RULE_SEMICOLON otherlv_21= 'tipo' this_EQUALS_22= RULE_EQUALS ( (lv_tipo_23_0= ruleTipoBaseDatos ) ) this_SEMICOLON_24= RULE_SEMICOLON (otherlv_25= 'sistemaManejador' this_EQUALS_26= RULE_EQUALS ( (lv_sistemaManejador_27_0= ruleEString ) ) this_SEMICOLON_28= RULE_SEMICOLON )? (otherlv_29= 'recursos' this_EQUALS_30= RULE_EQUALS otherlv_31= '(' ( ( ruleEString ) ) (this_COMA_33= RULE_COMA ( ( ruleEString ) ) )* otherlv_35= ')' this_SEMICOLON_36= RULE_SEMICOLON )? (otherlv_37= 'vpc' this_EQUALS_38= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_40= RULE_SEMICOLON )? this_OBJECT_END_41= RULE_OBJECT_END )
            {
            // InternalCeffective.g:3267:2: (this_OBJECT_START_0= RULE_OBJECT_START otherlv_1= 'nombre' this_EQUALS_2= RULE_EQUALS ( (lv_nombre_3_0= ruleEString ) ) this_SEMICOLON_4= RULE_SEMICOLON (otherlv_5= 'zonaDisponibilidad' this_EQUALS_6= RULE_EQUALS ( (lv_zonaDisponibilidad_7_0= ruleEString ) ) this_SEMICOLON_8= RULE_SEMICOLON )? (otherlv_9= 'zonaNombre' this_EQUALS_10= RULE_EQUALS ( (lv_zonaNombre_11_0= ruleEString ) ) this_SEMICOLON_12= RULE_SEMICOLON )? otherlv_13= 'id' this_EQUALS_14= RULE_EQUALS ( (lv_id_15_0= ruleEString ) ) this_SEMICOLON_16= RULE_SEMICOLON otherlv_17= 'dimension' this_EQUALS_18= RULE_EQUALS ( (lv_tamano_19_0= ruleTamanoServidor ) ) this_SEMICOLON_20= RULE_SEMICOLON otherlv_21= 'tipo' this_EQUALS_22= RULE_EQUALS ( (lv_tipo_23_0= ruleTipoBaseDatos ) ) this_SEMICOLON_24= RULE_SEMICOLON (otherlv_25= 'sistemaManejador' this_EQUALS_26= RULE_EQUALS ( (lv_sistemaManejador_27_0= ruleEString ) ) this_SEMICOLON_28= RULE_SEMICOLON )? (otherlv_29= 'recursos' this_EQUALS_30= RULE_EQUALS otherlv_31= '(' ( ( ruleEString ) ) (this_COMA_33= RULE_COMA ( ( ruleEString ) ) )* otherlv_35= ')' this_SEMICOLON_36= RULE_SEMICOLON )? (otherlv_37= 'vpc' this_EQUALS_38= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_40= RULE_SEMICOLON )? this_OBJECT_END_41= RULE_OBJECT_END )
            // InternalCeffective.g:3268:3: this_OBJECT_START_0= RULE_OBJECT_START otherlv_1= 'nombre' this_EQUALS_2= RULE_EQUALS ( (lv_nombre_3_0= ruleEString ) ) this_SEMICOLON_4= RULE_SEMICOLON (otherlv_5= 'zonaDisponibilidad' this_EQUALS_6= RULE_EQUALS ( (lv_zonaDisponibilidad_7_0= ruleEString ) ) this_SEMICOLON_8= RULE_SEMICOLON )? (otherlv_9= 'zonaNombre' this_EQUALS_10= RULE_EQUALS ( (lv_zonaNombre_11_0= ruleEString ) ) this_SEMICOLON_12= RULE_SEMICOLON )? otherlv_13= 'id' this_EQUALS_14= RULE_EQUALS ( (lv_id_15_0= ruleEString ) ) this_SEMICOLON_16= RULE_SEMICOLON otherlv_17= 'dimension' this_EQUALS_18= RULE_EQUALS ( (lv_tamano_19_0= ruleTamanoServidor ) ) this_SEMICOLON_20= RULE_SEMICOLON otherlv_21= 'tipo' this_EQUALS_22= RULE_EQUALS ( (lv_tipo_23_0= ruleTipoBaseDatos ) ) this_SEMICOLON_24= RULE_SEMICOLON (otherlv_25= 'sistemaManejador' this_EQUALS_26= RULE_EQUALS ( (lv_sistemaManejador_27_0= ruleEString ) ) this_SEMICOLON_28= RULE_SEMICOLON )? (otherlv_29= 'recursos' this_EQUALS_30= RULE_EQUALS otherlv_31= '(' ( ( ruleEString ) ) (this_COMA_33= RULE_COMA ( ( ruleEString ) ) )* otherlv_35= ')' this_SEMICOLON_36= RULE_SEMICOLON )? (otherlv_37= 'vpc' this_EQUALS_38= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_40= RULE_SEMICOLON )? this_OBJECT_END_41= RULE_OBJECT_END
            {
            this_OBJECT_START_0=(Token)match(input,RULE_OBJECT_START,FOLLOW_39); 

            			newLeafNode(this_OBJECT_START_0, grammarAccess.getServidorBDAccess().getOBJECT_STARTTerminalRuleCall_0());
            		
            otherlv_1=(Token)match(input,30,FOLLOW_6); 

            			newLeafNode(otherlv_1, grammarAccess.getServidorBDAccess().getNombreKeyword_1());
            		
            this_EQUALS_2=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

            			newLeafNode(this_EQUALS_2, grammarAccess.getServidorBDAccess().getEQUALSTerminalRuleCall_2());
            		
            // InternalCeffective.g:3280:3: ( (lv_nombre_3_0= ruleEString ) )
            // InternalCeffective.g:3281:4: (lv_nombre_3_0= ruleEString )
            {
            // InternalCeffective.g:3281:4: (lv_nombre_3_0= ruleEString )
            // InternalCeffective.g:3282:5: lv_nombre_3_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getServidorBDAccess().getNombreEStringParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_7);
            lv_nombre_3_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getServidorBDRule());
            					}
            					set(
            						current,
            						"nombre",
            						lv_nombre_3_0,
            						"org.xtext.example.ceffective.Ceffective.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_SEMICOLON_4=(Token)match(input,RULE_SEMICOLON,FOLLOW_40); 

            			newLeafNode(this_SEMICOLON_4, grammarAccess.getServidorBDAccess().getSEMICOLONTerminalRuleCall_4());
            		
            // InternalCeffective.g:3303:3: (otherlv_5= 'zonaDisponibilidad' this_EQUALS_6= RULE_EQUALS ( (lv_zonaDisponibilidad_7_0= ruleEString ) ) this_SEMICOLON_8= RULE_SEMICOLON )?
            int alt64=2;
            int LA64_0 = input.LA(1);

            if ( (LA64_0==41) ) {
                alt64=1;
            }
            switch (alt64) {
                case 1 :
                    // InternalCeffective.g:3304:4: otherlv_5= 'zonaDisponibilidad' this_EQUALS_6= RULE_EQUALS ( (lv_zonaDisponibilidad_7_0= ruleEString ) ) this_SEMICOLON_8= RULE_SEMICOLON
                    {
                    otherlv_5=(Token)match(input,41,FOLLOW_6); 

                    				newLeafNode(otherlv_5, grammarAccess.getServidorBDAccess().getZonaDisponibilidadKeyword_5_0());
                    			
                    this_EQUALS_6=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_6, grammarAccess.getServidorBDAccess().getEQUALSTerminalRuleCall_5_1());
                    			
                    // InternalCeffective.g:3312:4: ( (lv_zonaDisponibilidad_7_0= ruleEString ) )
                    // InternalCeffective.g:3313:5: (lv_zonaDisponibilidad_7_0= ruleEString )
                    {
                    // InternalCeffective.g:3313:5: (lv_zonaDisponibilidad_7_0= ruleEString )
                    // InternalCeffective.g:3314:6: lv_zonaDisponibilidad_7_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getServidorBDAccess().getZonaDisponibilidadEStringParserRuleCall_5_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_zonaDisponibilidad_7_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getServidorBDRule());
                    						}
                    						set(
                    							current,
                    							"zonaDisponibilidad",
                    							lv_zonaDisponibilidad_7_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_64); 

                    				newLeafNode(this_SEMICOLON_8, grammarAccess.getServidorBDAccess().getSEMICOLONTerminalRuleCall_5_3());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:3336:3: (otherlv_9= 'zonaNombre' this_EQUALS_10= RULE_EQUALS ( (lv_zonaNombre_11_0= ruleEString ) ) this_SEMICOLON_12= RULE_SEMICOLON )?
            int alt65=2;
            int LA65_0 = input.LA(1);

            if ( (LA65_0==40) ) {
                alt65=1;
            }
            switch (alt65) {
                case 1 :
                    // InternalCeffective.g:3337:4: otherlv_9= 'zonaNombre' this_EQUALS_10= RULE_EQUALS ( (lv_zonaNombre_11_0= ruleEString ) ) this_SEMICOLON_12= RULE_SEMICOLON
                    {
                    otherlv_9=(Token)match(input,40,FOLLOW_6); 

                    				newLeafNode(otherlv_9, grammarAccess.getServidorBDAccess().getZonaNombreKeyword_6_0());
                    			
                    this_EQUALS_10=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_10, grammarAccess.getServidorBDAccess().getEQUALSTerminalRuleCall_6_1());
                    			
                    // InternalCeffective.g:3345:4: ( (lv_zonaNombre_11_0= ruleEString ) )
                    // InternalCeffective.g:3346:5: (lv_zonaNombre_11_0= ruleEString )
                    {
                    // InternalCeffective.g:3346:5: (lv_zonaNombre_11_0= ruleEString )
                    // InternalCeffective.g:3347:6: lv_zonaNombre_11_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getServidorBDAccess().getZonaNombreEStringParserRuleCall_6_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_zonaNombre_11_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getServidorBDRule());
                    						}
                    						set(
                    							current,
                    							"zonaNombre",
                    							lv_zonaNombre_11_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_12=(Token)match(input,RULE_SEMICOLON,FOLLOW_36); 

                    				newLeafNode(this_SEMICOLON_12, grammarAccess.getServidorBDAccess().getSEMICOLONTerminalRuleCall_6_3());
                    			

                    }
                    break;

            }

            otherlv_13=(Token)match(input,37,FOLLOW_6); 

            			newLeafNode(otherlv_13, grammarAccess.getServidorBDAccess().getIdKeyword_7());
            		
            this_EQUALS_14=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

            			newLeafNode(this_EQUALS_14, grammarAccess.getServidorBDAccess().getEQUALSTerminalRuleCall_8());
            		
            // InternalCeffective.g:3377:3: ( (lv_id_15_0= ruleEString ) )
            // InternalCeffective.g:3378:4: (lv_id_15_0= ruleEString )
            {
            // InternalCeffective.g:3378:4: (lv_id_15_0= ruleEString )
            // InternalCeffective.g:3379:5: lv_id_15_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getServidorBDAccess().getIdEStringParserRuleCall_9_0());
            				
            pushFollow(FOLLOW_7);
            lv_id_15_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getServidorBDRule());
            					}
            					set(
            						current,
            						"id",
            						lv_id_15_0,
            						"org.xtext.example.ceffective.Ceffective.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_SEMICOLON_16=(Token)match(input,RULE_SEMICOLON,FOLLOW_65); 

            			newLeafNode(this_SEMICOLON_16, grammarAccess.getServidorBDAccess().getSEMICOLONTerminalRuleCall_10());
            		
            otherlv_17=(Token)match(input,54,FOLLOW_6); 

            			newLeafNode(otherlv_17, grammarAccess.getServidorBDAccess().getDimensionKeyword_11());
            		
            this_EQUALS_18=(Token)match(input,RULE_EQUALS,FOLLOW_59); 

            			newLeafNode(this_EQUALS_18, grammarAccess.getServidorBDAccess().getEQUALSTerminalRuleCall_12());
            		
            // InternalCeffective.g:3408:3: ( (lv_tamano_19_0= ruleTamanoServidor ) )
            // InternalCeffective.g:3409:4: (lv_tamano_19_0= ruleTamanoServidor )
            {
            // InternalCeffective.g:3409:4: (lv_tamano_19_0= ruleTamanoServidor )
            // InternalCeffective.g:3410:5: lv_tamano_19_0= ruleTamanoServidor
            {

            					newCompositeNode(grammarAccess.getServidorBDAccess().getTamanoTamanoServidorEnumRuleCall_13_0());
            				
            pushFollow(FOLLOW_7);
            lv_tamano_19_0=ruleTamanoServidor();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getServidorBDRule());
            					}
            					set(
            						current,
            						"tamano",
            						lv_tamano_19_0,
            						"org.xtext.example.ceffective.Ceffective.TamanoServidor");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_SEMICOLON_20=(Token)match(input,RULE_SEMICOLON,FOLLOW_74); 

            			newLeafNode(this_SEMICOLON_20, grammarAccess.getServidorBDAccess().getSEMICOLONTerminalRuleCall_14());
            		
            otherlv_21=(Token)match(input,45,FOLLOW_6); 

            			newLeafNode(otherlv_21, grammarAccess.getServidorBDAccess().getTipoKeyword_15());
            		
            this_EQUALS_22=(Token)match(input,RULE_EQUALS,FOLLOW_75); 

            			newLeafNode(this_EQUALS_22, grammarAccess.getServidorBDAccess().getEQUALSTerminalRuleCall_16());
            		
            // InternalCeffective.g:3439:3: ( (lv_tipo_23_0= ruleTipoBaseDatos ) )
            // InternalCeffective.g:3440:4: (lv_tipo_23_0= ruleTipoBaseDatos )
            {
            // InternalCeffective.g:3440:4: (lv_tipo_23_0= ruleTipoBaseDatos )
            // InternalCeffective.g:3441:5: lv_tipo_23_0= ruleTipoBaseDatos
            {

            					newCompositeNode(grammarAccess.getServidorBDAccess().getTipoTipoBaseDatosEnumRuleCall_17_0());
            				
            pushFollow(FOLLOW_7);
            lv_tipo_23_0=ruleTipoBaseDatos();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getServidorBDRule());
            					}
            					set(
            						current,
            						"tipo",
            						lv_tipo_23_0,
            						"org.xtext.example.ceffective.Ceffective.TipoBaseDatos");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_SEMICOLON_24=(Token)match(input,RULE_SEMICOLON,FOLLOW_76); 

            			newLeafNode(this_SEMICOLON_24, grammarAccess.getServidorBDAccess().getSEMICOLONTerminalRuleCall_18());
            		
            // InternalCeffective.g:3462:3: (otherlv_25= 'sistemaManejador' this_EQUALS_26= RULE_EQUALS ( (lv_sistemaManejador_27_0= ruleEString ) ) this_SEMICOLON_28= RULE_SEMICOLON )?
            int alt66=2;
            int LA66_0 = input.LA(1);

            if ( (LA66_0==57) ) {
                alt66=1;
            }
            switch (alt66) {
                case 1 :
                    // InternalCeffective.g:3463:4: otherlv_25= 'sistemaManejador' this_EQUALS_26= RULE_EQUALS ( (lv_sistemaManejador_27_0= ruleEString ) ) this_SEMICOLON_28= RULE_SEMICOLON
                    {
                    otherlv_25=(Token)match(input,57,FOLLOW_6); 

                    				newLeafNode(otherlv_25, grammarAccess.getServidorBDAccess().getSistemaManejadorKeyword_19_0());
                    			
                    this_EQUALS_26=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_26, grammarAccess.getServidorBDAccess().getEQUALSTerminalRuleCall_19_1());
                    			
                    // InternalCeffective.g:3471:4: ( (lv_sistemaManejador_27_0= ruleEString ) )
                    // InternalCeffective.g:3472:5: (lv_sistemaManejador_27_0= ruleEString )
                    {
                    // InternalCeffective.g:3472:5: (lv_sistemaManejador_27_0= ruleEString )
                    // InternalCeffective.g:3473:6: lv_sistemaManejador_27_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getServidorBDAccess().getSistemaManejadorEStringParserRuleCall_19_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_sistemaManejador_27_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getServidorBDRule());
                    						}
                    						set(
                    							current,
                    							"sistemaManejador",
                    							lv_sistemaManejador_27_0,
                    							"org.xtext.example.ceffective.Ceffective.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_28=(Token)match(input,RULE_SEMICOLON,FOLLOW_67); 

                    				newLeafNode(this_SEMICOLON_28, grammarAccess.getServidorBDAccess().getSEMICOLONTerminalRuleCall_19_3());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:3495:3: (otherlv_29= 'recursos' this_EQUALS_30= RULE_EQUALS otherlv_31= '(' ( ( ruleEString ) ) (this_COMA_33= RULE_COMA ( ( ruleEString ) ) )* otherlv_35= ')' this_SEMICOLON_36= RULE_SEMICOLON )?
            int alt68=2;
            int LA68_0 = input.LA(1);

            if ( (LA68_0==33) ) {
                alt68=1;
            }
            switch (alt68) {
                case 1 :
                    // InternalCeffective.g:3496:4: otherlv_29= 'recursos' this_EQUALS_30= RULE_EQUALS otherlv_31= '(' ( ( ruleEString ) ) (this_COMA_33= RULE_COMA ( ( ruleEString ) ) )* otherlv_35= ')' this_SEMICOLON_36= RULE_SEMICOLON
                    {
                    otherlv_29=(Token)match(input,33,FOLLOW_6); 

                    				newLeafNode(otherlv_29, grammarAccess.getServidorBDAccess().getRecursosKeyword_20_0());
                    			
                    this_EQUALS_30=(Token)match(input,RULE_EQUALS,FOLLOW_61); 

                    				newLeafNode(this_EQUALS_30, grammarAccess.getServidorBDAccess().getEQUALSTerminalRuleCall_20_1());
                    			
                    otherlv_31=(Token)match(input,52,FOLLOW_10); 

                    				newLeafNode(otherlv_31, grammarAccess.getServidorBDAccess().getLeftParenthesisKeyword_20_2());
                    			
                    // InternalCeffective.g:3508:4: ( ( ruleEString ) )
                    // InternalCeffective.g:3509:5: ( ruleEString )
                    {
                    // InternalCeffective.g:3509:5: ( ruleEString )
                    // InternalCeffective.g:3510:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getServidorBDRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getServidorBDAccess().getRecursosRecursoCrossReference_20_3_0());
                    					
                    pushFollow(FOLLOW_62);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalCeffective.g:3524:4: (this_COMA_33= RULE_COMA ( ( ruleEString ) ) )*
                    loop67:
                    do {
                        int alt67=2;
                        int LA67_0 = input.LA(1);

                        if ( (LA67_0==RULE_COMA) ) {
                            alt67=1;
                        }


                        switch (alt67) {
                    	case 1 :
                    	    // InternalCeffective.g:3525:5: this_COMA_33= RULE_COMA ( ( ruleEString ) )
                    	    {
                    	    this_COMA_33=(Token)match(input,RULE_COMA,FOLLOW_10); 

                    	    					newLeafNode(this_COMA_33, grammarAccess.getServidorBDAccess().getCOMATerminalRuleCall_20_4_0());
                    	    				
                    	    // InternalCeffective.g:3529:5: ( ( ruleEString ) )
                    	    // InternalCeffective.g:3530:6: ( ruleEString )
                    	    {
                    	    // InternalCeffective.g:3530:6: ( ruleEString )
                    	    // InternalCeffective.g:3531:7: ruleEString
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getServidorBDRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getServidorBDAccess().getRecursosRecursoCrossReference_20_4_1_0());
                    	    						
                    	    pushFollow(FOLLOW_62);
                    	    ruleEString();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop67;
                        }
                    } while (true);

                    otherlv_35=(Token)match(input,53,FOLLOW_7); 

                    				newLeafNode(otherlv_35, grammarAccess.getServidorBDAccess().getRightParenthesisKeyword_20_5());
                    			
                    this_SEMICOLON_36=(Token)match(input,RULE_SEMICOLON,FOLLOW_43); 

                    				newLeafNode(this_SEMICOLON_36, grammarAccess.getServidorBDAccess().getSEMICOLONTerminalRuleCall_20_6());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:3555:3: (otherlv_37= 'vpc' this_EQUALS_38= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_40= RULE_SEMICOLON )?
            int alt69=2;
            int LA69_0 = input.LA(1);

            if ( (LA69_0==42) ) {
                alt69=1;
            }
            switch (alt69) {
                case 1 :
                    // InternalCeffective.g:3556:4: otherlv_37= 'vpc' this_EQUALS_38= RULE_EQUALS ( ( ruleEString ) ) this_SEMICOLON_40= RULE_SEMICOLON
                    {
                    otherlv_37=(Token)match(input,42,FOLLOW_6); 

                    				newLeafNode(otherlv_37, grammarAccess.getServidorBDAccess().getVpcKeyword_21_0());
                    			
                    this_EQUALS_38=(Token)match(input,RULE_EQUALS,FOLLOW_10); 

                    				newLeafNode(this_EQUALS_38, grammarAccess.getServidorBDAccess().getEQUALSTerminalRuleCall_21_1());
                    			
                    // InternalCeffective.g:3564:4: ( ( ruleEString ) )
                    // InternalCeffective.g:3565:5: ( ruleEString )
                    {
                    // InternalCeffective.g:3565:5: ( ruleEString )
                    // InternalCeffective.g:3566:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getServidorBDRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getServidorBDAccess().getVpcVPCCrossReference_21_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_SEMICOLON_40=(Token)match(input,RULE_SEMICOLON,FOLLOW_8); 

                    				newLeafNode(this_SEMICOLON_40, grammarAccess.getServidorBDAccess().getSEMICOLONTerminalRuleCall_21_3());
                    			

                    }
                    break;

            }

            this_OBJECT_END_41=(Token)match(input,RULE_OBJECT_END,FOLLOW_2); 

            			newLeafNode(this_OBJECT_END_41, grammarAccess.getServidorBDAccess().getOBJECT_ENDTerminalRuleCall_22());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleServidorBD"


    // $ANTLR start "entryRuleEFloat"
    // InternalCeffective.g:3593:1: entryRuleEFloat returns [String current=null] : iv_ruleEFloat= ruleEFloat EOF ;
    public final String entryRuleEFloat() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEFloat = null;


        try {
            // InternalCeffective.g:3593:46: (iv_ruleEFloat= ruleEFloat EOF )
            // InternalCeffective.g:3594:2: iv_ruleEFloat= ruleEFloat EOF
            {
             newCompositeNode(grammarAccess.getEFloatRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEFloat=ruleEFloat();

            state._fsp--;

             current =iv_ruleEFloat.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEFloat"


    // $ANTLR start "ruleEFloat"
    // InternalCeffective.g:3600:1: ruleEFloat returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? ) ;
    public final AntlrDatatypeRuleToken ruleEFloat() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_INT_1=null;
        Token this_INT_3=null;
        Token this_INT_7=null;


        	enterRule();

        try {
            // InternalCeffective.g:3606:2: ( ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? ) )
            // InternalCeffective.g:3607:2: ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? )
            {
            // InternalCeffective.g:3607:2: ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? )
            // InternalCeffective.g:3608:3: (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )?
            {
            // InternalCeffective.g:3608:3: (kw= '-' )?
            int alt70=2;
            int LA70_0 = input.LA(1);

            if ( (LA70_0==58) ) {
                alt70=1;
            }
            switch (alt70) {
                case 1 :
                    // InternalCeffective.g:3609:4: kw= '-'
                    {
                    kw=(Token)match(input,58,FOLLOW_77); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getEFloatAccess().getHyphenMinusKeyword_0());
                    			

                    }
                    break;

            }

            // InternalCeffective.g:3615:3: (this_INT_1= RULE_INT )?
            int alt71=2;
            int LA71_0 = input.LA(1);

            if ( (LA71_0==RULE_INT) ) {
                alt71=1;
            }
            switch (alt71) {
                case 1 :
                    // InternalCeffective.g:3616:4: this_INT_1= RULE_INT
                    {
                    this_INT_1=(Token)match(input,RULE_INT,FOLLOW_78); 

                    				current.merge(this_INT_1);
                    			

                    				newLeafNode(this_INT_1, grammarAccess.getEFloatAccess().getINTTerminalRuleCall_1());
                    			

                    }
                    break;

            }

            kw=(Token)match(input,39,FOLLOW_79); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getEFloatAccess().getFullStopKeyword_2());
            		
            this_INT_3=(Token)match(input,RULE_INT,FOLLOW_80); 

            			current.merge(this_INT_3);
            		

            			newLeafNode(this_INT_3, grammarAccess.getEFloatAccess().getINTTerminalRuleCall_3());
            		
            // InternalCeffective.g:3636:3: ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )?
            int alt74=2;
            int LA74_0 = input.LA(1);

            if ( ((LA74_0>=59 && LA74_0<=60)) ) {
                alt74=1;
            }
            switch (alt74) {
                case 1 :
                    // InternalCeffective.g:3637:4: (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT
                    {
                    // InternalCeffective.g:3637:4: (kw= 'E' | kw= 'e' )
                    int alt72=2;
                    int LA72_0 = input.LA(1);

                    if ( (LA72_0==59) ) {
                        alt72=1;
                    }
                    else if ( (LA72_0==60) ) {
                        alt72=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 72, 0, input);

                        throw nvae;
                    }
                    switch (alt72) {
                        case 1 :
                            // InternalCeffective.g:3638:5: kw= 'E'
                            {
                            kw=(Token)match(input,59,FOLLOW_81); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getEFloatAccess().getEKeyword_4_0_0());
                            				

                            }
                            break;
                        case 2 :
                            // InternalCeffective.g:3644:5: kw= 'e'
                            {
                            kw=(Token)match(input,60,FOLLOW_81); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getEFloatAccess().getEKeyword_4_0_1());
                            				

                            }
                            break;

                    }

                    // InternalCeffective.g:3650:4: (kw= '-' )?
                    int alt73=2;
                    int LA73_0 = input.LA(1);

                    if ( (LA73_0==58) ) {
                        alt73=1;
                    }
                    switch (alt73) {
                        case 1 :
                            // InternalCeffective.g:3651:5: kw= '-'
                            {
                            kw=(Token)match(input,58,FOLLOW_79); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getEFloatAccess().getHyphenMinusKeyword_4_1());
                            				

                            }
                            break;

                    }

                    this_INT_7=(Token)match(input,RULE_INT,FOLLOW_2); 

                    				current.merge(this_INT_7);
                    			

                    				newLeafNode(this_INT_7, grammarAccess.getEFloatAccess().getINTTerminalRuleCall_4_2());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEFloat"


    // $ANTLR start "entryRuleEString"
    // InternalCeffective.g:3669:1: entryRuleEString returns [String current=null] : iv_ruleEString= ruleEString EOF ;
    public final String entryRuleEString() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEString = null;


        try {
            // InternalCeffective.g:3669:47: (iv_ruleEString= ruleEString EOF )
            // InternalCeffective.g:3670:2: iv_ruleEString= ruleEString EOF
            {
             newCompositeNode(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEString=ruleEString();

            state._fsp--;

             current =iv_ruleEString.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalCeffective.g:3676:1: ruleEString returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) ;
    public final AntlrDatatypeRuleToken ruleEString() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_0=null;
        Token this_ID_1=null;


        	enterRule();

        try {
            // InternalCeffective.g:3682:2: ( (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) )
            // InternalCeffective.g:3683:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            {
            // InternalCeffective.g:3683:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            int alt75=2;
            int LA75_0 = input.LA(1);

            if ( (LA75_0==RULE_STRING) ) {
                alt75=1;
            }
            else if ( (LA75_0==RULE_ID) ) {
                alt75=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 75, 0, input);

                throw nvae;
            }
            switch (alt75) {
                case 1 :
                    // InternalCeffective.g:3684:3: this_STRING_0= RULE_STRING
                    {
                    this_STRING_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    			current.merge(this_STRING_0);
                    		

                    			newLeafNode(this_STRING_0, grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalCeffective.g:3692:3: this_ID_1= RULE_ID
                    {
                    this_ID_1=(Token)match(input,RULE_ID,FOLLOW_2); 

                    			current.merge(this_ID_1);
                    		

                    			newLeafNode(this_ID_1, grammarAccess.getEStringAccess().getIDTerminalRuleCall_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEString"


    // $ANTLR start "ruleTipoAmbiente"
    // InternalCeffective.g:3703:1: ruleTipoAmbiente returns [Enumerator current=null] : ( (enumLiteral_0= 'IST' ) | (enumLiteral_1= 'QA' ) | (enumLiteral_2= 'NFT' ) | (enumLiteral_3= 'PRD' ) ) ;
    public final Enumerator ruleTipoAmbiente() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalCeffective.g:3709:2: ( ( (enumLiteral_0= 'IST' ) | (enumLiteral_1= 'QA' ) | (enumLiteral_2= 'NFT' ) | (enumLiteral_3= 'PRD' ) ) )
            // InternalCeffective.g:3710:2: ( (enumLiteral_0= 'IST' ) | (enumLiteral_1= 'QA' ) | (enumLiteral_2= 'NFT' ) | (enumLiteral_3= 'PRD' ) )
            {
            // InternalCeffective.g:3710:2: ( (enumLiteral_0= 'IST' ) | (enumLiteral_1= 'QA' ) | (enumLiteral_2= 'NFT' ) | (enumLiteral_3= 'PRD' ) )
            int alt76=4;
            switch ( input.LA(1) ) {
            case 61:
                {
                alt76=1;
                }
                break;
            case 62:
                {
                alt76=2;
                }
                break;
            case 63:
                {
                alt76=3;
                }
                break;
            case 64:
                {
                alt76=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 76, 0, input);

                throw nvae;
            }

            switch (alt76) {
                case 1 :
                    // InternalCeffective.g:3711:3: (enumLiteral_0= 'IST' )
                    {
                    // InternalCeffective.g:3711:3: (enumLiteral_0= 'IST' )
                    // InternalCeffective.g:3712:4: enumLiteral_0= 'IST'
                    {
                    enumLiteral_0=(Token)match(input,61,FOLLOW_2); 

                    				current = grammarAccess.getTipoAmbienteAccess().getISTEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getTipoAmbienteAccess().getISTEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalCeffective.g:3719:3: (enumLiteral_1= 'QA' )
                    {
                    // InternalCeffective.g:3719:3: (enumLiteral_1= 'QA' )
                    // InternalCeffective.g:3720:4: enumLiteral_1= 'QA'
                    {
                    enumLiteral_1=(Token)match(input,62,FOLLOW_2); 

                    				current = grammarAccess.getTipoAmbienteAccess().getQAEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getTipoAmbienteAccess().getQAEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalCeffective.g:3727:3: (enumLiteral_2= 'NFT' )
                    {
                    // InternalCeffective.g:3727:3: (enumLiteral_2= 'NFT' )
                    // InternalCeffective.g:3728:4: enumLiteral_2= 'NFT'
                    {
                    enumLiteral_2=(Token)match(input,63,FOLLOW_2); 

                    				current = grammarAccess.getTipoAmbienteAccess().getNFTEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getTipoAmbienteAccess().getNFTEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalCeffective.g:3735:3: (enumLiteral_3= 'PRD' )
                    {
                    // InternalCeffective.g:3735:3: (enumLiteral_3= 'PRD' )
                    // InternalCeffective.g:3736:4: enumLiteral_3= 'PRD'
                    {
                    enumLiteral_3=(Token)match(input,64,FOLLOW_2); 

                    				current = grammarAccess.getTipoAmbienteAccess().getPRDEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getTipoAmbienteAccess().getPRDEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTipoAmbiente"


    // $ANTLR start "ruleDireccionRegla"
    // InternalCeffective.g:3746:1: ruleDireccionRegla returns [Enumerator current=null] : ( (enumLiteral_0= 'ENTRADA' ) | (enumLiteral_1= 'SALIDA' ) ) ;
    public final Enumerator ruleDireccionRegla() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;


        	enterRule();

        try {
            // InternalCeffective.g:3752:2: ( ( (enumLiteral_0= 'ENTRADA' ) | (enumLiteral_1= 'SALIDA' ) ) )
            // InternalCeffective.g:3753:2: ( (enumLiteral_0= 'ENTRADA' ) | (enumLiteral_1= 'SALIDA' ) )
            {
            // InternalCeffective.g:3753:2: ( (enumLiteral_0= 'ENTRADA' ) | (enumLiteral_1= 'SALIDA' ) )
            int alt77=2;
            int LA77_0 = input.LA(1);

            if ( (LA77_0==65) ) {
                alt77=1;
            }
            else if ( (LA77_0==66) ) {
                alt77=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 77, 0, input);

                throw nvae;
            }
            switch (alt77) {
                case 1 :
                    // InternalCeffective.g:3754:3: (enumLiteral_0= 'ENTRADA' )
                    {
                    // InternalCeffective.g:3754:3: (enumLiteral_0= 'ENTRADA' )
                    // InternalCeffective.g:3755:4: enumLiteral_0= 'ENTRADA'
                    {
                    enumLiteral_0=(Token)match(input,65,FOLLOW_2); 

                    				current = grammarAccess.getDireccionReglaAccess().getENTRADAEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getDireccionReglaAccess().getENTRADAEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalCeffective.g:3762:3: (enumLiteral_1= 'SALIDA' )
                    {
                    // InternalCeffective.g:3762:3: (enumLiteral_1= 'SALIDA' )
                    // InternalCeffective.g:3763:4: enumLiteral_1= 'SALIDA'
                    {
                    enumLiteral_1=(Token)match(input,66,FOLLOW_2); 

                    				current = grammarAccess.getDireccionReglaAccess().getSALIDAEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getDireccionReglaAccess().getSALIDAEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDireccionRegla"


    // $ANTLR start "ruleTamanoServidor"
    // InternalCeffective.g:3773:1: ruleTamanoServidor returns [Enumerator current=null] : ( (enumLiteral_0= 'Micro' ) | (enumLiteral_1= 'Small' ) | (enumLiteral_2= 'Medium' ) | (enumLiteral_3= 'Large' ) ) ;
    public final Enumerator ruleTamanoServidor() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalCeffective.g:3779:2: ( ( (enumLiteral_0= 'Micro' ) | (enumLiteral_1= 'Small' ) | (enumLiteral_2= 'Medium' ) | (enumLiteral_3= 'Large' ) ) )
            // InternalCeffective.g:3780:2: ( (enumLiteral_0= 'Micro' ) | (enumLiteral_1= 'Small' ) | (enumLiteral_2= 'Medium' ) | (enumLiteral_3= 'Large' ) )
            {
            // InternalCeffective.g:3780:2: ( (enumLiteral_0= 'Micro' ) | (enumLiteral_1= 'Small' ) | (enumLiteral_2= 'Medium' ) | (enumLiteral_3= 'Large' ) )
            int alt78=4;
            switch ( input.LA(1) ) {
            case 67:
                {
                alt78=1;
                }
                break;
            case 68:
                {
                alt78=2;
                }
                break;
            case 69:
                {
                alt78=3;
                }
                break;
            case 70:
                {
                alt78=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 78, 0, input);

                throw nvae;
            }

            switch (alt78) {
                case 1 :
                    // InternalCeffective.g:3781:3: (enumLiteral_0= 'Micro' )
                    {
                    // InternalCeffective.g:3781:3: (enumLiteral_0= 'Micro' )
                    // InternalCeffective.g:3782:4: enumLiteral_0= 'Micro'
                    {
                    enumLiteral_0=(Token)match(input,67,FOLLOW_2); 

                    				current = grammarAccess.getTamanoServidorAccess().getMicroEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getTamanoServidorAccess().getMicroEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalCeffective.g:3789:3: (enumLiteral_1= 'Small' )
                    {
                    // InternalCeffective.g:3789:3: (enumLiteral_1= 'Small' )
                    // InternalCeffective.g:3790:4: enumLiteral_1= 'Small'
                    {
                    enumLiteral_1=(Token)match(input,68,FOLLOW_2); 

                    				current = grammarAccess.getTamanoServidorAccess().getSmallEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getTamanoServidorAccess().getSmallEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalCeffective.g:3797:3: (enumLiteral_2= 'Medium' )
                    {
                    // InternalCeffective.g:3797:3: (enumLiteral_2= 'Medium' )
                    // InternalCeffective.g:3798:4: enumLiteral_2= 'Medium'
                    {
                    enumLiteral_2=(Token)match(input,69,FOLLOW_2); 

                    				current = grammarAccess.getTamanoServidorAccess().getMediumEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getTamanoServidorAccess().getMediumEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalCeffective.g:3805:3: (enumLiteral_3= 'Large' )
                    {
                    // InternalCeffective.g:3805:3: (enumLiteral_3= 'Large' )
                    // InternalCeffective.g:3806:4: enumLiteral_3= 'Large'
                    {
                    enumLiteral_3=(Token)match(input,70,FOLLOW_2); 

                    				current = grammarAccess.getTamanoServidorAccess().getLargeEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getTamanoServidorAccess().getLargeEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTamanoServidor"


    // $ANTLR start "ruleTipoBaseDatos"
    // InternalCeffective.g:3816:1: ruleTipoBaseDatos returns [Enumerator current=null] : ( (enumLiteral_0= 'Relacional' ) | (enumLiteral_1= 'NoSql' ) ) ;
    public final Enumerator ruleTipoBaseDatos() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;


        	enterRule();

        try {
            // InternalCeffective.g:3822:2: ( ( (enumLiteral_0= 'Relacional' ) | (enumLiteral_1= 'NoSql' ) ) )
            // InternalCeffective.g:3823:2: ( (enumLiteral_0= 'Relacional' ) | (enumLiteral_1= 'NoSql' ) )
            {
            // InternalCeffective.g:3823:2: ( (enumLiteral_0= 'Relacional' ) | (enumLiteral_1= 'NoSql' ) )
            int alt79=2;
            int LA79_0 = input.LA(1);

            if ( (LA79_0==71) ) {
                alt79=1;
            }
            else if ( (LA79_0==72) ) {
                alt79=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 79, 0, input);

                throw nvae;
            }
            switch (alt79) {
                case 1 :
                    // InternalCeffective.g:3824:3: (enumLiteral_0= 'Relacional' )
                    {
                    // InternalCeffective.g:3824:3: (enumLiteral_0= 'Relacional' )
                    // InternalCeffective.g:3825:4: enumLiteral_0= 'Relacional'
                    {
                    enumLiteral_0=(Token)match(input,71,FOLLOW_2); 

                    				current = grammarAccess.getTipoBaseDatosAccess().getRelacionalEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getTipoBaseDatosAccess().getRelacionalEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalCeffective.g:3832:3: (enumLiteral_1= 'NoSql' )
                    {
                    // InternalCeffective.g:3832:3: (enumLiteral_1= 'NoSql' )
                    // InternalCeffective.g:3833:4: enumLiteral_1= 'NoSql'
                    {
                    enumLiteral_1=(Token)match(input,72,FOLLOW_2); 

                    				current = grammarAccess.getTipoBaseDatosAccess().getNoSqlEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getTipoBaseDatosAccess().getNoSqlEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTipoBaseDatos"

    // Delegated rules


    protected DFA26 dfa26 = new DFA26(this);
    protected DFA43 dfa43 = new DFA43(this);
    static final String dfa_1s = "\35\uffff";
    static final String dfa_2s = "\1\4\1\36\1\5\1\13\2\6\1\45\3\5\3\13\6\6\2\45\1\7\1\5\3\uffff\1\13\1\6\1\7";
    static final String dfa_3s = "\1\4\1\36\1\5\1\15\2\6\1\51\3\5\3\15\6\6\1\51\1\45\1\54\1\5\3\uffff\1\15\1\47\1\54";
    static final String dfa_4s = "\27\uffff\1\2\1\3\1\1\3\uffff";
    static final String dfa_5s = "\35\uffff}>";
    static final String[] dfa_6s = {
            "\1\1",
            "\1\2",
            "\1\3",
            "\1\5\1\uffff\1\4",
            "\1\6",
            "\1\6",
            "\1\11\2\uffff\1\7\1\10",
            "\1\12",
            "\1\13",
            "\1\14",
            "\1\16\1\uffff\1\15",
            "\1\20\1\uffff\1\17",
            "\1\22\1\uffff\1\21",
            "\1\23",
            "\1\23",
            "\1\24",
            "\1\24",
            "\1\25",
            "\1\25",
            "\1\11\3\uffff\1\10",
            "\1\11",
            "\1\27\36\uffff\1\31\3\uffff\1\26\2\30",
            "\1\32",
            "",
            "",
            "",
            "\1\33\1\uffff\1\30",
            "\1\34\40\uffff\1\27",
            "\1\27\44\uffff\1\30"
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final char[] dfa_2 = DFA.unpackEncodedStringToUnsignedChars(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final short[] dfa_4 = DFA.unpackEncodedString(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[][] dfa_6 = unpackEncodedStringArray(dfa_6s);

    class DFA26 extends DFA {

        public DFA26(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 26;
            this.eot = dfa_1;
            this.eof = dfa_1;
            this.min = dfa_2;
            this.max = dfa_3;
            this.accept = dfa_4;
            this.special = dfa_5;
            this.transition = dfa_6;
        }
        public String getDescription() {
            return "1365:2: (this_Subred_0= ruleSubred | this_InternetGateway_1= ruleInternetGateway | this_GrupoSeguridad_2= ruleGrupoSeguridad )";
        }
    }
    static final String dfa_7s = "\41\uffff";
    static final String dfa_8s = "\1\4\1\36\1\uffff\1\5\1\uffff\1\13\2\6\1\45\3\5\3\13\6\6\2\45\1\66\1\5\1\103\4\6\1\7\2\uffff";
    static final String dfa_9s = "\1\62\1\70\1\uffff\1\5\1\uffff\1\15\2\6\1\70\3\5\3\15\6\6\3\70\1\5\1\106\4\6\1\67\2\uffff";
    static final String dfa_10s = "\2\uffff\1\4\1\uffff\1\2\32\uffff\1\3\1\1";
    static final String dfa_11s = "\41\uffff}>";
    static final String[] dfa_12s = {
            "\1\1\55\uffff\1\2",
            "\1\3\6\uffff\1\4\2\uffff\2\4\16\uffff\1\4",
            "",
            "\1\5",
            "",
            "\1\7\1\uffff\1\6",
            "\1\10",
            "\1\10",
            "\1\13\2\uffff\1\12\1\11\16\uffff\1\4",
            "\1\14",
            "\1\15",
            "\1\16",
            "\1\20\1\uffff\1\17",
            "\1\22\1\uffff\1\21",
            "\1\24\1\uffff\1\23",
            "\1\25",
            "\1\25",
            "\1\26",
            "\1\26",
            "\1\27",
            "\1\27",
            "\1\13\2\uffff\1\12\17\uffff\1\4",
            "\1\13\22\uffff\1\4",
            "\1\30\1\uffff\1\4",
            "\1\31",
            "\1\32\1\33\1\34\1\35",
            "\1\36",
            "\1\36",
            "\1\36",
            "\1\36",
            "\1\40\31\uffff\1\40\10\uffff\1\40\2\uffff\1\37\11\uffff\1\40",
            "",
            ""
    };

    static final short[] dfa_7 = DFA.unpackEncodedString(dfa_7s);
    static final char[] dfa_8 = DFA.unpackEncodedStringToUnsignedChars(dfa_8s);
    static final char[] dfa_9 = DFA.unpackEncodedStringToUnsignedChars(dfa_9s);
    static final short[] dfa_10 = DFA.unpackEncodedString(dfa_10s);
    static final short[] dfa_11 = DFA.unpackEncodedString(dfa_11s);
    static final short[][] dfa_12 = unpackEncodedStringArray(dfa_12s);

    class DFA43 extends DFA {

        public DFA43(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 43;
            this.eot = dfa_7;
            this.eof = dfa_7;
            this.min = dfa_8;
            this.max = dfa_9;
            this.accept = dfa_10;
            this.special = dfa_11;
            this.transition = dfa_12;
        }
        public String getDescription() {
            return "2340:2: (this_ServidorAplicaciones_0= ruleServidorAplicaciones | this_Almacenamiento_1= ruleAlmacenamiento | this_ServidorBD_2= ruleServidorBD | this_Servidor_Impl_3= ruleServidor_Impl )";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000002810L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000080080L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000002800L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000800010L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000000140L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000400080L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000000500L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000003000080L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000002000080L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000003000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000004000080L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x00000007E0000080L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0xE000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x00000007C0000080L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000780000080L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000000700000080L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000000600000080L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0004000000000010L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000000400000080L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000002040000000L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0000002000000000L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000004000000080L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000008000000002L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0000032000000000L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000022000000000L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0000040000000080L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x00001C0000000000L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0000140000000000L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0003E80000000000L});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0003C80000000000L});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x0003880000000000L});
    public static final BitSet FOLLOW_50 = new BitSet(new long[]{0x0003080000000000L});
    public static final BitSet FOLLOW_51 = new BitSet(new long[]{0x0002080000000000L});
    public static final BitSet FOLLOW_52 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_53 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000006L});
    public static final BitSet FOLLOW_54 = new BitSet(new long[]{0x0008072240000000L});
    public static final BitSet FOLLOW_55 = new BitSet(new long[]{0x0008072200000000L});
    public static final BitSet FOLLOW_56 = new BitSet(new long[]{0x0008052200000000L});
    public static final BitSet FOLLOW_57 = new BitSet(new long[]{0x0008042200000000L});
    public static final BitSet FOLLOW_58 = new BitSet(new long[]{0x0008040200000000L});
    public static final BitSet FOLLOW_59 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000078L});
    public static final BitSet FOLLOW_60 = new BitSet(new long[]{0x0000040200000000L});
    public static final BitSet FOLLOW_61 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_62 = new BitSet(new long[]{0x0020000000000100L});
    public static final BitSet FOLLOW_63 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_64 = new BitSet(new long[]{0x0000012000000000L});
    public static final BitSet FOLLOW_65 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_66 = new BitSet(new long[]{0x0080040200000080L});
    public static final BitSet FOLLOW_67 = new BitSet(new long[]{0x0000040200000080L});
    public static final BitSet FOLLOW_68 = new BitSet(new long[]{0x0100032040000000L});
    public static final BitSet FOLLOW_69 = new BitSet(new long[]{0x0100032000000000L});
    public static final BitSet FOLLOW_70 = new BitSet(new long[]{0x0100012000000000L});
    public static final BitSet FOLLOW_71 = new BitSet(new long[]{0x0100002000000000L});
    public static final BitSet FOLLOW_72 = new BitSet(new long[]{0x0100000000000000L});
    public static final BitSet FOLLOW_73 = new BitSet(new long[]{0x0400008000001000L});
    public static final BitSet FOLLOW_74 = new BitSet(new long[]{0x0000200000000000L});
    public static final BitSet FOLLOW_75 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000180L});
    public static final BitSet FOLLOW_76 = new BitSet(new long[]{0x0200040200000080L});
    public static final BitSet FOLLOW_77 = new BitSet(new long[]{0x0000008000001000L});
    public static final BitSet FOLLOW_78 = new BitSet(new long[]{0x0000008000000000L});
    public static final BitSet FOLLOW_79 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_80 = new BitSet(new long[]{0x1800000000000002L});
    public static final BitSet FOLLOW_81 = new BitSet(new long[]{0x0400000000001000L});

}